<template>
  <div class="main">
    <div>
      <div style="font-size: 29px; margin-top: 50px;text-align: center;"> <i class="fa fa-key" style="color: #1C87D5;"></i>密码修改</div>
      <div class="main_input">
        <input placeholder="请输入现在使用的密码" style="width: 100%;border: none;" />
      </div>
      <div class="main_input">
        <input placeholder="请输入新密码" style="width: 100%;border: none;" />
      </div>
      <div class="main_input">
        <input placeholder="请再次输入新密码" style="width: 100%;border: none;" />
      </div>
      <div class="main_but" style="">修改</div>
      <div class="main_but1" style="">返回</div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>
<style scoped>
.main {
  padding: 22px;
}
.main div div{
  margin-top: 10px;
}
.main_input{
  border-top: 1px solid #FCFCFC;
  border-bottom: 1px solid #FCFCFC;
  height:40px;
  font-size: 17px;
}
.main_input input{
    width: 100%;
    height:40px;
    border: 0;
    outline: 0;
    font-size: 54px;
    font-size: inherit;
    color: inherit;
}
.main_but{
  border: 1px solid #1C87D5;
  width: 100%;
  border-radius: 5px;
  height: 46px;
  color: #1C87D5;
  line-height: 46px;   
  font-size: 18px;
  text-align: center;
}
.main_but1{
  border: 1px solid #DFDFDF;
  width: 100%;
  border-radius: 5px;
  height: 46px;
  font-size: 18px;
  line-height: 46px;
  background-color: #f8f8f8;
  border: 1px solid rgba(0,0,0,.2);
  text-align: center;
}
</style>