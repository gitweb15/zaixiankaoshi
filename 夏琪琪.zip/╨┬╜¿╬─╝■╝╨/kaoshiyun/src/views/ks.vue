<template>
	<div>
		<div class="top3" style="text-align: center;">
			<div style="background-color:#EAEAEA">
				<i class="fa fa-map-o iconfix" style="color:#5E87D6"></i>&nbsp;
				我的考试 (<span style="color:red">1</span>)
			</div>
			<div style="background-color:#FAFAFA" @click="cj">
				<i class="fa fa-line-chart" style="margin-top: 10px;"></i>&nbsp;
				考试成绩
			</div>
		</div>
		<div class="panel" @click="toksguodu">
			<h4>SSM框架测试</h4>
			<span class="panel-right">已考 2 次</span>
			<p class="panel-desc">有效时间：从04-07 14:53 至 09-30 14:53</p>
			<p class="panel-info">及格/总分：60/100分 丨 限考：<span style="color: red;">100</span> 次</p>
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			return {};
		},
		methods: {
			//跳转成绩页面
			cj() {
				this.$router.push("/cj")
			},
			//跳转考试过渡页面
			toksguodu(){
				this.$router.push('/ksshi')
			}
		}
	};
</script>
<style scoped>
	.top3 div {
		display: inline-block;
		width: 50%;
		height: 100px;
		line-height: 100px;
		font-size: 30px;
	}

	.panel {
		padding: 35px;
		position: relative;
	}

	.panel h4 {
		margin-bottom: 18px;
		font-weight: 400;
		font-size: 33px;
	}

	.panel-right {
		float: right;
		background: #2f8746;
		display: inline-block;
		padding: 12px;
		min-width: 18px;
		border-radius: 28px;
		color: #fff;
		line-height: 18px;
		text-align: center;
		font-size: 22px;
	}

	.panel-desc {
		color: #999;
		font-size: 26px;
	}

	.panel-info {
		margin-top: 30px;
		font-size: 26px;
		color: #cecece;
	}
	
</style>
