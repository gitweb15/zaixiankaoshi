<template>
<!-- 登录页面 -->
	<div>
		<div  style="margin-top: 100px;text-align: center;">
			<img src="http://www.kaoshiyun.com.cn/user/assets/images/logo2.gif?t=2020-05-08 17:01:40" height="50px">
			<p style="font-size: 34px;">考试云</p>
		</div>
		<div style="margin-top: 30px;">
			<div class="form">
				<label class="lab">账号</label><input type="text" id="account" placeholder="请输入账号" class="inp" v-model="name"/>
			</div>
			<div class="form">
				<label class="lab">密码</label><input type="password" id="password" placeholder="请输入密码" class="inp" v-model="password"/>
			</div>
			<div style="margin: 1.1em 15px .3em" @click="sy()">
				<a class="weui-btn" href="#" style="background:#1C87D5">登录</a>
			</div>
		</div>
		<p style="margin-top: 50px;color: #1C87D5;font-size: 17px;text-align: center;" @click="sy">没有账号，以免登录方式浏览</p>
		<p style="color: #999;font-size: 17px;margin-top: 50px;text-align: center;">考试云 - 提供支持</p>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				name:'',//登录名
				password:''//登录密码
			}
		},
		methods: {
			//跳转首页并且存入用户数据
			sy(){
				this.$store.commit("showname",this.name)
				localStorage.setItem("stu_id", 1);
				this.$router.push('/sy')
			},
		}
	}
</script>

<style scoped="scoped">
	.weui-btn {
	    position: relative;
	    display: block;
	    margin-left: auto;
	    margin-right: auto;
	    padding-left: 14px;
	    padding-right: 14px;
	    box-sizing: border-box;
	    font-size: 18px;
	    text-align: center;
	    text-decoration: none;
	    color: #fff;
		height: 100px;
		font-size: 44px;
	    line-height: 100px;
	    border-radius: 15px;
	    -webkit-tap-highlight-color: rgba(0,0,0,0);
	    overflow: hidden;
	}
	.form {
		padding: 30px 20px;
		border-top: 1px solid #FCFCFC;
		border-bottom: 1px solid #FCFCFC;
	}
	
	.inp {
		width:75%;
		border: none;
		font-size: 24px;
		outline: none;
	}
	.lab{
		display: inline-block;
		width: 25%;
		font-size: 24px;
	}
</style>
