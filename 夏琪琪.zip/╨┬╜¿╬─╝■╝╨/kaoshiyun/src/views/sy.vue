<template>
  <div style="padding:27px">
    <div class="top1">
		<i class="fa fa-user-circle" style="font-size:60px;margin-top: 20px;"></i>
		<!-- 根据name是否为空显示隐藏 -->
		<p style="padding-bottom: 20px;color: #e0f47a;" @click="login" v-if="name==null">{{name}}我有账号，点击登录</p>
		<p style="padding-bottom: 20px;" v-if="name!=null">{{name}}</p>
    </div>
    <div class="top2 top2_left"  @click="ks">
      <div>
        <i class="fa fa-map-o iconfix" style="font-size:40px;margin-top: 10px;"></i>
      </div>
      <div style="font-size:18px;margin-top: 10px;">我的考试</div>
    </div>
     <div class="top2 top2_right" @click="cj" style="background-color: #8B8B8B;">
      <div>
       <i class="fa fa-line-chart" style="font-size:40px;margin-top: 10px;"></i>
      </div>
      <div style="font-size:18px;margin-top: 10px;">考试成绩</div>
    </div>
     <div class="top2 top2_left"  @click="lx">
      <div>
        <i class="fa fa-file-text-o" style="font-size:40px;margin-top: 10px;"></i>
      </div>
      <div style="font-size:18px;margin-top: 10px;">我的练习</div>
    </div>
     <div class="top2 top2_right" @click="ctb" style="background-color: #8B8B8B;">
      <div>
        <i class="fa fa-calendar-times-o" style="font-size:40px;margin-top: 10px;"></i>
      </div>
      <div style="font-size:18px;margin-top: 10px;">错题本</div>
    </div>
     <div class="top2 top2_left"  @click="kc">
      <div>
        <i class="fa fa-leanpub iconfix" style="font-size:40px;margin-top: 10px;"></i>
      </div>
      <div style="font-size:18px;margin-top: 10px;">我的课程</div>
    </div>
     <div class="top2 top2_right" @click="jf" style="background-color: #8B8B8B;">
      <div>
        <i class="fa fa-star" style="font-size:40px;margin-top: 10px;"></i>
      </div>
      <div style="font-size:18px;margin-top: 10px;">我的积分</div>
    </div>
    <div class="top3">
        <div style="background-color:#99A8CA" @click="xgmm">
             <i class="fa fa-key" style="font-size:25px;"></i>修改密码
        </div>
        <div style="background-color:#B9BECB" @click="login">
          <i class="fa fa-sign-out" style="font-size:25px;"></i>退出登录
        </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },methods:{
   ks(){
      this.$router.push("/ks")//跳转到考试页面
	  this.$store.commit("isActive",2)
    },
    lx(){
      this.$router.push({name:"lx",params: {id: '111'}})//跳转到练习页面
	  this.$store.commit("isActive", 3)
    },
    kc(){
      this.$router.push("/kc")//跳转到我的课程
	  this.$store.commit("isActive", 4)
    },
    cj(){
      this.$router.push("/cj")//跳转到考试成绩
	  this.$store.commit("isActive", 2)
    },
    ctb(){
      this.$router.push("/ctb")//跳转到错题本页面
    },
    jf(){
      this.$router.push("/jf")//跳转到积分页面
    },
    xgmm(){
      this.$router.push("/xgmm")//跳转到修改密码页面
    },
    login(){
		if(this.$store.state.name!=null){
			this.$store.state.name=null
		}
      this.$router.push("/login")//退出登录
    }
  },
  computed: {
		//取出vuex里的name变量
		name() {
			return this.$store.state.name
		}
	},
  created(){
  	  // localStorage.setItem("isChanges","1")
	  console.log('奠基石1')
  }
};
</script>
<style scoped>
.top1 {
  width: 100%;
  background-color: #4c6aa9;
  border-radius: 10px;
  color: white;
  text-align: center;
}
.top2 {
  background-color: #6785c3;
  width: 47%;
  height: 100%;
  border-radius: 10px;
  color: white;
  margin-top: 27px;
  display: inline-block;
  padding-bottom: 10px;
  text-align: center;
}
.top2_left{
  margin-right: 3%;
  
}
.top2_right{
  margin-left: 3%;
}
.fa {
    display: inline-block;
    font-size: inherit;
    text-rendering: auto;
}
.top3 div{
    margin-top: 27px;
    display: inline-block;
    width: 50%;
    height: 120px;
    line-height: 120px;
    font-size: 23px;
    color: white;
	text-align: center;
}
</style>
