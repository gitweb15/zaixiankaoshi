<template>
	<div style="text-align: center;">
		<div v-if="id==1">
			<div style="padding-top: 120px;">
				<img src="../assets/dui.png" width="93px" />
			</div>
			<div style="font-size: 19px;margin-top: 30px;">
				交卷成功
			</div>
			<div class="bottom">
				<a href="#" @click="$router.push('/sy')" class="bottom-item" style="border-right: #e2e1e1 1px solid;">返回</a>
				<a href="#" class="bottom-item" @click="id=2">问题反馈</a>
			</div>
		</div>
		<div v-if="id==2">
			<div class="ground">

			</div>
			<div class="text">

				<textarea class="text1" placeholder="说点什么吧，为了方便于联系你，你可以留下你的联系方式。" rows="3"></textarea>
				<div class="text2">200字内</div>
			</div>
			<div class="fankui" @click="id=3">
				提交反馈
			</div>
			<div class="bottom">
				<a href="#" @click="id=1" class="bottom-item" style="width: 100%;">返回</a>
			</div>
		</div>
		<div v-if="id==3">
			<div style="padding-top: 120px;">
				<img src="../assets/dui.png" width="93px" />
			</div>
			<div style="font-size: 19px;margin-top: 30px;">
				提交成功
				<p style="font-size: 14px;color: #999;margin-top: 5px;">感谢您的宝贵意见，我们会尽快处理</p>
			</div>
			<div class="bottom">
				<a href="#" @click="$router.push('/sy')" class="bottom-item" style="width: 100%;">返回</a>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				id: 1
			}
		},
		methods: {
			back() {
				this.$router.go(-1)
			}
		}
	}
</script>

<style scoped>
	a {
		text-decoration: none;
	}

	.bottom {
		background: #fff;
		border: #e2e1e1 1px solid;
		width: 100%;
		position: fixed;
		z-index: 500;
		bottom: 0;
	}

	.bottom-item {
		color: #808080;
		width: 49%;
		display: block;
		float: left;
		padding: 30px 0;
	}

	.ground {
		width: 100%;
		background-color: #B9BECB;
		height: 45px;
	}

	.text {
		font-size: 30px;
		padding: 30px 40px;
		border: 2px solid #eee;
		margin-bottom: 25px;
	}

	.text1 {
		border: 0;
		width: 100%;
		font-size: 45px;
		line-height: 60px;
		outline: 0;
		text-decoration: 20px;
		letter-spacing: 3px
	}

	.text2 {
		color: #b2b2b2;
		text-align: right;
		font-size: 40px;
	}

	.fankui {
		width: 150px;
		margin-top: 14px;
		background-color: #1aad19;
		text-align: center;
		margin: 0 auto;
		padding: 15px 100px;
		border-radius: 15px;
		color: white;
		font-size: 30px;
	}
</style>
