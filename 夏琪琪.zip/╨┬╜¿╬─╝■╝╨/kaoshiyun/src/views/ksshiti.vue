<template>
	<div style="padding: 10px;">
		<div v-if="id==1">
			<div style="margin-bottom: 20px;border-bottom: #e2e1e1 1px solid;padding-bottom:20px;">
				SSM框架测试
			</div>
			<div style="margin: 20px 0;">
				第1大题(共35题,100.00分)
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					1.
				</span>
				Spring的元素中的autowire属性取值不包括以下。( ) (单选题,2.0分)
				<mt-radio v-model="value" :options="['A.default', 'B.byName', 'C.byType','D.byId']">
				</mt-radio>
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					2.
				</span>
				对于<input type='text' style='border:none;border-bottom:black solid 1px;outline: none;text-align: center;'>
				作用域的Bean,Spring只负责创建，当容器创建了Bean实例后，Bean的实例就交给客户端代码来管理,Spring容器将不再跟踪其生命周期。(填空题,2.0分)
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					3.
				</span>
				Spring配置文件中的元素下可以包含多个aop:config元素，一个aop:conflg元素中又可以包含属性和子元素，其子元素包括aop:pointcut、aop:advisor和aop:aspecto ( )
				(判断题.2.0分)
				<mt-radio :options="['A.正确', 'B.错误']">
				</mt-radio>
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					4.
				</span>
				@PathVariable注 解用于接收并绑定请求参数，它可以将请求URL中的<input type='text' style='border:none;border-bottom:black solid 1px;outline: none;text-align: center;'>
				到方法的形参上。(填空题,2.0分)
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					5.
				</span>
				Spring MVC提供了一个前端控制器<input type='text' style='border:none;border-bottom:black solid 1px;outline: none;text-align: center;'>
				，使开发人员无需额外开发控制器对象。(填空题,2.0分)
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					6.
				</span>
				下列关于拦截器的执行流程说法错误的是。( ) (单选题,2.0分)
				<mt-radio v-model="value" :options="['A.程序首先会执行拦截器类中的preHandle()方法。', 'B.如果preHandle()方法的返回值为true,则程序会继续向下执行处理器中的方法，否则将不再向下执行。', 'C.在业务处理器(即控制器Controller类) 处理完请求后，会执行preHandle()方 法。','D.在DispatcherServlet处理完请求后，才会执行afterCompletion()方法。']">
				</mt-radio>
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					7.
				</span>
				Spring的元素中的autowire属性取值不包括以下。( ) (单选题,2.0分)
				<mt-radio v-model="value" :options="['A.default', 'B.byName', 'C.byType','D.byId']">
				</mt-radio>
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					8.
				</span>
				对于<input type='text' style='border:none;border-bottom:black solid 1px;outline: none;text-align: center;'>
				作用域的Bean,Spring只负责创建，当容器创建了Bean实例后，Bean的实例就交给客户端代码来管理,Spring容器将不再跟踪其生命周期。(填空题,2.0分)
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					9.
				</span>
				Spring配置文件中的元素下可以包含多个aop:config元素，一个aop:conflg元素中又可以包含属性和子元素，其子元素包括aop:pointcut、aop:advisor和aop:aspecto ( )
				(判断题.2.0分)
				<mt-radio :options="['A.正确', 'B.错误']">
				</mt-radio>
			</div>
			<div class="subject">
				<span style="color: #316fb8;">
					10.
				</span>
				@PathVariable注 解用于接收并绑定请求参数，它可以将请求URL中的<input type='text' style='border:none;border-bottom:black solid 1px;outline: none;text-align: center;'>
				到方法的形参上。(填空题,2.0分)
			</div>
		</div>
		<div v-if="id==2">
			<div class="top">
				▦&nbsp;答题卡
			</div>
			<div style="padding: 8px 8px 8px 20px;">
				第 1 大题<br />
				<a class="tishu" v-for="(a,index) in 35" :key="index">
					{{a}}
				</a>
			</div>
		</div>
		<div style="margin-top: 20%;"></div>
		<div class="bottom">
			<a href="#" v-if="id==1" @click="id=2" class="bottom-item" style="border-right: #e2e1e1 1px solid;color: #000000;background-color: #e5e5e5;">答题卡</a>
			<a href="#" v-if="id==2" @click="id=1" class="bottom-item" style="border-right: #e2e1e1 1px solid;color: #000000;background-color: #e5e5e5;">返回到试卷</a>
			<a href="#" class="bottom-item" style="background-color: #e64240;color: white;" @click="commit">交卷<span style="font-size: 12px;margin-left: 10px;">{{minutes}}分{{seconds}}秒</span></a>
		</div>
	</div>
</template>

<script>
	import { MessageBox } from 'mint-ui';
	export default {
		data() {
			return {
				value: null,
				minutes: 60,
				seconds: 0,
				id: 1
			}
		},
		methods: {
			commit(){
				MessageBox({
				  title: '',
				  message: '确认交卷吗?',
				  showCancelButton: true
				});
				MessageBox.confirm('确认交卷吗?').then(action => {
				  this.$router.push('/jjcg')
				});
			},
			// 倒计时
			num(n) {
				return n < 10 ? '0' + n : '' + n
			},
			timer() {

				var _this = this
				var time = setInterval(function() {
					if (_this.seconds === 0 && _this.minutes !== 0) {
						_this.seconds = 59
						_this.minutes -= 1
					} else if (_this.minutes === 0 && _this.seconds === 0) {
						_this.seconds = 0
						clearInterval(time)
					} else {
						_this.seconds -= 1
					}
				}, 1000)
			}
		},
		mounted() {
			this.timer()
		},
		watch: {
			second: {
				handler(newVal) {
					this.num(newVal)
				}
			},
			minute: {
				handler(newVal) {
					this.num(newVal)
				}
			}
		},
	}
</script>

<style scoped>
	li {
		list-style: none;
	}

	.top {
		text-align: center;
		display: inline-block;
		width: 100%;
		height: 90px;
		line-height: 90px;
		font-size: 35px;
		border-bottom: 1px solid #e2e2e2;
	}

	.subject {
		margin-top: 50px;
	}

	.bottom {
		text-align: center;
		background: #fff;
		border: #e2e1e1 1px solid;
		width: 100%;
		position: fixed;
		right: 0;
		z-index: 500;
		bottom: 0;
	}

	.bottom-item {
		color: #808080;
		width: 49%;
		display: block;
		float: left;
		padding: 30px 0;
	}

	.tishu {
		display: inline-block;
		line-height: 45px;
		width: 50px;
		text-align: center;
		margin-right: 12px;
		border-radius: 50%;
		border: solid 1px #bababc;
		padding: 30px;
		margin-bottom: 50px;
	}
</style>
