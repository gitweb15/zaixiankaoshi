<template>
  <div class="main">
  		<div class="top3" style="text-align: center;">
  			<div style="background-color:#FAFAFA" @click="ks">
  				<i class="fa fa-map-o iconfix" style="color:#5E87D6"></i>&nbsp;
  				我的考试
  			</div>
  			<div style="background-color:#EAEAEA">
  				<i class="fa fa-line-chart" style="margin-top: 10px;"></i>&nbsp;
  				考试成绩 (<span style="color:red">1</span>)
  			</div>
  		</div>
  		<div style="background-color: #EFEFF4;">
  			<input placeholder="搜索" style="width: 90%;margin: 4%;height: 30px;border:0;border-radius: 3px;text-align: center;color: #9b9b9b;background: #fff;" />
  		</div>
  		<div class="panel" @click="$router.push('/jjcg')">
  			<h4>SSM框架测试</h4>
  			<p class="panel-desc">2020-05-16 08:52:34</p>
  			<p class="panel-info">成绩：-- 分 丨 及格/总分：60/100分</p>
  		</div>
  	</div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods:{
    ks(){
      this.$router.push("/ks")//跳转考试
    }
  }
};
</script>
<style scoped>
.top3 div {
  display: inline-block;
  width: 50%;
  height: 100px;
  line-height: 100px;
  font-size: 30px;
  text-align: center;
}
.mint-search {
		height: 100px;
		overflow: hidden;
	}

	.panel {
		padding: 35px;
		position: relative;
	}

	.panel h4 {
		margin-bottom: 18px;
		font-weight: 400;
	}

	.panel-desc {
		color: #999;
		font-size: 30px;
	}

	.panel-info {
		margin-top: 30px;
		font-size: 30px;
		color: #cecece;
	}
</style>