<template>
  <div class="main">
    <!-- 云平台 -->
     <div class="top_1">
      <img src="http://www.kaoshiyun.com.cn/File/331460/Logo/logo331460.png" class="top_logo" /> 海纳会实训云平台
	  </div>
   <div>
    <div class="top2">
        <div class="top2_1">
            消息中间件
        </div>
        <div class="top2_2">
            <div>学分：0.0</div>
            <div>状态:  <span style="background-color:#02b81b;color: white;padding: 4px 12px;border-radius: 5px;margin-left: 15px;">已完成课程</span></div>
        </div>
        <div class="top2_3">
            课程要求：至少学习60分钟
        </div>
        <div class="top2_4">
            已完成课程
        </div>
    </div>
	<div class="top_title">课程目录</div>
    <div class="top3" @click="tokcnr">
		<div>第1章</div>
		<div><i class="fa fa-bars" aria-hidden="true"></i>1.1  RabbitMQ消息中间件-1</div>
		<div><i class="fa fa-bars" aria-hidden="true"></i>1.2  RabbitMQ消息中间件-2</div>
    </div>
	<div class="top3" @click="tokcnr">
		<div>第2章</div>
		<div><i class="fa fa-bars" aria-hidden="true"></i>2.1  ActiveMQ消息中间件-1</div>
		<div><i class="fa fa-bars" aria-hidden="true"></i>2.2  ActiveMQ消息中间件-2</div>
	</div>
	<div class="top3" @click="tokcnr1">
		<div>第3章</div>
		<div><i class="fa fa-caret-square-o-right" aria-hidden="true"></i></i>3.1  消息如何保障 100% 的投递成功方案-1</div>
		<div><i class="fa fa-caret-square-o-right" aria-hidden="true"></i></i>3.2  消息如何保障 100% 的投递成功方案-2</div>
	</div>
   </div>
   <div class="nav">
	   <div class="nav1">
		   学习有效时间
	   </div>
	   <div class="nav2">
			从04-06 08:51至05-06 08:51
	   </div>
   </div>
   <div class="course-btns">
	   <a @click="$router.push('/kcnr')" style="float: left;">继续学习</a>
   </div>
	<div @click="$router.go(-1)" style="position: fixed; z-index: 0; box-shadow: rgba(15, 66, 76, 0.25) 0px 0px 14px 0px; width: 60px; height: 60px; border-radius: 50%; background-color: gray; left: 10px; bottom: 60px;">
		<a style="position:relative;text-decoration: none; outline: none; font-family: Microsoft Yahei, Arial, Helvetica; color: #fff; font-size: 16px; display: inline-block; margin: 0; padding: 0; border: none; line-height:60px; text-align:center;float:none;width:100%;height:100%;border-radius:50%;">
			<span>返回</span>
		</a>
	</div>
	<div style="position: fixed; z-index: 0; box-shadow: rgba(15, 66, 76, 0.25) 0px 0px 14px 0px; width: 60px; height: 60px; border-radius: 50%; background-color: rgb(33, 204, 134); right: 10px; bottom: 60px;">
		<a href="/tongji" style="position:relative;text-decoration: none; outline: none; font-family: Microsoft Yahei, Arial, Helvetica; color: #fff; font-size: 16px; display: inline-block; margin: 0; padding: 0; border: none; line-height:60px; text-align:center;float:none;width:100%;height:100%;border-radius:50%;">
			<span>统计</span>
		</a>
	</div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods:{
	 tokcnr(){
		this.$router.push('/kcnr')
	},
	tokcnr1(){
		this.$router.push('/kcnr1')
	}
  }
};
</script>
<style scoped>
.top_1{
    padding-left: 45px;
    text-align: left;
    height: 100px;
    font-size: 33px;
	line-height: 100px;
	border-bottom: 1px solid #EEEEEE;
}
.top_logo{
    width: 60px;
    height: 60px;
    vertical-align: middle;
}
.top2{
    padding: 15px;
	/* background-color: red; */
}
.top2_1{
    font-weight: bold;
    text-align: left;
	height: 100px;
	line-height: 80px;
	font-size: 35px;
	margin-left: 45px;
	margin-right: 45px;
    border-bottom: 1px solid #EEEEEE;
}
.top2_2{
    padding: 20px 0;
	height: 60px;
	font-size: 35px;
	border-bottom: 1px solid #D9DDE1;
	margin-left: 45px;
	margin-right: 45px;
}
.top2_2 div:nth-child(1){
	width: 50%;
	display: inline-block;
	text-align: center;
	border-right: 1px solid #D9DDE1;
	font-size: 17px;
	color: #71777D;
}
.top2_2 div:nth-child(2){
	display: inline-block;
	width: 48%;
	font-size: 17px;
	color: #71777D;
	margin-left: 1%;
}
.top2_3{
	text-align: center;
	height: 80px;
	line-height: 80px;
	color: #71777D;
	border-top: 1px solid #D9DDE1;
	margin-top: 70px;
	margin-left: 45px;
	margin-right: 45px;
	border-bottom: 10px solid #09BB07;
}
.top2_4{
	border: 1px solid #D9DDE1;
	margin-left: 45px;
	margin-right: 45px;
	text-align: center;
	font-size: 30px;
	padding: 5px 0;
	color: #71777D;
}
.top3{
	margin-left: 45px;
	margin-right: 45px;
}
.top_title{
	font-size: 30px;
	height: 90px;
	line-height: 90px;
	font-weight: bold;
	margin-left: 45px;
}
.top3 div:nth-child(1){
	font-size: 28px;
	height: 80px;
	line-height: 80px;
	margin-top: 15px;
}
.top3 div:nth-child(2),.top3 div:nth-child(3){
	box-shadow: 0 0.05rem 0.2rem 0.05rem #e0e3e6;
	border-radius: .25rem;
	height: 90px;
	line-height: 90px;
	color: #71777D;
	margin-top: 20px;
}
.top3 i{
	width: 90px;
	height: 90px;
	text-align: center;
	color: #71777D;
}
.nav{
	margin-left: 60px;
}
.nav1{
	height: 100px;
	line-height: 100px;
	margin-top: 80px;
	font-size: 30px;
	font-weight: bold;
}
.nav2{
	font-size: 28px;
	color: #71777D;
	margin-bottom: 300px;
}
.course-btns {
    width: 100%;
    max-width: 1000px;
    margin: 0 auto;
    position: fixed;
    bottom: 0;
    z-index: 10000000;
}
.course-btns a {
    margin: 0;
    width: 100%;
    border-radius: 0;
    box-sizing: border-box;
    line-height: 1.3rem;
    height: 1.3rem;
	text-align: center;
	text-decoration: none;
	color: #FFFFFF;
	font-size: 32px;
	background: #21cc86;
}
</style>