<template>
	<div style="padding: 15px;font-size: 16px;">
		<div style="font-size: 20px;">
			<img style="vertical-align: bottom;" src="http://www.kaoshiyun.com.cn/File/331460/Logo/logo331460.png?t=2020-04-03%2016:02:04"
			 height="35px">
			海纳会实训云平台
		</div>
		<div style="margin: 30px 0 20px 0;font-size: 17px;">
			{{name}}
		</div>
		<div style="margin: 20px 0;white-space: nowrap;font-size: 17px;">
			有效时间：从04-07 14:53至09-30 14:53
		</div>

		<div style="margin: 20px 0;font-size: 17px;">
			可考次数：100（次）
		</div>
		<div style="margin: 20px 0;font-size: 17px;">
			及格分数：60.00（分）
		</div>
		<div style="margin: 20px 0;font-size: 17px;">
			试卷总分：100.00（分）
		</div>
		<div style="margin: 20px 0;border-bottom: #e2e1e1 1px solid;padding-bottom: 20px;font-size: 17px;">
			答题时间：60（分钟）
		</div>
		<div style="color: #b2b2b2;font-size: 17px;">
			<i class="fa fa-info-circle" style="font-size: 22px;color: #1aad19;"></i> 参加考试前，请输入以下信息
		</div>
		<div style="margin: 20px 0;font-size: 17px;">
			账号：210XXY <span @click="$router.push('/login')" style="display: inline-block;color: #1aad19;margin-left: 20px;font-size: 17px;">切换账号</span>
		</div>
		<div style="margin: 20px 0;font-size: 17px;">
			姓名：冼学阳
		</div>
		<div class="btn1" @click="$router.push('/ksnr')">参加考试</div>
		<div>
			<p style="color: #999;font-size: 15px;margin-top: 15px;text-align: center;">考试云 - 提供支持</p>
		</div>
	</div>
</template>

<script>
	export default {
		data(){
			return{
				title:[
					{name:'消息队列练习'},
					{name:'SSO练习'},
					{name:'Redis练习'},
					{name:'SSM面试题2019'},
					{name:'SpringCloud练习'},
					{name:'Nginx随机练习'}
				],
				name: ''
			}
		},
		created(){	
			let name = localStorage["name"]
			console.log("...",name)
			this.name=name
			
		}
	}
</script>

<style scoped>
	.btn1 {
		margin-top: 50px;
		border: 2px solid #1C87D5;
		width: 100%;
		background-color: #1aad19;
		border-radius: 10px;
		height: 60px;
		color: white;
		line-height: 60px;
		text-align: center;
		font-size: 25px;
	}
</style>
