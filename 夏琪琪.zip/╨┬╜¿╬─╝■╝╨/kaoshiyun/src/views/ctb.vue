<template>
<!-- 错题本页面 -->
  <div class="main">
    <div class="top"><i class="fa fa-file-text-o"></i>  错题本</div>
    <div class="main_title">错题设置</div>
    <div class="main_switch">
        <mt-switch v-model="value">答对后自动从错题本移除</mt-switch>
    </div>
    <div class="main_switchs">
        <mt-switch v-model="value1">  背题模式</mt-switch>
    </div>
    <div class="main_titles">错题列表</div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      value: false,
      value1: false
    };
  }
};
</script>
<style scoped>
  .top{
    display: block;
    width: 100%;
    height: 50px;
    line-height: 50px;
    padding: 13px 0;
    text-align: center;
    font-size: 18px;
    color: inherit;
    background-color:#FAFAFA;
    border-bottom: 1px solid #E2E2E2;
	text-align: center;
  }
  .main_title{
    margin-top: .77em;
    margin-bottom: .3em;
    padding-left: 15px;
    padding-bottom: 5px;
    color: #999;
    font-size: 14px;
    text-align: left;
    border-bottom: 1px solid #E2E2E2;
  }
  .main_titles{
    text-align: left;
    font-size: 14px;
    color: #999;
    padding-left: 15px;
    margin-top: 15px;
  }
  .main_switchs{
    width: 100%;
    height: 45px;
    padding: 7px 15px;
    font-size: 17px;
    border-bottom: 1px solid #E2E2E2;
  }
  .main_switch{
    width: 100%;
    height: 45px;
    padding: 7px 0;
    margin-left: 15px;
    font-size: 17px;
    border-bottom: 1px solid #E2E2E2;
  }
</style>