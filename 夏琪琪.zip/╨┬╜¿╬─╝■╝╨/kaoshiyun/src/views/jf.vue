<template>
<!-- 积分页面 -->
  <div class="main">
    <div class="qq">
        <div style="font-size:16px;margin-top:30px;">总积分</div>
        <div><span style="color:#F57C00;font-size:26px;">--</span></div>
    </div>
    <div style="font-size: 22px;">积分排名：</div>
    <div style="margin: 25px 0;">
        <div>
            <div style="background-color: #EFF2F5;border: 1px solid #E7E5E5;height: 40px;line-height: 40px;font-size:14px;">积分来源</div>
        </div>
          <div style="display: flex;">
            <div style="display: inline-block;border: 1px solid #E7E5E5;height: 40px;line-height: 40px;flex: 1;font-size:14px;">考试</div>
            <div style="display: inline-block;border: 1px solid #E7E5E5;height: 40px;line-height: 40px;flex: 1;font-size:14px;">练习</div>
            <div style="display: inline-block;border: 1px solid #E7E5E5;height: 40px;line-height: 40px;flex: 1;font-size:14px;">培训</div>
        </div>
          <div style="display: flex;">
            <div style="display: inline-block;border: 1px solid #E7E5E5;height: 40px;line-height: 40px;flex: 1;font-size:14px;">0.00</div>
            <div style="display: inline-block;border: 1px solid #E7E5E5;height: 40px;line-height: 40px;flex: 1;font-size:14px;">0.00</div>
            <div style="display: inline-block;border: 1px solid #E7E5E5;height: 40px;line-height: 40px;flex: 1;font-size:14px;">0.00</div>
        </div>
    </div>
    <div style="text-align: left;font-size: 22px;color: #9999B3;">积分明细</div>
    <div  style="margin: 25px 0;">
        <span style="font-size: 20px;float: left;">无记录</span>
        <span style="height: 20px;background-color: #F57C00;color: white;width: 25px;float: right;border-radius: 25px;">--</span>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>
<style scoped>
.main{
    text-align: center;padding:27px;
}
.qq{
    margin: 25px 0;
    width: 124px;
    height: 124px;
    border-radius: 50%;
    border: 3px solid #F57C00;
    display: inline-block;
    line-height: 30px;
	text-align: center;
}

</style>