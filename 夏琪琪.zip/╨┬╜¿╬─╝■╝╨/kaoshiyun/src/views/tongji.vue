<template>
	<div class="main">
		<div class="footer">
			学习成绩（冼学阳）
		</div>
		<div class="icon-box" style="padding: 26px 0;text-align: center;border-bottom: 1px solid #f8f4f4;">
			<div class="icon-box__ctn">
				<img src="../assets/dui.png" alt="" style="width: 60px;height: 60px;">
			</div>
			<div class="icon-box__ctn" style="margin-left: 18px;">
				<h3 style="font-size: 18px;">已完成课程 ( 100% )</h3>
				<p class="icon-box__desc">共学习 124 分钟</p>
			</div>
		</div>
		<div class="weui-title">
			<div style="font-size:18px;color:#707070;padding-top: 15px;">消息中间件</div>
			<h3 class="chapter-title">第 1 章</h3>
			<div style="color: #000000;">
				<a href="/kcnr" class="weui-media-box" style="width:66%;display:inline-block;color:#2972ab">
					<h4>RabbitMQ消息中间件-1</h4>
					<ul>
						<li>首次学习时间：<span>2020-05-16 9:22:57</span></li>
						<li>最近学习时间：<span>2020-05-20 11:37:14</span></li>
					</ul>
				</a>
				<div style="width: 24%; display: inline-block;float:right;margin-top:10px;">
					<div class="icon-box">
						<i class="fa fa-check-circle" aria-hidden="true" style="font-size:20px;color: #09bb07;float: right;margin-right: 28px;"></i>
						<div class="icon-box__ctn">
							<h3 style="font-size:14px;text-align:center">已完成</h3>                                
							<p class="icon-box__desc" style="text-align:left">已学118分钟</p>
						</div>
					</div>
				</div>
			</div>
			<div style="color: #000000;">
				<a href="/kcnr" class="weui-media-box" style="width:66%;display:inline-block;color:#2972ab">
					<h4>RabbitMQ消息中间件-1</h4>
					<ul>
						<li>首次学习时间：<span>2020-05-16 9:22:57</span></li>
						<li>最近学习时间：<span>2020-05-20 11:37:14</span></li>
					</ul>
				</a>
				<div style="width: 24%; display: inline-block;float:right;margin-top:10px;">
					<div class="icon-box">
						<i class="fa fa-check-circle" aria-hidden="true" style="font-size:20px;color: #09bb07;float: right;margin-right: 28px;"></i>
						<div class="icon-box__ctn">
							<h3 style="font-size:14px;text-align:center">已完成</h3>                                
							<p class="icon-box__desc" style="text-align:left">已学118分钟</p>
						</div>
					</div>
				</div>
			</div>
			<h3 class="chapter-title">第 2 章</h3>
			<div style="color: #000000;">
				<a href="/kcnr" class="weui-media-box" style="width:66%;display:inline-block;color:#2972ab">
					<h4>ActiveMQ消息中间件-1</h4>
					<ul>
						<li>首次学习时间：<span>2020-05-16 9:22:57</span></li>
						<li>最近学习时间：<span>2020-05-20 11:37:14</span></li>
					</ul>
				</a>
				<div style="width: 24%; display: inline-block;float:right;margin-top:10px;">
					<div class="icon-box">
						<i class="fa fa-check-circle" aria-hidden="true" style="font-size:20px;color: #09bb07;float: right;margin-right: 28px;"></i>
						<div class="icon-box__ctn">
							<h3 style="font-size:14px;text-align:center">已完成</h3>                                
							<p class="icon-box__desc" style="text-align:left">已学118分钟</p>
						</div>
					</div>
				</div>
			</div>
			<div style="color: #000000;">
				<a href="/kcnr" class="weui-media-box" style="width:66%;display:inline-block;color:#2972ab">
					<h4>ActiveMQ消息中间件-2</h4>
					<ul>
						<li>首次学习时间：<span>2020-05-16 9:22:57</span></li>
						<li>最近学习时间：<span>2020-05-20 11:37:14</span></li>
					</ul>
				</a>
				<div style="width: 24%; display: inline-block;float:right;margin-top:10px;">
					<div class="icon-box">
						<i class="fa fa-check-circle" aria-hidden="true" style="font-size:20px;color: #09bb07;float: right;margin-right: 28px;"></i>
						<div class="icon-box__ctn">
							<h3 style="font-size:14px;text-align:center">已完成</h3>                                
							<p class="icon-box__desc" style="text-align:left">已学118分钟</p>
						</div>
					</div>
				</div>
			</div>
			<h3 class="chapter-title">第 3 章</h3>
			<div style="color: #000000;">
				<a href="/kcnr1" class="weui-media-box" style="width:75%;display:inline-block;color:#2972ab">
					<h4>消息如何保障 100% 的投递成功方案-1</h4>
					<ul>
						<li>首次学习时间：<span>2020-05-16 9:22:57</span></li>
						<li>最近学习时间：<span>2020-05-20 11:37:14</span></li>
					</ul>
				</a>
				<div style="width: 24%; display: inline-block;float:right;margin-top:10px;">
					<div class="icon-box">
						<i class="fa fa-check-circle" aria-hidden="true" style="font-size:20px;color: #09bb07;float: right;margin-right: 28px;"></i>
						<div class="icon-box__ctn">
							<h3 style="font-size:14px;text-align:center">已完成</h3>                                
							<p class="icon-box__desc" style="text-align:left">已学118分钟</p>
						</div>
					</div>
				</div>
			</div>
			<div style="color: #000000;">
				<a href="/kcnr1" class="weui-media-box" style="width:75%;display:inline-block;color:#2972ab">
					<h4>消息如何保障 100% 的投递成功方案-2</h4>
					<ul>
						<li>首次学习时间：<span>2020-05-16 9:22:57</span></li>
						<li>最近学习时间：<span>2020-05-20 11:37:14</span></li>
					</ul>
				</a>
				<div style="width: 24%; display: inline-block;float:right;margin-top:10px;">
					<div class="icon-box">
						<i class="fa fa-check-circle" aria-hidden="true" style="font-size:20px;color: #09bb07;float: right;margin-right: 28px;"></i>
						<div class="icon-box__ctn">
							<h3 style="font-size:14px;text-align:center">已完成</h3>                                
							<p class="icon-box__desc" style="text-align:left">已学118分钟</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div @click="$router.go(-1)" style="position: fixed; z-index: 0; box-shadow: rgba(15, 66, 76, 0.25) 0px 0px 14px 0px; width: 60px; height: 60px; border-radius: 50%; background-color: gray; left: 10px; bottom: 10px;">
			<a style="position:relative;text-decoration: none; outline: none; font-family: Microsoft Yahei, Arial, Helvetica; color: #fff; font-size: 16px; display: inline-block; margin: 0; padding: 0; border: none; line-height:60px; text-align:center;float:none;width:100%;height:100%;border-radius:50%;">
				<span>返回</span>
			</a>
		</div>
	</div>
</template>

<script>
export default{
	data(){
		return{
			
		}
	}
}
</script>

<style>
.main{
	margin-bottom: 200px;
}
.footer{
	font-size: 30px;
	text-align: center;
	padding: 30px 0;
	border-bottom: 1px solid #ccc;
	background-color: #fafafa;
}
.icon-box__ctn{
	display: inline-block;
	vertical-align: middle; 
	margin-left: 18px;
	text-align: left;
}
.icon-box__desc{
	color: #888888;
	margin-top: 15px;
}
.weui-title{
	margin-left: 30px;
}
.chapter-title{
	margin-top: 50px;
	font-weight: normal;
	font-size: 36px;
	border-left: 8px solid #21cc86;
	padding-left: 16px;
	border-radius: 10px;
}
.weui-media-box{
	text-decoration: none;
}
.weui-media-box ul{
	list-style-type: none;
	font-size: 26px;
}
.weui-media-box ul li{
	margin-bottom: 15px;
	color: #888888;
}
.weui-media-box h4 {
    display: block;
	margin: 20px 0;
	font-size: 28px;
	color: #2972ab;
}
.icon-box i{
	text-align: center;
}
</style>
