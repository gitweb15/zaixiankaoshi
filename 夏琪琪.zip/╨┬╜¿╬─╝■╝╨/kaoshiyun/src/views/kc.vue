<template>
  <div class="main">
    <!-- 课程 -->
    <div class="top3">
      <div style="background-color:#FAFAFA">
        <i class="fa fa-leanpub iconfix" style="margin-top: 10px;"></i>&nbsp;
        我的课程 (<span style="color:red">8</span>)
      </div>
    </div>
    <!-- <span style=" font-size: 17px;">没有了</span> -->
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #00c000;">消</div>
      <div class="kcWz">
        <div class="title">消息中间件</div>
        <div class="time">学时：60 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #2196F3;">J</div>
      <div class="kcWz">
        <div class="title">JAVA其它相关技术</div>
        <div class="time">学时：60 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #079FC6;">商</div>
      <div class="kcWz">
        <div class="title">商城技术2018</div>
        <div class="time">学时：360 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #25C08E;">通</div>
      <div class="kcWz">
        <div class="title">通讯协议</div>
        <div class="time">学时：60 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #74C260;">S</div>
      <div class="kcWz">
        <div class="title">SSM面试题2019版</div>
        <div class="time">学时：60 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #8B8B8B;">微</div>
      <div class="kcWz">
        <div class="title">微服务</div>
        <div class="time">学时：60 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #EC661A;">框</div>
      <div class="kcWz">
        <div class="title">框架技术</div>
        <div class="time">学时：60 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
    <div class="kc" @click="ypt">
      <div class="kcImg" style="background-color: #FF3B30;">分</div>
      <div class="kcWz">
        <div class="title">分布式</div>
        <div class="time">学时：60 分钟</div>
        <div class="time">学分：0.0 分</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },methods:{
    ypt(){
      this.$router.push("/ypt")
    }
  }
};
</script>
<style scoped>
.top3 div {
  display: inline-block;
  width: 100%;
  height: 100px;
  line-height: 100px;
  border-bottom: 1px solid #e2e2e2;
  text-align: center;
  font-size: 30px;
}
.kc {
  text-align: left;
  padding: 18px;
  height: 120px;
  border-bottom: 1px solid #f5f5f5;
}
.kcImg {
  width: 120px;
  height: 120px;
  display: inline-block;
  text-align: center;
  line-height: 120px;
  font-size: 32px;
  color: white;
  margin-right: 15px;
}
.kcWz {
  display: inline-block;
  vertical-align: top;
}
.title {
  font-size: 33px;
}
.time {
  font-size: 15px;
  color: #999999;
}
</style>