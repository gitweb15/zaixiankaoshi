<template>
  <div class="main">
    <div class="top3">
      <div style="background-color:#FAFAFA">
        <i class="fa fa-map-o iconfix" style="margin-top: 10px;"></i>
         我的练习 (<span style="color:red;">6</span>)
      </div>
    </div>
	<div class="clearfix" v-for="(item,index) in title" :key="index" @click="clearfix3_btn(index)">
		<div class="clearfix1">{{item.name}}</div>
		<div class="clearfix2">
			<p>有效时间：从<span>04-06 08:26 至 10-13 08:26</span></p>
			<span class="exerType">模拟练习</span>
		</div>
		<div class="clearfix3">
			<ul class="clearfix3_ul" >
				<li class="clearfix3_li1">及格/总分：<span id="passScore">60</span>/<span id="paperScore">100</span>分</li>
				<li class="clearfix3_li2 clearfix3_border">限 <span id="attendTimes" style="color:red">100</span> 次</li>                            
				<li class="clearfix3_li3" style="display: list-item;padding: 0 13px;">已练习 <span id="attendedTimes" style="color:red">1</span> 次</li>
			</ul>
		</div>
	</div>
	<!-- <span style=" font-size: 17px;">没有了</span> -->
  </div>
</template>
<script>
export default {
  data() {
    return {
		title:[
			{name:'消息队列练习'},
			{name:'SSO练习'},
			{name:'Redis练习'},
			{name:'SSM面试题2019'},
			{name:'SpringCloud练习'},
			{name:'Nginx随机练习'}
		]
	}
	
  },
  methods:{
  	clearfix3_btn(idx){
		let vanida=this.title[idx].name
		localStorage.setItem("name",vanida);
		this.$router.push("ksks")
		console.log("123")
  	}
  },
  created(){
	  // localStorage.setItem("isChanges","3")
	  console.log('奠基石3')
  }
};
</script>
<style scoped>
	
.top3 div {
  display: inline-block;
  width: 100%;
  height: 100px;
  line-height: 100px;
  font-size: 30px;
  border-bottom: 1px solid #E2E2E2;
  text-align: center;
}
.clearfix{
	height: 200px;
	margin: 15px 0 15px 25px;
	padding-right: 15px;
	border-bottom: 1px solid #e5e5e5;
}
.clearfix1{
	height: 50px;
	font-size: 33px;
	margin: 15px 0 8px;
	padding-top: 15px;
}
.clearfix2{
	display: flex;
	height: 30px;
	font-size: 18px;
	color: #999999;
	margin-top: 10px;
}
.clearfix2 p{
	width: 80%;
}
.clearfix2 .exerType{
	text-align: right;
	line-height: 30px;
	padding: 0 8px;
	font-size: 16px;
	border-radius: 18px;
	background: rgb(83, 164, 244);
	color: #FFFFFF;
}
.clearfix3{
	height: 23px;
	padding: 15px 0 5px;
	color: #cecece;
}
.clearfix3 ul{
	display: flex;
	list-style-type: none;
	margin-top: 15px;
	padding-bottom: 5px;
	font-size: 18px;
}
.clearfix3_li1{
	padding-right: 13px;
}
.clearfix3_li2,.clearfix3_li3{
	padding: 0 13px;
}
.clearfix3_border{
	border-right: 1px solid #e2e2e2;
	border-left: 1px solid #e2e2e2;
}
</style>