<template>
	<div class="main">
		<div class="top" v-if="id==1">消息队列练习</div>
		<h2 v-if="id==1" style="margin-top: 30px;padding-left:5%;font-size: 20px;">第1大题(共10题,100.00分)</h2>
		<div class="body" v-for="(item,index) in list" :key="index" v-if="id==1">
			<p class="body_title"><span>{{item.id}}.</span>
				{{item.name}}? (问答题,10.0分)
			</p>
			<div>
				<textarea rows="10" cols="40"/>
			</div>
			<button class="btn" v-if="currentActive != index"  @click="currentActive = index">查看答案</button>
			<div v-if="currentActive == index" class="hides">
				<!-- <span>X</span>答错了<br>
				得分: <span>0.0</span>分<br> -->
				标准答案:<br>
				消息提供方->路由->-至多个队列消息发布到交换器时,消
				息将拥有一个路由键(routing key),在消息创建时设定。通
				过队列路由键,可以把队列绑定到交换器上。消息到达交换
				器后,RabbitMQ会将消息的路由键与队列的路由键进行匹配
				(针对不同的交换器有不同的路由规则);常用的交换器主要
				分为以下三种: fanout:如果交换器收到消息，将会广播到所有
				绑定的队列上direct:如果路由键完全匹配,消息就被投递到
				相应的队列topic:可以使来自不同源头的消息能够到达同一
				个队列。使用topic交换 器时,可以使用通配符。

			</div>
		</div>
		<div v-if="id==2">
			<div class="top">
				▦&nbsp;答题卡
			</div>
			<div style="padding: 8px 8px 8px 20px;">
				第 1 大题<br />
				<a class="tishu" style="border: solid 1px #bababc;" v-for="(a,index) in list" :key="index">
					{{a.id}}
				</a>
			</div>
		</div>
		<div style="margin-top: 20%;"></div>
		<div class="bottom">
			<a href="#" v-if="id==1" @click="id=2" class="bottom-item" style="border-right: #e2e1e1 1px solid;color: #000000;background-color: #e5e5e5;">答题卡</a>
			<a href="#" v-if="id==2" @click="id=1" class="bottom-item" style="border-right: #e2e1e1 1px solid;color: #000000;background-color: #e5e5e5;">返回到试卷</a>
			<a href="#" class="bottom-item" style="background-color: #e64240;color: white;" @click="commit">交卷<span style="font-size: 12px;margin-left: 10px;">{{minutes}}分{{seconds}}秒</span></a>
		</div>
	</div>
</template>

<script>
	import { MessageBox } from 'mint-ui';
	export default{
		data(){
			return{
				list:[
					{id:1,name: '消息怎么路由'},
					{id:2,name: '什么是应用解耦'},
					{id:3,name: '什么是异步处理'},
					{id:4,name: '消息如何分发'},
					{id:5,name: 'activemq的几种通信方式'},
					{id:6,name: '日志收集系统的消息中间件介绍'},
					{id:7,name: '如何设置消息的过期时间'},
					{id:8,name: '消息基于什么传输'},
					{id:9,name: '三种广播模式'},
					{id:10,name: '如何指定消息的优先级'},
				],
				value: null,
				minutes: 60,
				seconds: 0,
				id: 1,
				currentActive: -1
			}
		},
		methods: {
			commit(){
				console.log("123")
				MessageBox({
				  title: '',
				  message: '确认交卷吗?',
				  showCancelButton: true
				});
				MessageBox.confirm('确认交卷吗?').then(action => {
				  this.$router.push('/jjcg')
				});
			},
			// 倒计时
			num(n) {
				return n < 10 ? '0' + n : '' + n
			},
			timer() {

				var _this = this
				var time = setInterval(function() {
					if (_this.seconds === 0 && _this.minutes !== 0) {
						_this.seconds = 59
						_this.minutes -= 1
					} else if (_this.minutes === 0 && _this.seconds === 0) {
						_this.seconds = 0
						clearInterval(time)
					} else {
						_this.seconds -= 1
					}
				}, 1000)
			}
		},
		mounted() {
			this.timer()
		},
		watch: {
			second: {
				handler(newVal) {
					this.num(newVal)
				}
			},
			minute: {
				handler(newVal) {
					this.num(newVal)
				}
			}
		},
	}
</script>

<style>
	a{
		text-decoration: none;
	}
	.top{
		width: 95%;
		height: 156px;
		border-bottom: 1px solid #e5e5e5;
		font-size: 45px;
		line-height: 156px;
		padding-left: 5%;
	}
	.body_title{
		font-size: 32px;
		font-weight: bold;
		margin-top: 15px;
		margin-bottom: 20px;
	}
	.body_title span{
		color: #2b71c7;
	}
	.body{
		margin-left: 5%;
		margin-right: 5%;
	}
	.btn{
		width: 256px;
		height: 82px;
		background: #1aac19;
		color: #FFFFFF;
		border-radius: 20px;
		border: 0;
		margin: 20px 0;
	}
	.bottom {
			text-align: center;
			background: #fff;
			border: #e2e1e1 1px solid;
			width: 100%;
			position: fixed;
			right: 0;
			z-index: 500;
			bottom: 0;
		}
	
		.bottom-item {
			color: #808080;
			width: 49%;
			display: block;
			float: left;
			padding: 30px 0;
		}
	
		.tishu {
			display: inline-block;
			line-height: 45px;
			width: 50px;
			text-align: center;
			margin-right: 12px;
			border-radius: 50%;
			
			padding: 30px;
			margin-bottom: 50px;
		}
		.hides{
			background-color: #fdedf0;
			padding: 15px;
		}
		.hides span{
			color: #c5182b;
		}
</style>
