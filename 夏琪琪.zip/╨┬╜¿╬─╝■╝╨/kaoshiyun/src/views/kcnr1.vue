<template>
	<div>
		<header style="max-width:1000px;margin:0 auto;height:47px">
			<div class="newheader">
				<a @click="$router.go(-1)" class="left"><i></i><span>返回</span></a>
				<a href="../tongji" class="right"><i></i><span>统计</span></a>
			</div>
		</header>
		<div style="height: 47px;"></div>
		<div>
			<video src="http://oss.kaoshiyun.com.cn/File/331460/les/34c12a/ef52c6/ef52c6.mp4" controls="controls" controlslist="nodownload"
			 autoplay="autoplay" style="width: 100%;" webkit-playsinline="true" playsinline="true" preload="metadata">
				您的浏览器不支持HTML5视频
			</video>
		</div>
		<mt-popup v-model="popupVisible" position="bottom" style="width: 100%;">
			<div style="padding: 15px;font-size: 16px;">
				<div>
					<p style="margin-bottom: 20px;">第 1 章</p>
					<div class="kc" @click="tokcnr">
						<i class="fa fa-align-left"></i>
						<a href="#"> 1.1 RabbitMQ消息中间件-1</a>
					</div>
					<div class="kc" @click="tokcnr">
						<i class="fa fa-align-left"></i>
						<a href="#"> 1.2 RabbitMQ消息中间件-2</a>
					</div>
				</div>
				<div>
					<p style="margin-bottom: 20px;">第 2 章</p>
					<div class="kc" @click="tokcnr">
						<i class="fa fa-align-left"></i>
						<a href="#"> 2.1 ActiveMQ消息中间件-1</a>
					</div>
					<div class="kc" @click="tokcnr">
						<i class="fa fa-align-left"></i>
						<a href="#"> 2.2 ActiveMQ消息中间件-2</a>
					</div>
				</div>
				<div>
					<p style="margin-bottom: 20px;">第 3 章</p>
					<div class="kc" @click="tokcnr1">
						<i class="fa fa-play"></i>
						<a href="#"> 3.1 消息如何保障 100% 的投递...</a>
					</div>
					<div class="kc" @click="tokcnr1">
						<i class="fa fa-play"></i>
						<a href="#"> 3.2 消息如何保障 100% 的投递...</a>
					</div>
				</div>
			</div>
		</mt-popup>
		<div style="padding: 0 20px;">
			<p style="font-weight: bold;margin: 5px 0 10px;font-size: 14px;">消息如何保障 100% 的投递成功方案-1</p>

		</div>
		<div style="height: 47px;"></div>
		<div class="bottom">
			<a href="#" @click="zhezhao" class="bottom-item" style="border-right: #e2e1e1 1px solid;background: #ff2d50;">课程目录</a>
			<a href="../kcnr" class="bottom-item" @click="id=2" style="background: #21cc86;">保存记录&下一章</a>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				popupVisible: false
			}

		},
		created() {

		},
		methods: {
			zhezhao() {
				this.popupVisible = true
			},
			tokcnr() {
				this.$router.push('/kcnr')
			},
			tokcnr1() {
				this.$router.push('/kcnr1')
			}
		}
	}
</script>

<style scoped>
	a{
		text-decoration: none;
	}
	header {
	    width: 100%;
	    height: 2.4rem;
	    display: flex;
	    flex-direction: column;
	    justify-content: center;
	    position: fixed;
	    align-items: center;
	    top: 0;
	    padding-left: .6rem;
	    padding-right: .6rem;
	    background: #fff;
	    z-index: 99999;
	    box-sizing: border-box;
	    color: #000;
	    background: #fff;
	    border-bottom: 1px solid #eee;
	}
	header .newheader {
	    width: 100%;
	    color: #fff;
	}
	.newheader .left {
	    color: #000;
	    font-size: 30px;
	    line-height: 45px;
	    width: 45%;
	    overflow: hidden;
	}
	.newheader .left i {
	    background: url(../assets/back.png) no-repeat;
	    width: 45px;
	    height: 45px;
	    display: inline-block;
	    vertical-align: middle;
	}
	.newheader .right {
	    color: #000;
	    text-align: right;
	    font-size: 30px;
	    line-height: 45px;
	    float: right;
	}
	.newheader .right i {
	    background: url(../assets/analysis.png) no-repeat;
	    width: 45px;
	    height: 45px;
	    display: inline-block;
	    vertical-align: middle;
	    margin-right: 5px;
	}
	.kc {
		box-shadow: 0 0.05rem 0.2rem 0.05rem #e0e3e6;
		border-radius: .25rem;
		height: 1rem;
		line-height: 1rem;
		margin-bottom: .4rem;
		padding: 0 .5rem 0 .6rem;
		font-size: 35px;
	}
	
	.kc a {
		color: #71777d;
	}
	.bottom {
		text-align: center;
		background: #fff;
		border: #e2e1e1 1px solid;
		width: 100%;
		position: fixed;
		z-index: 500;
		bottom: 0;
	}
	
	.bottom-item {
		color: white;
		width: 49%;
		display: block;
		float: left;
		padding: 30px 0;
	}
	
</style>
