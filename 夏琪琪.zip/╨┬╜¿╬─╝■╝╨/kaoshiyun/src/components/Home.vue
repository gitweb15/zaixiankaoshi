<template>
  <div class="home">
 <router-view/>
 <div style="height: 100px;"></div>
  <div class="tab">
    <div class="tabson" @click="sy(1)" :class="{ isActive:id == 1}">
  <i class="fa fa-home"></i><br/>
    首页
    </div>
    <div class="tabson" @click="ks(2)" :class="{ isActive:id == 2}">
  <i class="fa fa-map-o iconfix" ></i><br/>
    考试
    </div>
    <div class="tabson" @click="lx(3)" :class="{ isActive:id == 3}">
  <i class="fa fa-map iconfix" ></i><br/>
    练习
    </div>
    <div class="tabson" @click="kc(4)" :class="{ isActive:id == 4}">
  <i class="fa fa-leanpub iconfix" ></i><br/>
    课程
    </div>
  </div>

  </div>
</template>

<script>


export default {
  data(){
    return{
      
    }
  },methods:{
		sy(id) {
			this.$router.push("/sy")
			this.$store.commit("isActive",id)
		},
		ks(id) {
			this.$router.push("/ks")
			this.$store.commit("isActive",id)
		},
		lx(id) {
			this.$router.push("/lx")
			this.$store.commit("isActive",id)
		},
		kc(id) {
			this.$router.push("/kc")
			this.$store.commit("isActive",id)
		}
  },
  computed:{		
	id(){
		return this.$store.state.id
	}
  }
} 
</script>
<style scoped>
.tab{
  display: flex;
  border-top: 1px solid #E2E2E5;
  position: fixed;
  bottom: 0;
  background-color:white;
  width: 100%;
  text-align: center;
  
}
.tabson{
  flex: 1;
  color: #999999;
  padding: 10px 0;
}
.tabson i{
	font-size: 50px;
}
.isActive{
      color: #1C87D5;
}

</style>