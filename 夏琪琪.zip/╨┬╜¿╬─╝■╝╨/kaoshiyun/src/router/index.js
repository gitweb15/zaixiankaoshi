import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../components/Home.vue'

Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,//底部导航栏
    redirect: '/login',
    children:[
      {
        path: 'sy',
        name: 'sy',
        component: () => import('../views/sy.vue')//首页
      },{
        path: 'ks',
        name: 'ks',
        component: () => import('../views/ks.vue')//我的考试
      },{
        path: 'lx',
        name: 'lx',
        component: () => import('../views/lx.vue')//我的练习
      },{
        path: 'kc',
        name: 'kc',
        component: () => import('../views/kc.vue')//我的页面课程
      },{
        path: 'jf',
        name: 'jf',
        component: () => import('../views/jf.vue')//我的积分
      },{
        path: 'cj',
        name: 'cj',
        component: () => import('../views/cj.vue')//考试成绩
      },{
        path: 'ctb',
        name: 'ctb',
        component: () => import('../views/ctb.vue')//错题本
      },{
        path: 'xgmm',
        name: 'xgmm',
        component: () => import('../views/xgmm.vue')//修改密码
      }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/login.vue')//登录
  },
  {
    path: '/ksks',
    name: 'ksks',
    component: () => import('../views/ksks.vue')//开始考试
  },
  {
    path: '/ypt',
    name: 'ypt',
    component: () => import('../views/ypt.vue')//开始考试
  },
  {
    path: '/ksnr',
    name: 'ksnr',
    component: () => import('../views/ksnr.vue')//开始考试
  },
  {
    path: '/jjcg',
    name: 'jjcg',
    component: () => import('../views/jjcg.vue')//开始考试
  },
  {
    path: '/ksshiti',
    name: 'ksshiti',
    component: () => import('../views/ksshiti.vue')//开始考试
  },
  {
    path: '/ksshi',
    name: 'ksshi',
    component: () => import('../views/ksshi.vue')//开始考试
  },
  {
    path: '/tongji',
    name: 'tongji',
    component: () => import('../views/tongji.vue')//开始考试
  },
  {
    path: '/kcnr',
    name: 'kcnr',
    component: () => import('../views/kcnr.vue')//开始考试
  },
  {
    path: '/kcnr1',
    name: 'kcnr1',
    component: () => import('../views/kcnr1.vue')//开始考试
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
