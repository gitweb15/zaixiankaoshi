import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
	  id:1,
	  name:null
  },
  mutations: {
	  isActive(state,id){
		  state.id=id
		  console.log(state.id)
	  },
	  showname(state,name){
		  if(name!=''){
			  state.name=name
		  }
	  }
  },
  actions: {
  },
  modules: {
  }
})
