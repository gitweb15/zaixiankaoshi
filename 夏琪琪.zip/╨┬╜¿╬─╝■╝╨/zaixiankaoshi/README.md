# 在线考试系统
```
方震、胡振华、夏琪琪
```
## 拉取依赖
```
npm install
```

### 运行项目
```
npm run serve
```

### 打包
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
