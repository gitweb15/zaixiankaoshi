import Mock from 'mockjs';

const login = Mock.mock(
  '/api/login','get',(req, res) => {
    return {
      data: {
        name: 'admin',
        password: 123
      },
      message: '查询成功'
    }
  })

export default {
  login
}