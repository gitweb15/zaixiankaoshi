<template>
  <div class="Upgrade">
      <Header></Header>
      <div class="append-box">
          <h4>请根据您的需求选择配置，自定义弹性购买 
              <span style="font-size:13px;color:red;display:none"><i class="fa fa-volume-up"></i> </span>
              <span style="color: #808080;float:right;font-size:12px;margin-right:14px;" title="185 7310 3286">
                  购买咨询：<a style="color:#0275d8"><i class="fa fa-phone" style="display:"></i> 185 7310 3286</a>
                  <a style="color:#0275d8" href="http://wpa.qq.com/msgrd?v=3&amp;uin=240349944&amp;site=qq&amp;menu=yes" target="_blank" title="QQ:240349944">
                  <i class="fa fa-qq"></i> 240349944</a>
            </span>
            </h4>
            <div class="form-group">
                <label class="control-label">请选择版本</label>
                <div class="areaselect">
                    <span style="background-color: #1c87d5;color: #fff;" >考试版</span>
                    <span class="active">考试培训版</span>
                    <i class="tooltips" swidth="400"><a href="#" style="padding:0px 10px 0px 30px;line-height:30px;color:#0275d8"> <i class="fa fa-hand-o-right"></i> 教我选择 </a></i>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">请选择付费模式</label>
                <div class="areaselect">
                    <span style="background-color: #1c87d5;color: #fff;" >一个月</span>
                    <span class="active">二个月</span>
                    <span class="active">三个月</span>
                    <span class="active">四个月</span>
                    <span class="active">五个月</span>
                    <span class="active">六个月</span>
                    <span class="active">1年</span>
                    <span class="active">2年</span>
                    <span class="active">3年</span>
                    <i class="tooltips" swidth="400"><a href="#" style="padding:0px 10px 0px 30px;line-height:30px;color:#0275d8"> <i class="fa fa-hand-o-right"></i> 教我选择 </a></i>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">请选择同时在线人数</label>
                <div class="areaselect">
                    <select class="form-control" style="width:110px;display:inline-block">
                        <option value="50">50 (人)</option>
                        <option value="100" selected="selected">100 (人)</option>
                        <option value="150">150 (人)</option>
                        <option value="200">200 (人)</option>
                        <option value="250">250 (人)</option>
                        <option value="300">300 (人)</option>
                        <option value="350">350 (人)</option>
                        <option value="400">400 (人)</option>
                        <option value="450">450 (人)</option>
                        <option value="500">500 (人)</option>
                        <option value="550">550 (人)</option>
                        <option value="600">600 (人)</option>
                        <option value="650">650 (人)</option>
                        <option value="700">700 (人)</option>
                        <option value="750">750 (人)</option>
                        <option value="800">800 (人)</option>
                        <option value="850">850 (人)</option>
                        <option value="900">900 (人)</option>
                        <option value="950">950 (人)</option>
                        <option value="1000">1000 (人)</option>
                    </select>
                    <i class="tooltips" swidth="400"><a href="#" style="padding:0px 10px 0px 30px;line-height:30px;color:#0275d8"> <i class="fa fa-hand-o-right"></i> 教我选择 </a></i>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">请选择考生账号个数</label>
                <div class="areaselect">
                    <select class="form-control" style="width:110px;display:inline-block">
                        <option value="100" >100 (个)</option>
                        <option value="200">200 (个)</option>
                        <option value="300">300 (个)</option>
                        <option value="400" selected="selected">400 (个)</option>
                        <option value="500">500 (个)</option>              
                        <option value="600">600 (个)</option>
                        <option value="700">700 (个)</option>
                        <option value="800">800 (个)</option>
                        <option value="900">900 (个)</option>
                        <option value="1000">1000 (个)</option>
                        <option value="1100">1100 (个)</option>
                        <option value="1200">1200 (个)</option>
                        <option value="1300">1300 (个)</option>
                        <option value="1400">1400 (个)</option>
                        <option value="1500">1500 (个)</option>
                        <option value="1600">1600 (个)</option>
                        <option value="1700">1700 (个)</option>
                        <option value="1800">1800 (个)</option>
                        <option value="1900">1900 (个)</option>
                        <option value="1000">2000 (个)</option>
                    </select>
                    <i class="tooltips" swidth="400"><a href="#" style="padding:0px 10px 0px 30px;line-height:30px;color:#0275d8"> <i class="fa fa-hand-o-right"></i> 教我选择 </a></i>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">请选择考生账号个数</label>
                <div class="areaselect">
                   <label style="font-size: 15px;">
                        <input type="checkbox" class="checkboxCtrl">
                        需要多个子管理员账号 
                    </label>
                    <i class="tooltips" swidth="400"><a href="#"> <i class="fa fa-hand-o-right"></i> 教我选择 </a></i>
                </div>
            </div>
            <fieldset>
            <div class="form-group">
                <label class="control-label">选择支付方式 <i class="fa fa-question-circle-o tooltips" stitle="建议使用在线支付完成付款并及时开通，如果使用线下汇款，<br/>请在下单汇款后联系我们，我们会以最快速度为您确认并开通。"></i></label>
                <div class="col-sm-8" style="margin-top:10px;">
                    <span style="padding:15px 15px;border:1px solid #eee;margin-right:10px;">                        
                        <label for="rdAlipay" style="cursor:pointer"><input type="radio" name="rdPaymentType" id="rdAlipay" value="Alipay">  <img style="vertical-align: middle;" src="../../assets/alipay.png" alt=""></label>
                    </span>
                    <span style="padding:15px 15px;border:1px solid #eee;margin-right:10px;">                        
                        <label for="rdTransfer" style="cursor:pointer"><input type="radio" name="rdPaymentType" id="rdTransfer" value="Transfer">  <img style="vertical-align: middle;" src="../../assets/transfer.png" alt=""></label>
                    </span>
                </div>
            </div>
        </fieldset>
        <fieldset>
         <div class="form-group">
            <label class="control-label">发票信息</label>
            <div class="areaselect">
                <label style="font-size: 15px;">
                    <input type="checkbox" class="checkboxCtrl">
                    需要发票 
                </label>
            </div>
        </div>
        </fieldset>
        <fieldset>
         <div class="form-group">
            <label class="control-label">优惠码</label>
            <div class="areaselect">
                <label style="font-size: 15px;">
                    <input type="checkbox" class="checkboxCtrl">
                    使用优惠码 
                </label>
                <i class="tooltips" swidth="400"><a href="#" style="color: #5e5e5e;padding:0px 10px 0px 30px;line-height:30px;">如何获得优惠码? </a></i>
            </div>
        </div>
        </fieldset>
      </div>
      <div class="bottom" style="padding:10px 5px;">
            <div id="divConfigInfo" style="float: left; margin-top: 10px; margin-left: 10%; font-size: 14px; color: rgb(94, 94, 94); text-align: left;">            
                您选择的配置：<br>
                在<em class="config_num" id="config_duration">1</em> 个月内，可给 <em id="config_usercount" class="config_num">400</em> 位考生安排<span id="versionTypeName">考试、练习</span>(不限答题次数)，允许 <em id="config_onlinecount" class="config_num">100</em> 人同时在线。
            </div>
            <div style="float:right;margin-right:10%;font-size:18px;">
                合计：<span style="font-size:24px;color:#f57c00">￥ <span id="amount">328</span></span> <br>
                <span style="font-size:13px;color:green;float:right;margin-right:8px;margin-top:-20px;display:none">省：￥ <span id="discountAmount">230.00</span></span>
                <button id="btnConfirmOrder" class="btn btn-default" style="background:#4caf50;color:#fff;border:none;padding:10px 35px;margin-bottom:10px;margin-top:10px;float:right"><i class="fa fa-yen" aria-hidden="true"></i>   <span>使用支付宝支付</span></button>  <br>
            </div>
        </div>
  </div>
</template>

<script>
import Header from '@/components/Header/index.vue'
export default {
  components:{Header},
  name: 'Upgrade',
  data(){
    return{
      
    }
  }

}
</script>


<style scoped lang="scss">
.Upgrade{
    margin-bottom: 200px;
}
.append-box {
    width: 80%;
    border-radius: 3px;
    border: 1px solid #e6e9ee;
    background-color: #fff;
    color: #333333;
    font-size: 12px;
    margin: 30px auto;
    
}
.append-box h4 {
    height: 40px;
    line-height: 40px;
    text-indent: 20px;
    font-size: 16px;
    color: #555;
    margin-bottom: 25px;
}
.form-group{
    height: 40px;
    display: flex;
    margin-bottom: 25px;
    
}
.append-box .control-label {
    font-weight: 500;
    color: #777;
    width: 200px;
    padding: 7px 0 0 15px;
    font-size: 13px;
}
.areaselect{
    display: flex;
    width: 698px;
    height: 30px;
}
.areaselect span{
    display: inline-block;
    text-align: center;
    padding: 6px 12px;
    border: 1px solid #1c87d5;
    height: 30px;
}
.active{
    margin-left: 5px;
    color: #5e5e5e;
}
.form-control {
    padding-left: 5px;
    border-color: #dbd9d9;
    font-size: 13px;
}
.checkbox label {
    padding-left: 20px;
    font-weight: 400;
    cursor: pointer;
    margin-top: 20px;
}    
.checkboxCtrl{
margin-top: 10px;
}
fieldset{
    border: 0;
}
.tooltips a{
    padding:0px 10px 0px 30px;
    line-height:30px;
    color:#5e5e5e;
}

.tooltips:hover{
    color: #0275d8;
}
 .bottom {
    display: inline-block;
    padding: 6px 0 6px 0;
    width: 100%;
    text-align: center;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 11;
    background: #f8f8f8;
    border-top: 1px solid #eee;
}
.config_num {
    color: #f57c00;
    font-style: italic;
    font-size: 16px;
    font-weight: bold;
}
</style>
