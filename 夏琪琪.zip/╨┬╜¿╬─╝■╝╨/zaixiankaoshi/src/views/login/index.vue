<template>
  <div class="login">
    <img width="100%" height="100%" src="http://www.kaoshiyun.com.cn/Custom/Ultimate/style/images/login/3.jpg" style="position:absolute; left:0; top:0; z-index:-1;"/>
    <div class="login_my">
      <div class="top">
        <a href='http://www.kaoshiyun.com.cn'><img src="http://www.kaoshiyun.com.cn/Custom/Ultimate/style/images/logo1.png" /></a>
      </div>
      <div class="lock-holder">
      <div class="form-group input-user">        
          <label>账号</label>
          <input name="account" v-model="FormGroup.user"  class="input-text" title="请输入注册邮箱" placeholder="请输入注册邮箱..." value="" required>          
      </div>
      <div class="avatar"><img src="http://www.kaoshiyun.com.cn/Custom/Ultimate/style/images/login/admin.png" alt=""></div>
      <div class="form-group input-pass">
          <label>密码</label>
          <input name="password" v-model="FormGroup.pass" id="password" class="input-text" type="password" required pattern="[\S]{6}[\S]*" title="密码不少于6个字符">
      </div>
    </div>
      <div class="submit">
        <Button type="primary" @click="login" class="but">登录</Button>
      </div>
      <div id="lAutoLogin" style="text-align:center;margin-top:15px;color:#fff;font-size:12px;height:14px;">
        <input id="chkAutoLogin" type="checkbox" style="height:12px;" checked>
        <label for="chkAutoLogin">下次自动登录</label>
      </div>
      <div class="submit2">
        <input class="input-button1 btn-submit1" style="font-size:12px;" @click="modals=true" type="button" value="忘记密码">
        <input class="input-button1 btn-submit1" style="font-size:12px;" @click="$router.push('/register')" type="button" value="免费注册">
      </div>
    <div class="bottom">
        <h5>Copyright &nbsp;&copy; 2013-2019 <a href='http://www.kaoshiyun.com.cn'>考试云</a></h5>
    </div>
    </div>
    <Modal v-model="modals" title="忘记密码" footer-hide>
		<input type="text" class="form-control required" autocomplete="off" placeholder="请输入您的注册邮箱..." />
		<div style="margin-top: 100px;text-align: center;">
			<button class="btn btn-org" type="submit">找回密码</button>
		</div>
	</Modal>
    
  </div>
</template>

<script>
import axios from "axios"
export default {
  name: 'login',
  data(){
    return{
      FormGroup:{
        user:'',//账号
        pass:'',//密码
      },
	  modals: false
    }
  },
  methods:{
    login(){//登陆方法
       axios.get("/api/login").then(res=>{
      console.log("12",res.data.data)
        if(this.FormGroup.user!="" && this.FormGroup.pass!=""){
           if(this.FormGroup.user==res.data.data.name && this.FormGroup.pass==res.data.data.password){
              this.$router.push("/Home")
            }else{
              alert("账户或密码不匹配")
            }
        }else{
          alert("账户或密码不能为空")
        }
      })
    }
  },
  created(){
   axios.get("http://122.112.179.240:9005/api/masterData/getAllTemplate?pageNum=1&pageSize=10").then(res=>{
     console.log("00-",res)
    })
	 fetch("http://122.112.179.240:9005/api/masterData/getAllTemplate?pageNum=1&pageSize=10",{
	      method:'GET',
	      headers:{ 'Content-Type': 'application/json' },
	      //body: JSON.stringify({key:value}), //POST传参方式
	      credentials: 'include' //允许携带cookie
	    })//fetch返回的是promise对象。所以fetch().then()第一个then里返回的并不是真正的数据。而是一个promise，所以我们需要通过链式操作第二个then()来获取真正的数据。
	    .then(res => {
	        return res.json();
	    })
	    .then(res => {
	      // 这里返回的数据就是我们想要请求的json数据
	      if(res.message == "OK") {
	        console.log(res.responseBody.list);
	      }
	    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.login{
  background-size: cover;
  width: 100%;
  height: 100%;
  
}
.login_my{  
    width: 700px;
    margin: -200px auto auto -340px;
    position: absolute;
    top: 50%;
    left: 50%;

}
.top{
    color: #FFF;
    text-shadow: 1px 1px 0 rgba(0,0,0,.25);
    text-align: center;
    width: 100%;
    height: 80px;
    margin: 0 auto 8%;
}
.input-user{
  width: 100%;
}
.lock-holder{
    width: 100%;
    margin: 0 auto;
    // background: red;
    display: flex;
    .form-group{
      width: 250px;
      height: 40px;
      position: relative;
      z-index: 1;
      flex-direction: row;
      // background: blue;
    }
    .input-pass,.avatar{
      margin-left: 73px;
    }
    input{
      font-size: 14px;
      color: #fff;
      height: 28px;
      padding: 5px 6px;
      background: #2d2d2d;
      background: rgba(45,45,45,.15);
      border: 1px solid #3d3d3d;
      border: 1px solid rgba(255,255,255,.15);
      -moz-border-radius: 5px;
      -webkit-border-radius: 5px;
      border-radius: 5px;
      -moz-box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
      -webkit-box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
      box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
    }
    .input-text{
        width: 228px;
        height: 40px;
        padding-left: 56px;
    }
    label{
      font-size: 14px;
      font-weight: 600;
      line-height: 20px;
      color: #FFF;
      display: block;
      height: 20px;
      padding-right: 10px;
      border-right: dotted 1px #FFF;
      position: absolute;
      z-index: 9;
      top: 10px;
      left: 10px;
    }
}
.submit{
  width: 700px;
  height: 40px;
  margin-top: 34px;
  text-align: center;
  .but{
    width: 100px;
    height: 40px;
    background: #ef4300;
    border: 0;
  }
}
.submit2{
  margin-top: 5%;
  text-align: center;
  input{
    font-size: 14px;
    color: #fff;
    height: 28px;
    padding: 5px 6px;
    background: #2d2d2d;
    background: rgba(45,45,45,.15);
    border: 1px solid #3d3d3d;
    border: 1px solid rgba(255,255,255,.15);
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    -moz-box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
    -webkit-box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
    box-shadow: 0 2px 3px 0 rgba(0,0,0,.1) inset;
  }
}
.bottom {
    line-height: 16px;
    color: #FFF;
    text-shadow: 1px 1px 0 rgba(0,0,0,.25);
    width: 600px;
    margin-left: -300px;
    position: fixed;
    left: 50%;
    h5{
      display: block;
      font-size: 0.83em;
      margin-block-start: 1.67em;
      margin-block-end: 1.67em;
      margin-inline-start: 0;
      margin-inline-end: 0;
      font-weight: bold;
      text-align: center;
    }
    a{
      color: #FFF;
      text-decoration: none;
    }
    a:hover{
      color: chartreuse;
    }
}
.btn-org {
	    padding: 8px 20px;
	    height: 35px;
	    line-height: 1em;
	    border-radius: 3px;
	    color: #fff;
	    border: none;
	    cursor: pointer;
	    background-color: #ff8000;
	}
	.form-control {
		display: block;
		width: 100%;
		height: 34px;
		padding: 6px 12px;
		font-size: 14px;
		line-height: 1.42857143;
		color: #555;
		background-color: #fff;
		background-image: none;
		border: 1px solid #ccc;
		border-radius: 4px;
		box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
		transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
	}

</style>
