<template>
    <div class="syle">
     <!-- 批量导入试题 -->
        <Modal
            v-model="modal4"
            @on-cancel="oncancel"
            title="批量导入试题"
            width="944"
            >
            <div class="nav">
                <div class="fieldset">
                    <label class="control-labels">模板下载</label>
                    <div class="exportType">
                        <a href="#" target="_blank"><i class="fa fa-file-excel-o"></i>   下载Excel模板</a>
                        <a href="#" target="_blank"><i class="fa fa-file-word-o"></i>   下载Word模板</a>
                        <a href="#" target="_blank"><i class="fa fa-file-text-o"></i>   下载txt模板</a>
                    </div>
                </div>
                <div class="fieldset">
                    <label class="control-labels">试题分类</label>
                    <div class="input-group">
                        <input name="txtTreeName" type="text" placeholder="请选择一个分类，试题将导入到此分类下" class="form-control" size="30">
                        <div class="input_but">
                            <button type="button" class="btn btn-default" data-toggle="dropdown">选择</button>
                        </div>
                    </div>
                </div>
                 <div class="fieldset">
                    <label class="control-labels">试题分类</label>
                    <div class="input-group" style="font-size:12px;">
                        <a  class="file">
                            <i class="fa fa-upload"></i>   
                            上传试题文件 
                        </a>
                    </div>
                </div>
                <textarea style="width:96%;font-size:13px;color:green;margin-left:13px;height: 234px;" rows="20"></textarea>
            </div>
            <div slot="footer" class="footer_but">        
                <button disabled="disabled" class="btn btn-blue"><i class="fa fa-arrow-circle-o-up" aria-hidden="true"></i>   <span>导入试题</span></button>            
                <button class="btn btn-default" type="button" ><i class="fa fa-window-close-o" aria-hidden="true"></i>   关 闭</button>
            </div>
        </Modal>
    </div>

</template>

<script>
export default {
    data(){
        return{
           modal4: true
        }
    },
    methods:{
       oncancel(){
           this.$router.push("/questions")
       }
    },
}
</script>

<style scoped>

.form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);

}

.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
.btn-red {
    border-radius: 3px;
    color: #fff;
    border: none;
    cursor: pointer;
    background-color: red;
}
.btn-default {
    color: #333;
    background-color: #fff;
    border-color: #ccc;
}



.form-control {
    padding-left: 5px;
    border-color: #dbd9d9;
    box-shadow: none;
    font-size: 13px;
    overflow-x: hidden;
}
textarea {
    resize: none;
}

.append-box .bottom {
    display: inline-block;
    padding: 6px 0 6px 0;
    width: 100%;
    text-align: center;
    z-index: 11;
    background: #f8f8f8;
    border-top: 1px solid #eee;
}
/* 批量导入 */
.nav{
    width: 915px;
    height: 382px;
    overflow-y:scroll; 
}
.fieldset{
    width: 100%;
    height: 40px;
    display: flex;
    margin-bottom: 30px;
}
.control-labels{
    width: 150px;
    height: 40px;
    vertical-align: middle;
    line-height: 40px;
}

.exportType a{
    display: inline-block;
    padding: 4px 8px;
    border: 1px solid #2b71c8;
    margin-right: 5px;
}
.input_but{
    position: relative;
    left: 248px;
    bottom: 34px;
}

.file {
    display: inline-block;
    background: #D0EEFF;
    border: 1px solid #99D3F5;
    border-radius: 4px;
    padding: 4px 12px;
}
.footer_but{
    display: inline-block;
    padding: 6px 0 6px 0;
    width: 100%;
    text-align: center;
    background: #fff;
    border-top: 1px solid #eee;
    
}

.required{
    width: 300px;
}


</style>