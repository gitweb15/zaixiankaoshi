<template>
	<div>
		<Header></Header>
		<div class="main-box">
			<ul class="navtabs">
				<li class="active lefttopborder">
					<a href="#"><strong>1</strong><span class="examflag">考试</span>信息</a>
					<i></i>
				</li>
				<li>
					<a href="#"><strong>2</strong>设计试卷</a>
					<i></i>
				</li>
				<li class="righttopborder">
					<a href="#"><strong>3</strong>发布<span class="examflag">考试</span></a>
					<i></i>
				</li>
			</ul>
			<div class="append-box">
				<h4>基本信息</h4>
				<fieldset>
					<div class="form-group">
						<label class="col-sm-2 control-label"><i style="color:red">*</i><span class="examflag">考试</span>名称</label>
						<div class="col-sm-5">
							<input type="text" class="form-control required autosave" placeholder="请输入名称...">
						</div>
						<p class="help-block error"></p>
					</div>
				</fieldset>
				<fieldset>
					<div class="form-group ">
						<label class="col-sm-2 control-label"><i style="color:red">*</i><span class="examflag">考试</span>分类
							<i class="fa fa-question-circle-o tooltips"></i></label>
						<div class="col-sm-5">
							<div class="input-group" style="margin-top:0px;">
								<input type="text" style="border-bottom-left-radius:4px;border-top-left-radius:4px;" readonly class="form-control"
								 value="考试分类">
								<div class="input-group-btn">
									<button style="height:34px;" type="button" class="btn btn-default dropdown-toggle">选择 <span class="caret"></span></button>
								</div>
							</div>
						</div>
						<p class="help-block error"></p>
					</div>
				</fieldset>
				<fieldset>
					<div class="form-group">
						<label class="col-sm-2 control-label"><span class="examflag">考试</span>须知
							<i class="fa fa-question-circle-o tooltips"></i></label>
						<div class="col-sm-5">
							<textarea type="text" rows="3" class="form-control autosave"></textarea>
						</div>
					</div>
				</fieldset>
				<h4>参加方式</h4>
				<fieldset id="divEaxmType">
					<div class="form-group">
						<label class="col-sm-2 control-label">考生参加方式</label>
						<div class="col-sm-7" style="font-size:13px;">
							<input type="radio" value="info" name="rdExamType" id="rdInfo" style="zoom:120%" checked="checked">
							<label style="font-weight:normal" for="rdInfo"><span style="font-weight:600;">免登录<span class="examflag">考试</span></span>：考生填写身份信息(如姓名、电话)，就可以参加<span
								 class="examflag">考试</span></label><br>
							<input type="radio" value="key" name="rdExamType" checked id="rdKey" style="zoom:120%">
							<label style="font-weight:normal" for="rdKey"><span style="font-weight:600">口令<span class="examflag">考试</span></span>：只要输入<span
								 class="examflag">考试</span>口令就可以参加<span class="examflag">考试</span>(防止陌生人参加)<a href="#" style="font-size: 12px; margin-left: 6px; color: blue; display: inline;"><i
									 class="fa fa-eye"></i> 预览效果</a>
							</label><br>
							<input type="radio" value="keyinfo" name="rdExamType" id="rdKeyInfo" style="zoom:120%">
							<label style="font-weight:normal" for="rdKeyInfo"><span style="font-weight:600">免登录+口令<span class="examflag">考试</span></span>：考生须填写身份信息和<span
								 class="examflag">考试</span>口令才可以参加<span class="examflag">考试</span>
							</label><br>
							<input type="radio" value="arrange" name="rdExamType" id="rdArrange" style="zoom:120%">
							<label style="font-weight:normal" for="rdArrange"><span style="font-weight:600">安排<span class="examflag">考试</span></span>：指定考生或部门参加，考生使用账号和密码登录才可以参加<span
								 class="examflag">考试</span>
							</label><br>
						</div>
					</div>
				</fieldset>
				<fieldset style="display: block;">
					<div class="form-group">
						<label class="col-sm-2 control-label"><span class="examflag">考试</span>口令</label>
						<div class="col-sm-5">
							<input name="txtExamKey" type="text" id="txtExamKey" class="form-control autosave" v-model="kouling">
						</div>
						<p class="help-block error">考生须输入此口令才能参加<span class="examflag">考试</span></p>
					</div>
				</fieldset>
				<fieldset>
					<div class="form-group">
						<label class="col-sm-2 control-label">考生手工签名</label>
						<div class="col-sm-5" style="font-size:13px;">
							<input name="chkManualSign" type="checkbox" id="chkManualSign" class="autosave" style="zoom:120%"> <label style="font-weight:normal"
							 for="chkManualSign">考生必须亲手签名才可以参加<span class="examflag">考试</span></label>
							<a href="#" style="font-size: 12px; margin-left: 6px; color: blue;"><i class="fa fa-eye"></i>
								查看效果</a>
						</div>
						<p class="help-block error"></p>
					</div>
				</fieldset>
				<div class="bottom">
					<button class="btn btn-blue" type="button" @click="doSaveData">保存 &amp; 去设计试卷</button>
				</div>
			</div>
		</div>
	</div>	
</template>

<script>
import Header from '@/components/Header/index.vue'
	export default {
		components:{Header},
		data() {
			return {
				kouling:810438
			}
		},
		methods:{
			doSaveData(){
				this.$router.push("/examedit2")
			}
		}
	}
</script>

<style scoped>
	.main-box {
		float: left;
		padding: 15px 20px 20px 20px;
		width: 100%;
		min-height: 600px;
		background-color: #f7f9fb;
	}

	.navtabs {
		float: left;
		margin-bottom: 10px;
		height: 45px;
		width: 100%;
		border-top-left-radius: 12px;
		border-top-right-radius: 12px;
		border: 1px solid #e6e9ee;
		border-bottom: none;
		background-color: #e2e9ef;
	}

	.navtabs li a {
		display: inline-block;
		width: 100%;
		height: 45px;
		line-height: 45px;
		font-size: 16px;
		color: #999;
		cursor: not-allowed;
		border-right: 1px solid #fff;
	}

	.navtabs li.active a {
		color: #fff;
		cursor: pointer;
		background-color: #173689;
	}

	.navtabs li strong {
		position: absolute;
		top: 7px;
		left: 30%;
		font-size: 28px;
		line-height: 1em;
		font-weight: 500;
	}

	.navtabs li.lefttopborder,
	.navtabs li.lefttopborder a {
		border-top-left-radius: 12px;
	}

	.navtabs li {
		position: relative;
		float: left;
		width: 33.33333333333%;
		text-align: center;
		cursor: pointer;
	}

	.navtabs li.active i {
		position: absolute;
		left: 47.5%;
		bottom: 0;
		border-color: transparent transparent #f7f9fb transparent;
		border-style: dashed dashed solid dashed;
		border-width: 8px;
		display: block;
		font-size: 0;
		width: 0;
		height: 0;
		line-height: 0;
	}

	.append-box {
		position: relative;
		float: left;
		width: 100%;
		margin-bottom: 15px;
		padding-top: 10px;
		padding-bottom: 20px;
		border-radius: 3px;
		border: 1px solid #e6e9ee;
		background-color: #fff;
	}

	.append-box h4 {
		margin-top: -11px;
		margin-bottom: 10px;
		height: 40px;
		line-height: 40px;
		text-indent: 20px;
		font-size: 16px;
		color: #555;
		border-top: 1px solid #e6e9ee;
		background-color: #f9f9f9;
		font-weight: 500;
	}

	fieldset {
		min-width: 0;
		padding: 0;
		margin: 0;
		border: 0;
	}

	.append-box fieldset {
		margin-bottom: 10px;
		padding: 0 15px 10px 15px;
	}

	.append-box .form-group {
		margin-right: 0;
		margin-bottom: 0;
	}

	.append-box .control-label {
		padding-right: 5px;
		font-weight: 500;
		color: #777;
		padding-top: 7px;
	}

	.control-label {
		font-size: 13px;
	}

	.col-sm-2 {
		width: 16.66666667%;
		float: left;
		position: relative;
		min-height: 1px;
		padding-right: 15px;
		padding-left: 15px;
	}

	.col-sm-5 {
		width: 41.66666667%;
		float: left;
		position: relative;
		min-height: 1px;
		padding-right: 15px;
		padding-left: 15px;
	}

	.col-sm-7 {
		width: 58.33333333%;
		float: left;
		position: relative;
		min-height: 1px;
		padding-right: 15px;
		padding-left: 15px;
	}

	.append-box p {
		margin: 10px 0 0 0;
	}

	.form-control {
		padding-left: 5px;
		border-color: #dbd9d9;
		box-shadow: none;
		font-size: 13px;
		overflow-x: hidden;
		display: block;
		width: 100%;
		height: 34px;
		padding: 6px 12px;
		font-size: 14px;
		line-height: 1.42857143;
		color: #555;
		background-color: #fff;
		background-image: none;
		border: 1px solid #ccc;
		border-radius: 4px;
		transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
	}

	.input-group-btn {
		position: absolute;
		top: 0;
		right: 15px;
		white-space: nowrap;
		vertical-align: middle;
		display: inline-block;
	}

	button {
		overflow: visible;
	}

	.btn {
		display: inline-block;
		padding: 6px 12px;
		margin-bottom: 0;
		font-size: 14px;
		font-weight: 400;
		line-height: 1.42857143;
		text-align: center;
		white-space: nowrap;
		vertical-align: middle;
		cursor: pointer;
		user-select: none;
		background-image: none;
		border: 1px solid transparent;
		border-radius: 4px;
	}

	.btn-default {
		color: #333;
		background-color: #fff;
		border-color: #ccc;
	}

	.caret {
		display: inline-block;
		width: 0;
		height: 0;
		margin-left: 2px;
		vertical-align: middle;
		border-top: 4px solid;
		border-right: 4px solid transparent;
		border-left: 4px solid transparent;
	}

	textarea.form-control {
		height: auto;
	}
label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
}
	.help-block {
		font-size: 12px;
	}
	.append-box .bottom {
	    display: inline-block;
	    padding: 6px 0 6px 0;
	    width: 100%;
	    text-align: center;
	    position: fixed;
	    bottom: 0;
	    left: 0;
	    z-index: 11;
	    background: #f8f8f8;
	    border-top: 1px solid #eee;
	}
	.btn-blue {
	    border-radius: 3px;
	    color: #fff;
	    border: none;
	    cursor: pointer;
	    background-color: #2b71c8;
	}
	.append-box .bottom .btn {
	    margin-right: 15px;
	    min-width: 100px;
	    height: 35px;
	    line-height: 1em;
	    padding: 8px 20px;
	}
</style>
