<template>
    <div class="syle">
      <Modal
        v-model="modal3"
        @on-cancel="oncancel"
        title="试题新增&编辑"
        width="950px"
        >
        <div class="main">
           <div id="btnChangeEditMode" value="txt" style="margin:0 auto;background:#55b63c;color:#fff;width:140px;height:26px;line-height:26px;padding:1px 4px;border-bottom-left-radius:8px;border-bottom-right-radius:8px;text-align:center;cursor:pointer">点击切换至编辑器模式</div>
            <div class="append-box" style="margin-top:10px;margin-right:10px;">    
        <fieldset class="col2">
            <div class="form-group">
                <label class="col-sm-2 control-label">试题类型</label>
                <div class="col-sm-9" style="width:74%">
                    <select name="ddlQuestionType" id="ddlQuestionType" class="form-control valid" style="border-bottom-left-radius:0px;">
                        <option value="Single"> 单选题 </option>
                        <option value="Multi"> 多选题 </option>
                        <option value="Judge"> 判断题 </option>
                        <option value="Fill"> 填空题 </option>
                        <option value="Ask"> 问答题 </option>
                    </select>
                    <a href="http://www.kaoshiyun.com.cn/help/f64d76.html#%E8%87%AA%E5%AE%9A%E4%B9%89%E9%A2%98%E5%9E%8B" target="_blank" style="font-size:8px;text-align:left;">更多自定义题型</a>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-2 control-label">试题分类</label>
                <div class="col-sm-9" style="width:74%">                          
                    <div class="input-group" style="margin-top:0px;">
                        <input name="hidTreeID" type="hidden" id="hidTreeID" value="b3d1d3">
                        <input name="txtTreeName" type="text" id="txtTreeName" readonly="" class="form-control" onclick="" value="试题分类">
                        <div class="input-group-btn">
                        <button id="btnSelectTree" type="button" style="height:34px;" class="btn btn-default dropdown-toggle" data-toggle="dropdown" onclick="">选择 <span class="caret"></span></button>
                        </div>
                    </div>                                
                </div>
            </div>
        </fieldset>                                          
        <fieldset>
            <div class="form-group">
                <label class="col-sm-1 control-label">试题内容<label style="color:red">*</label></label>
                <div class="col-sm-9" style="width:87%">
                    <textarea name="txtQuestionContent" id="txtQuestionContent" class="form-control valid content-simple" style="width:100%;height:50px;"></textarea><a href="#" class="htmleditor" title="高级编辑器，可上传图片"><i class="fa fa-file-image-o" style="font-size:15px;" aria-hidden="true"></i></a>
                    <p class="unit" id="divQuestionContentInfo" style="display:none;"><a id="btnInserFillArea" href="#" style="background:#1C87D5;width:100px;height:40px;color:#fff;margin-right:5px;padding:3px 8px 3px 8px">插入填空符</a>在填空位置插入填空符<label id="lFillAreaMsg" style="font-weight:normal;display:none;color:red" class="org">(用三个连续下划线表示)，如___</label></p>
                </div>
            </div>
        </fieldset> 
        <!--单选题-->                   
        <fieldset id="divObjective" style="">       
            <table cellspacing="0" cellpadding="0" style="border:1px solid #f2f4f8;width:94.1%" class="common-table table-border text-center">
                <thead>
                    <tr>
                    <th width="8%" colspan="2">勾选设置正确答案</th>
                    <th width="73%">选项内容<a id="btnBatchSetOption" href="#" style="font-weight:normal;cursor:pointer;margin-left:8px;font-size:12px;"><i class="fa fa-pencil" aria-hidden="true"></i> 批量编辑选项</a></th>
                    </tr>
                </thead>                        
                <tbody>
                    <tr>
                        <td><label><input value="A" type="radio" name="rdObjectiveOption"></label></td>
                        <td>A</td>
                        <td class="textearea"><textarea name="txtQuestionOption0" id="txtQuestionOption0" rows="1" style="height:auto;width:100%;" class="form-control content-simple"></textarea><a href="#" class="htmleditor" title="高级编辑器，可上传图片"><i class="fa fa-file-image-o" style="font-size:15px;" aria-hidden="true"></i></a></td>
                    </tr>
                        
                    <tr>
                        <td><label><input value="B" type="radio" name="rdObjectiveOption"></label></td>
                        <td>B</td>
                        <td class="textearea"><textarea name="txtQuestionOption1" id="txtQuestionOption1" rows="1" style="height:auto;width:100%;" class="form-control content-simple"></textarea><a href="#" class="htmleditor" title="高级编辑器，可上传图片"><i class="fa fa-file-image-o" style="font-size:15px;" aria-hidden="true"></i></a></td>
                    </tr>
                        
                    <tr>
                        <td><label><input value="C" type="radio" name="rdObjectiveOption"></label></td>
                        <td>C</td>
                        <td class="textearea"><textarea name="txtQuestionOption2" id="txtQuestionOption2" rows="1" style="height:auto;width:100%;" class="form-control content-simple"></textarea><a href="#" class="htmleditor" title="高级编辑器，可上传图片"><i class="fa fa-file-image-o" style="font-size:15px;" aria-hidden="true"></i></a></td>
                    </tr>
                        
                    <tr>
                        <td><label><input value="D" type="radio" name="rdObjectiveOption"></label></td>
                        <td>D</td>
                        <td class="textearea"><textarea name="txtQuestionOption3" id="txtQuestionOption3" rows="1" style="height:auto;width:100%;" class="form-control content-simple"></textarea><a href="#" class="htmleditor" title="高级编辑器，可上传图片"><i class="fa fa-file-image-o" style="font-size:15px;" aria-hidden="true"></i></a></td>
                    </tr>
                    <tr id="divAnswerOperation" class="operation">
                        <td colspan="3" style="padding-left:38px;padding-bottom:15px;">
                            <button type="button" id="btnAddObjectiveOption" onclick="" style="height:25px;line-height:10px;font-size:12px;" class="btn btn-default"><i class="fa fa-plus" aria-hidden="true"></i>   添加选项</button>
                            <button type="button" id="btnDelObjectiveOption" onclick="" style="height:25px;line-height:10px;font-size:12px;" class="btn btn-red"><i class="fa fa-minus" aria-hidden="true"></i>   删减选项</button>
                        </td>
                    </tr>                        
                </tbody>
            </table>
        </fieldset>
                  
        <!--问答题-->
        <fieldset id="divSubjective" style="display:none">       
            <div class="form-group">
            <label class="col-sm-1 control-label">标准答案</label>
            <div class="col-sm-9" style="width:87%">
                <textarea name="txtStandardAnswer" id="txtStandardAnswer" class="form-control content-simple" style="width:100%;height:50px;"></textarea><a href="#" class="htmleditor" title="高级编辑器，可上传图片"><i class="fa fa-file-image-o" style="font-size:15px;" aria-hidden="true"></i></a>
                <br>
                <label id="lAllowUploadPhoto" for="chkAllowUploadPhoto" onclick="" style="padding:3px 15px 3px 2px;width:200px;border:#f2f4f8 1px solid;cursor:pointer;display:none"><input name="chkAllowUploadPhoto" type="checkbox" id="chkAllowUploadPhoto" style="vertical-align:middle;zoom:120%"><span style="vertical-align:middle;font-weight:normal;font-size:12px;">&nbsp;允许考生拍照上传图片答题</span></label> 
            </div>            
        </div></fieldset> 
                  
        <fieldset class="col2">
            <div class="form-group">
                <label class="col-sm-2 control-label">试题分数</label>                          
                <div class="col-sm-9" style="width:74%">  
                    <input name="txtScore" type="text" id="txtScore" class="form-control" value="0.00">
                </div>
            </div>            
            <div class="form-group">
                <label class="col-sm-2 control-label">难易度</label>
                <div class="col-sm-9" style="width:74%">  
                    <select name="ddlDifficulty" id="ddlDifficulty" class="form-control valid">
                        <option value="0">不限难度</option>
                        <option value="1">容易</option>
                        <option value="2">中等</option>
                        <option value="3">困难</option>
                    </select>
                </div>
            </div>
        </fieldset>   
        <fieldset>
            <div class="form-group">
                <label class="col-sm-1 control-label">试题分析</label>
                <div class="col-sm-9" style="width:87%">
                    <textarea name="txtAnalysis" id="txtAnalysis" class="form-control  content-simple" style="width:100%;height:50px"></textarea><a href="#" class="htmleditor" title="高级编辑器，可上传图片"><i class="fa fa-file-image-o" style="font-size:15px;" aria-hidden="true"></i></a>
                </div>
            </div>
        </fieldset> 
                                        
        <div class="bottom" style="background:#fff">
            <button type="button" class="btn btn-blue" onclick=""><i class="fa fa-calendar-o"></i>   保 存</button>        
            <button type="button" class="btn btn-default" onclick=""><i class="fa fa-calendar-times-o" ></i>  保存并关闭</button>       
            <button type="button" class="btn btn-default" onclick=""><i class="fa fa-calendar-plus-o"></i>  保存并新增</button>
            <button type="button" class="btn btn-default" onclick=""><i class="fa fa-window-close-o"></i>   关 闭</button>
        </div>
    </div>
        </div>
    </Modal>
    </div>

</template>

<script>
export default {
    data(){
        return{
           modal3: true//默认弹出
        }
    },
    methods:{
       oncancel(){//退出
           this.$router.push("/questions")
       }
    },
}
</script>

<style scoped>
 .main{
        width: 875px;
    }
   .append-box {
        width: 100%;
        margin-bottom: 15px;
        padding-top: 10px;
        padding-bottom: 20px;
        border-radius: 3px;
        background-color: #fff;
    }
    .append-box fieldset {
        margin-bottom: 10px;
        padding: 0 15px 10px 15px;
    }
    fieldset {
        display: block;
        margin-inline-start: 2px;
        margin-inline-end: 2px;
        padding-block-start: 0.35em;
        padding-inline-start: 0.75em;
        padding-inline-end: 0.75em;
        padding-block-end: 0.625em;
        min-inline-size: min-content;
        border-width: 2px;
        border-style: groove;
        border-color: threedface;
        border-image: initial;
        border: 0;
        
    }

.form-control {
    padding-left: 5px;
    border-color: #dbd9d9;
    box-shadow: none;
    font-size: 13px;
    overflow-x: hidden;
}
.form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);

}
.append-box fieldset.col2 .form-group {
    float: left;
    width: 50%;
}
.append-box .control-label {
    padding-right: 5px;
    font-weight: 500;
    color: #777;
    padding-top: 7px;
}
.col-sm-1, .col-sm-2, .col-sm-9,.col-sm-9 .input-group-btn{
    float: left;
}
.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
.btn-red {
    border-radius: 3px;
    color: #fff;
    border: none;
    cursor: pointer;
    background-color: red;
}
.btn-default {
    color: #333;
    background-color: #fff;
    border-color: #ccc;
}
.caret {
    display: inline-block;
    margin-left: 2px;
    vertical-align: middle;
    border-top: 4px solid;
    border-right: 4px solid transparent;
    border-left: 4px solid transparent;
}
.form-group {
    display: flex;
}
.input-group-btn{
    position: relative;
    left: 245px;
    bottom: 34px;
}
.htmleditor {
    float: right;
    margin-top: -20px;
    padding-right: 20px;
    color: #2b71c8;
    position: relative;
}

.form-control {
    padding-left: 5px;
    border-color: #dbd9d9;
    box-shadow: none;
    font-size: 13px;
    overflow-x: hidden;
}
textarea {
    resize: none;
}
.common-table th {
    padding: 7px 0 7px 5px;
    color: #555;
    line-height: 22px;
    text-align: left;
    word-wrap: break-word;
    background-color: #eff2f5;
    text-align: center;
}
.append-box .bottom {
    display: inline-block;
    padding: 6px 0 6px 0;
    width: 100%;
    text-align: center;
    z-index: 11;
    background: #f8f8f8;
    border-top: 1px solid #eee;
}
</style>