<template>
	<div>
		<Header></Header>
		<div class="main-box">
			<ul class="navtabs">
				<li class="active lefttopborder">
					<a href="#"><strong>1</strong><span class="examflag">考试</span>信息</a>
					<i></i>
				</li>
				<li class="active">
					<a href="#"><strong>2</strong>设计试卷</a>
					<i></i>
				</li>
				<li class="righttopborder">
					<a href="#"><strong>3</strong>发布<span class="examflag">考试</span></a>
					<i></i>
				</li>
			</ul>
			<div class="append-box">
				<h4 style="padding-left:10px;">以下任意一种方式通知考生参加<span class="examflag">考试</span></h4>
				<fieldset>
					<div class="form-group">
						<label class="control-label">1、将二维码发给考生，扫描参加<span class="examflag">考试</span></label>
						<div class="col-sm-4" style="padding-left:0px;">
							<a style="font-size:14px;display:none;" target="_blank" href="http://www.kaoshiyun.com.cn/a/8d3003/8d3003.png">下载二维码</a><br>
							<img src="http://www.kaoshiyun.com.cn/a/8d3003/8d3003.png" style="margin-top: 25px;">
						</div>
						<p class="help-block error"></p>
					</div>
				</fieldset>
				<fieldset>
					<div class="form-group">
						<label class="col-sm-3 control-label">2、复制<span class="examflag">考试</span>链接发给考生，打开链接参加<span class="examflag">考试</span></label>
						<div class="col-sm-4">     
							<div class="input-group">
								<div class="form-control" style="height:36px;min-width:300px"><a title="在新窗口打开考试链接" id="examURL" href="http://www.kaoshiyun.com.cn/t.html?id=8d3003" target="_blank">http://www.kaoshiyun.com.cn/t.html?id=8d3003</a></div>
								<a class="input-group-addon" @click="fuzhi" style="font-size:13px;background:#fff"><i class="fa fa-copy"></i>  复制<span class="examflag">考试</span>链接</a>
							</div>                       
						</div>
						<p class="help-block error"></p>
					</div>
				</fieldset>
				<fieldset>
					<div class="form-group">
						<label class="col-sm-3 control-label">3、发送<span class="examflag">考试</span>邮件，通知考生参加<span class="examflag">考试</span></label>
						<div class="col-sm-4">
							<button @click="fasong" type="button" class="btn" style="margin-top: 25px;margin-left: 45px;" ><i class="fa fa-envelope-o fa-fw"></i>  发送<span class="examflag">考试</span>通知</button>
						</div>
						<p class="help-block error"></p>
					</div>
				</fieldset>
				
			</div>
			<div class="bottoms">
				<a href="/kaoshi" class="btn"><i class="fa fa-rotate-left" aria-hidden="true"></i>   返回<span class="examflag">考试</span>列表</a>
				<a @click="$router.go(-1)" class="btn" style="margin-left: 10px;"><i class="fa fa-reply" aria-hidden="true"></i>  上一步</a>
			</div>
		</div>
		
	</div>	
</template>

<script>
import Header from '@/components/Header/index.vue'
	export default {
		components:{Header},
		data() {
			return {
				kouling:810438
			}
		},
		methods:{
			fasong(){
				alert("发送成功")
			},
			fuzhi(){
				alert("复制成功")
			}
		}
	}
</script>

<style scoped>
	.main-box {
		float: left;
		padding: 15px 20px 20px 20px;
		width: 100%;
		min-height: 600px;
		background-color: #f7f9fb;
	}

	.navtabs {
		float: left;
		margin-bottom: 10px;
		height: 45px;
		width: 100%;
		border-top-left-radius: 12px;
		border-top-right-radius: 12px;
		border: 1px solid #e6e9ee;
		border-bottom: none;
	}

	.navtabs li a {
		display: inline-block;
		width: 100%;
		height: 45px;
		line-height: 45px;
		font-size: 16px;
		color: #999;
		/* cursor: not-allowed; */
		border-right: 1px solid #fff;
	}

	.navtabs li.active a {
		color: #fff;
		cursor: pointer;
		background-color: #4a9b04;
	}
	.navtabs li.righttopborder a {
		color: #fff;
		cursor: pointer;
		background-color: #173689;
	}

	.navtabs li strong {
		position: absolute;
		top: 7px;
		left: 30%;
		font-size: 28px;
		line-height: 1em;
		font-weight: 500;
	}

	.navtabs li.lefttopborder,
	.navtabs li.lefttopborder a {
		border-top-left-radius: 12px;
	}

	.navtabs li {
		position: relative;
		float: left;
		width: 33.33333333333%;
		text-align: center;
		cursor: pointer;
	}

	.navtabs li.righttopborder i {
		position: absolute;
		left: 47.5%;
		bottom: 0;
		border-color: transparent transparent #f7f9fb transparent;
		border-style: dashed dashed solid dashed;
		border-width: 8px;
		display: block;
		font-size: 0;
		width: 0;
		height: 0;
		line-height: 0;
	}

	.append-box {
		position: relative;
		float: left;
		width: 100%;
		margin-bottom: 15px;
		padding-top: 10px;
		padding-bottom: 20px;
		border-radius: 3px;
		border: 1px solid #e6e9ee;
		background-color: #fff;
	}

	.append-box h4 {
		margin-top: -11px;
		margin-bottom: 10px;
		height: 40px;
		line-height: 40px;
		text-indent: 20px;
		font-size: 16px;
		color: #555;
		border-top: 1px solid #e6e9ee;
		background-color: #f9f9f9;
		font-weight: 500;
	}
	.append-box fieldset {
	    margin-bottom: 10px;
	    padding: 0 15px 10px 15px;
	    border-bottom: 1px dashed #eee;
	}
	fieldset{
		border: 0;
	}
	.form-group{
		display: flex;
	}
	.control-label{
		width: 300px;
		margin-top: 25px;
		padding: 0 40px;
	}
	.append-box .control-label {
	    padding-right: 5px;
	    font-weight: 500;
	    color: #777;
	}
	.input-group {
	    position: relative;
	    display: table;
	    border-collapse: separate;
		margin-top: 25px;
	}
	.form-control {
	    padding-left: 5px;
	    border-color: #dbd9d9;
		display: table-cell;
	    box-shadow: none;
	    font-size: 13px;
	    overflow-x: hidden;
		border: 1px solid #ccc;
		border-radius: 4px;
	}
	.input-group-addon {
	    padding: 6px 12px;
	    font-size: 14px;
	    font-weight: 400;
	    color: #555;
	    text-align: center;
	    background-color: #eee;
	    border: 1px solid #ccc;
	    border-radius: 4px;
		white-space: nowrap;
		vertical-align: middle;
		display: table-cell;
	}
	.btn {
	    display: inline-block;
	    padding: 6px 12px;
	    margin-bottom: 0;
	    font-size: 14px;
	    font-weight: 400;
	    line-height: 1.42857143;
	    text-align: center;
	    white-space: nowrap;
	    vertical-align: middle;
	    cursor: pointer;
	    user-select: none;
	    background-image: none;
	    border: 1px solid rgb(204, 204, 204);
	    border-radius: 4px;
		background-color: #FFFFFF;
	}
	 .bottoms {
		width: 100%;
		height: 48px;
		text-align: center;
		position: fixed;
		bottom: 0;
	}
</style>
