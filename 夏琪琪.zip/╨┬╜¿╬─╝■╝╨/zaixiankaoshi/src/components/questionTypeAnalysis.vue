<template>
	<div class="syle">
		<div style="padding:15px 20px;background-color: #f7f9fb;">
			<div style="border: 1px solid #e6e9ee;margin-bottom: 5px;height: 46px;border-bottom: 1px solid #eee;float: left;width:100% ">
				<div style="color: #2b71c8;border-bottom: 2px solid #2b71c8;width: 150px;height: 46px;line-height: 46px;padding: 8px 20px 10px 20px;font-size: 14px;float: left; ">
					<div style="margin-top: -10px;">
						<i class="fa fa-quora"></i> 试题类型统计
					</div>

				</div>
				<div style="font-size: 12px;float: right;padding: 4px;">

					<ButtonGroup style="padding: 0 4px 0 0;">
						<Button>
							<i class="fa fa-angle-double-down" aria-hidden="true"></i>
							查询
						</Button>
					</ButtonGroup>
					<ButtonGroup>
						<Button>
							<i class="fa fa-download" aria-hidden="true"></i>
							导出
						</Button>
					</ButtonGroup>

				</div>
			</div>

			<div style="float:left;width:100%;margin-bottom:15px;padding:15px 15px 15px 5px;-moz-border-radius:3px;-webkit-border-radius:3px;border-radius:3px;border:1px solid #e6e9ee;background-color:#fff">
				<div style="width:50%;min-height:351px;float:left">
					<div id="main" style="width: 640px;height:350px;"></div>
				</div>
				<div style="width:50%;float:right">
					<div id="main1" style="width: 640px;height:350px;"></div>
				</div>
			</div>

			<table class="common-table table-border">
				<thead>
					<tr>
						<th width="80" style="text-align:center">试题类型</th>
						<th style="text-align:center">试题总数</th>
						<th style="text-align:center">难度不限</th>
						<th style="text-align:center">容易</th>
						<th style="text-align:center">中等</th>
						<th style="text-align:center">困难</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="text-align:center">单选题</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
					</tr>
					<tr>
						<td style="text-align:center">多选题</td>
						<td style="text-align:center">2</td>
						<td style="text-align:center">2</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
					</tr>
					<tr>
						<td style="text-align:center">判断题</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
					</tr>
					<tr>
						<td style="text-align:center">填空题</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
					</tr>
					<tr>
						<td style="text-align:center">问答题</td>
						<td style="text-align:center">8</td>
						<td style="text-align:center">8</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
						<td style="text-align:center">0</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				option: {//echarts样式
					title: {
						text: '试题类型百分比统计',
						left: 'center'
					},
					tooltip: {
						trigger: 'item',
						formatter: '{b} : {c} ({d}%)'
					},
					legend: {

						bottom: 10,
						left: 'center',
						data: ['单选题', '多选题', '判断题', '填空题', '问答题']
					},
					series: [{
						type: 'pie',
						startAngle: 90,
						radius: '65%',
						center: ['50%', '50%'],
						label: {
							formatter: '{b}:{d}%'
						},
						selectedMode: 'single',
						data: [{

								value: 0,
								name: '单选题'
							},
							{
								value: 0,
								name: '多选题'
							},
							{
								value: 0,
								name: '判断题'
							},
							{
								value: 2,
								name: '填空题'
							},
							{
								value: 8,
								name: '问答题'
							}
						],
						emphasis: {
							itemStyle: {//图表方法
								shadowBlur: 10,
								shadowOffsetX: 0,
								shadowColor: 'rgba(0, 0, 0, 0.5)'
							}
						}
					}]
				},
				option1: {
					title: {
						text: '试题难度百分比统计',
						left: 'center'
					},
					color: ['rgb(72,151,241)', 'green', 'yellow', 'blueviolet'],
					tooltip: {
						trigger: 'item',
						formatter: '{b} : {c} ({d}%)'
					},
					legend: {

						bottom: 10,
						left: 'center',
						data: ['不限难度', '容易', '中等', '困难']
					},
					series: [{
						type: 'pie',
						startAngle: 90,
						radius: '65%',
						center: ['50%', '50%'],
						label: {
							formatter: '{b}:{d}%'
						},
						selectedMode: 'single',
						data: [{

								value: 10,
								name: '不限难度'
							},
							{
								value: 0,
								name: '容易'
							},
							{
								value: 0,
								name: '中等'
							},
							{
								value: 0,
								name: '困难'
							}
						],
						emphasis: {
							itemStyle: {
								shadowBlur: 10,
								shadowOffsetX: 0,
								shadowColor: 'rgba(0, 0, 0, 0.5)'
							}
						}
					}]
				}

			}
		},
		mounted() {
			let myChart = this.$echarts.init(document.getElementById("main"));
			myChart.setOption(this.option)
			let myChart1 = this.$echarts.init(document.getElementById("main1"));
			myChart1.setOption(this.option1)
		}
	}
</script>

<style scoped>
	.syle {
		background-color: #f7f9fb;
		min-height: 600px;
	}
	.common-table {
	    width: 100%;
	    border: 1px solid #e6e9ee;
	    color: #222;
	}
	.common-table tr {
	    height: 58px;
	}
	.table-border td, .table-border th {
	    border-right: 1px solid #e6e9ee;
	    border-bottom: 1px solid #e6e9ee;
	}
	.common-table th {
	    padding: 7px 0 7px 5px;
	    color: #555;
	    line-height: 22px;
	    text-align: left;
	    word-wrap: break-word;
	    background-color: #eff2f5;
	}
	.common-table td {
	    padding: 7px 0 7px 5px;
	    line-height: 22px;
	    word-wrap: break-word;
	    text-align: left;
	    background-color: #fff;
	}
</style>
