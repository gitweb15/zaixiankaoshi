<template>
    <div class="syle">
     <!-- 批量导入考生 -->
       <Modal v-model="modal7" width="800" @on-cancel="oncancel"  title="考生导入" >
            <div class="main1">
               <div class="main1_contorl" style="font-size:14px;font-weight:500;">第一步、下载导入模板</div>
                <div class="exportType">
                    <a href="../../Resource/User/UserImportTemplate.xls" target="_blank"><i class="fa fa-cloud-download"></i>&nbsp;&nbsp;简单模板（点击下载）</a>
                    <a href="../../Resource/User/UserImportTemplateAll.xls" target="_blank"><i class="fa fa-cloud-download"></i>&nbsp;&nbsp;完整模板（点击下载）</a>
                </div>
                <div class="main1_contorl" style="font-size:14px;font-weight:500;">第二步、上传导入文件</div>
                <div class="exportType">
                    <a href="javascript:;" class="file">
                        <i class="fa fa-cloud-upload"></i>&nbsp;&nbsp;<input type="file" name="btnUploadQuestionFile" id="btnUploadQuestionFile">上传导入文件
                    </a>
                </div>
            </div>
            <div slot="footer" class="main1_footer">
                <button class="btn" @click="cancel">关闭</button>
            </div>
        </Modal>
    </div>

</template>

<script>
export default {
    data(){
        return{
           modal7: true,
        }
    },
    methods:{
       oncancel(){//退出
           this.$router.push("/examinee")
       },
        cancel () {//关闭弹出框
            this.modal7 = false;
        }
    },
}
</script>

<style scoped>
.main1{
    width: 100%;
    margin: 10px 0 15px;
    padding: 10px 0 20px;
    background-color: #fff;
}
.main1_contorl{
    padding-left: 55px;
    font-weight: 500;
    color: #777;
    padding-top: 7px;
    margin-bottom: 25px;
}
.exportType{
    display: flex;
    margin-top: 5px;
    padding-left: 55px;
    margin-bottom: 25px;
}
.exportType a {
    border: 1px solid #1C87D5;
    padding: 4px 8px 4px 8px;
    text-decoration: none;
    font-size: 12px;
    margin-right: 5px;
}
.file {
    position: relative;
    display: inline-block;
    background: #D0EEFF;
    border: 1px solid #99D3F5;
    border-radius: 4px;
    padding: 4px 12px;
    overflow: hidden;
    color: #1E88C7;
    text-decoration: none;
    text-indent: 0;
    line-height: 20px;
    font-size: 13px;
}
.file input {
    position: absolute;
    font-size: 100px;
    right: 0;
    top: 0;
    opacity: 0;
}
.main1_footer{
    text-align: center;
}
.main1_footer .btn {
    margin-right: 15px;
    min-width: 100px;
    height: 35px;
    line-height: 1em;
    padding: 8px 20px;
    
}

</style>