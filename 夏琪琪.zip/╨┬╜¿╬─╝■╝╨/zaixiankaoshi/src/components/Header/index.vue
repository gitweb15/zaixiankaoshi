<template>
	<div>
        <!-- 头部 -->
	<div id="topControl" class="top topbannerbg shadow" style="position:fixed;top:0;">
		<!-- logo -->
		<div style="float:left;color:#fff;height:58px;display:table-cell;vertical-align:middle;font-size:20px;font-weight:bold;">
            <img src="../../assets/logo1.png" style="height:58px;padding:13px 30px 13px 10px;">
			<span style="margin-left:8px;"></span>
        </div>
		<a href="/Home" class="current"> <i class="fa fa-home" style="line-height:58px;font-size:20px;"></i> </a>
		<a href="/kaoshi">考试</a> <a id="exer" href="/lianxi">练习</a><a id="lesson" href="/peixun">培训</a>
		<a @mouseover="show()" @mouseleave="noshow()" href="/questions" class="">资源 <i class="fa fa-caret-down"></i></a><a id="report" href="/baobiao">报表</a>
		<a href="#" title="快捷操作" @mouseover="quickmenuShow" @mouseleave="quickmenuHide"> <i class="fa fa-list-ul" style="font-size:18px;" ></i></a>
		<span id="divRightPanel" style="float:right;">
			<a id="imguser" href="#" style="padding: 0px 8px;" class="topbannerbg" @mouseover="mouseover()" @mouseleave="mouseleave" > 
				<i class="fa fa-user-circle" style="font-size:24px;"></i> 
                </a> <a id="manage" href="/SubAdministrator" style="padding:0px 8px;background:#051638">管理</a>
		</span>
	</div>
	<div style="height: 58px;"></div>
    <!-- 资源弹出框 -->
		<div id="divResource" @mouseover="show()" @mouseleave="noshow()" v-show="toshow" class="resourcemenu" style="font-size: 13px; width: 130px; left: 556px;">
			<a href="../questions"><i class="fa fa-database" style="margin-right: 12px;"></i>试题</a>
			<a href="../examinee"><i class="fa fa-users" style="margin-right: 10px;"></i>考生</a>
		</div>
    <!-- 快捷方式弹出框 -->
		<div class="quickmenu" style="font-size: 13px; width: 530px; border-top: none; right: 14.1%;" v-show="quickmenu"
		 @mouseover="quickmenuShow" @mouseleave="quickmenuHide">
			<h5 style="font-size:14px;padding-left:8px;font-weight:200;height:25px;border-bottom:1px solid #ECECEC;padding-bottom:10px;">功能快捷方式</h5>
			<div style="margin-top:10px;">
				<div style="font-size:14px;padding-left:8px;font-weight:bold">业务</div>
				<a href="../examedit">创建考试</a>
				<a href="#" @click="tolianxi = true">创建练习</a>
				<!-- 创建练习弹出框 -->
				<Modal v-model="tolianxi" title="请选择创建类型" footer-hide width="590">
					<div>
						<div class="fix">
							<i class="fa fa-server iconfix "></i>
							<div class="typetext">章节练习</div>
							<div class="typetextdetail">组建一套练习题库，可自定义练习章节<br>并向章节添加试题，考生可按章节练习</div>
							<a class="btn btn-default btn_create_exam" href="../createLianxi">去创建章节练习</a>
						</div>
						<div class="fixfromrandom">
							<i class="fa fa-map iconfixfromrandom"></i>
							<div class="typetext">模拟练习</div>
							<div class="typetextdetail">创建一张模拟试卷，可手工或随机组卷<br>考生每作答一道试题可查看答案和解析</div>
							<a class="btn btn-default btn_create_exam" href="../createLianxi">去创建模拟练习</a>
						</div>
					</div>
				</Modal>
				<a href="../lessonedit">创建培训课程</a>
			</div>
			<div>
				<br>
				<div style="margin-top:35px;">
					<div style="font-size:14px;padding-left:8px;font-weight:bold">资源</div>
                    <!-- <a href="../addCandidates">批量导入试题</a> -->
					<a href="../BatchQuestions">批量导入试题</a>
                    <a href="../fastAddQuestions">快速新增试题</a>
					<a href="../addQuestions" >新增试题</a>
					<a href="../batchCandidates">批量导入考生</a>
					<a href="../addCandidates">新增考生</a>
				</div>
			</div>
			<br>
			<div style="margin-top:35px;">
				<div style="font-size:14px;padding-left:8px;font-weight:bold">报表</div>
				<a href="../kaoshichengji" class="normal">考试成绩</a>
				<a href="../analysis" class="normal">考生分析</a>
				<a href="../Statistical" class="normal">答题统计</a>
				<a href="../quexitongji" class="normal">缺席统计</a>
				<a href="../judgepaper" class="normal">人工评卷</a>
				<a href="../Practice" class="normal">练习统计</a>
				<a href="../lessonanalysis" class="normal">培训学习统计</a>
				<a href="../integralAnalysis" class="normal">积分统计</a>
				<a href="../itemAnalysis" class="normal">试题分析</a>
				<a href="../questionTypeAnalysis" class="normal">试题类型统计</a>
			</div>
			<br>
			<div style="margin-top:75px;">
				<div style="font-size:14px;padding-left:8px;font-weight:bold">设置</div>
				<a href="../core">考生中心</a>
				<a href="../Upgrade">在线升级</a>
				<a href="../../help" target="_blank">帮助文档</a>
			</div>
			<br>
		</div>
	<div class="personal" @mouseover="mouseover()" @mouseleave="mouseleave" v-show="isshow">
		<a href="/core"><i class="fa fa-share-alt"></i> <span>考生中心</span> </a>
		<hr style="width:90%;border:none;border-bottom:1px solid #ECECEC;margin-top:7px;margin-bottom:7px;">
		<a  @click="modal1 = true"><i class="fa fa-address-card-o"></i> <span>我的资料</span></a>
		<a @click="modal2 = true" class="online"><i class="fa fa-key"></i> <span>修改密码</span></a>
		<hr style="width:90%;border:none;border-bottom:1px solid #ECECEC;margin-top:7px;margin-bottom:7px;">
		<a href="http://www.kaoshiyun.com.cn/help" ><i class="fa fa-question-circle-o"></i> <span>帮助文档</span></a>
		<a href="/"><i class="fa fa-sign-out" ></i> <span>退出</span></a>
	</div>
    <!-- 我的信息弹出框 -->
	 <Modal
        v-model="modal1"
        title="我的信息"
        width="1140"
        >
        <div class="main">
            <div class="left">
                <div class="left_top">
                   <ul class="left_top1">
                       <li><Icon type="md-contact" size="40" /></li> 
                       <li class="sp">海纳创新</li>    
                   </ul>
                   <div class="left_top2">海纳创新</div>
                   <div class="left_top3">最近登录：2020-04-28 10:13</div>
                </div>
                <div class="left_but">
                    <h3 class="left_but1">最近登录人员</h3>
                    <div class="left_but2">
                       <div><Icon type="md-contact" size="40" /></div>
                       <ul>
                           <li>海纳创新</li>
                           <li>海纳创新</li>
                       </ul>
                   </div>
                    <div class="left_but2">
                       <div><Icon type="md-contact" size="40" /></div>
                       <ul>
                           <li>测试1</li>
                           <li>后台</li>
                       </ul>
                   </div>
                </div>
            </div>
            <div class="right">
                <Tabs size="default">
                    <TabPane label="我的">
                        <div class="right_top">
                            <div class="right_top1">账号</div>
                            <div class="right_top2">521175582@qq.com</div>
                            <div class="right_top3"><button class="but">修改我的资料</button></div>
                        </div>
                        <div class="right_cen">
                            <div class="right_top1">姓名</div>
                            <div class="right_top2">海纳创新</div>
                        </div>
                        <div class="right_cen">
                            <div class="right_top1">部门</div>
                            <div class="right_top2">海纳创新</div>
                        </div>
                        <div class="right_cen">
                            <div class="right_top1">电话</div>
                            <div class="right_top2"></div>
                        </div>
                        <div class="right_cen">
                            <div class="right_top1">手机</div>
                            <div class="right_top2">18975019203</div>
                        </div>
                        <div class="right_cen">
                            <div class="right_top1">邮箱</div>
                            <div class="right_top2">521175582@qq.com</div>
                        </div>
                    </TabPane>
                    <TabPane label="使用评率">
                        <div id="myChart" class="myChart" :style="{width: '739px', height: '450px'}"></div>
                    </TabPane>
                </Tabs>
            </div>
        </div>
    </Modal>
    <!-- 修改密码弹出框 -->
     <Modal
        v-model="modal2"
        title="修改密码"
        width="756px"
        footer-hide
        >
            <Tabs type="card">
                <TabPane label="基本资料">
        <div id="divContent1" class="form_content1" style="font-size: 13px; display: block;">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="form_table form_table_edit form_control"> 
                <tbody><tr>
                    <th>账号</th>
                    <td>521175582@qq.com</td>
                </tr>
                <tr>
                    <th>姓名</th>
                    <td><input name="txtUName" type="text" id="txtUName" class="commontext" value="海纳创新"></td>
                </tr>
                <tr style="display:none">
                    <th>性别</th>
                    <td>
                    <select name="ddlSex" id="ddlSex" class="commonselect">
                        <option value="男">男</option>
                        <option value="女">女</option>
                    </select>
                    </td>
                </tr>
                <tr>
                    <th>证件类型</th>
                    <td>
                    <select name="ddlIdentityType" id="ddlIdentityType" style="width:20%" class="commonselect">
                        <option value="身份证">身份证</option>
                        <option value="学生证">学生证</option>
                        <option value="军官证">军官证</option>
                        <option value="其它">其它</option>
                    </select>
                    <input name="txtIdentityCard" type="text" id="txtIdentityCard" style="width:44%" class="commontext">
                    </td>
                </tr>
                <tr>
                    <th>出生日期</th>
                    <td><input name="txtBDay" type="text" id="txtBDay" class="commontext"></td>
                </tr>
                <tr>
                    <th>电话号码</th>
                    <td><input name="txtTphone" type="text" id="txtTphone" class="commontext"></td>
                </tr>
                <tr>
                    <th>手机号码</th>
                    <td><input name="txtMPhone" type="text" id="txtMPhone" class="commontext" value="18975019203"></td>
                </tr>
                <tr>
                    <th>电子邮件</th>
                    <td><input name="txtEmail" type="text" id="txtEmail" class="commontext" value="521175582@qq.com"></td>
                </tr>
                
                <tr style="display:none;">
                    <th>个人说明</th>
                    <td><textarea name="txtRemark" id="txtRemark" class="commontextarea" cols="45" rows="5"></textarea></td>
                </tr>
                </tbody></table>
            <div style="text-align:center" id="btnSaveData"><a href="javascript:doSaveData()" class="bluebtn">保存修改</a></div> 
            <br><br>
        </div>          
                </TabPane>
                <TabPane label="修改密码">
                     <div id="divContent3" class="form_content1" style="font-size: 13px;">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="form_table form_table_edit form_control">               
                <tbody><tr>
                    <th>原密码</th>
                    <td><input name="txtOldPassword" type="password" id="txtOldPassword" class="commontext">
                        <span id="sOldPasswordInfo" style="color:red;">*</span>
                    </td>
                </tr>
                <tr>
                    <th>新密码</th>
                    <td><input name="txtNewPassword" type="password" id="txtNewPassword" class="commontext">
                        <span id="sNewPasswordInfo" style="color:red;">*</span>
                    </td>
                </tr>
                <tr>
                    <th>确认新密码</th>
                    <td><input name="txtNewPasswordConfirm" type="password" id="txtNewPasswordConfirm" class="commontext">
                        <span id="sNewPasswordConfirmInfo" style="color:red;">*</span>
                    </td>
                </tr>
                </tbody></table>
            <div style="text-align:center"><a href="javascript:doModifyPassword()" class="bluebtn">保 存</a></div> 
        </div>
                </TabPane>
            </Tabs>
        </Modal>
	</div>
</template>

<script>

export default {
    data(){
      return {
		isshow:false,
        modal1: false,
        modal2: false,
        modal3: false,
        toshow: false,
        quickmenu: false,
        tolianxi: false
      }
	},
	methods:{
		 // 移入
    mouseover(id) {
      this.isshow = true;
    },
    // 移出
    mouseleave() {
        this.isshow = false;
    },
    show() {
        this.toshow = true
    },
    noshow() {
        this.toshow = false
    },
    quickmenuShow() {
		this.quickmenu = true
	},
	quickmenuHide() {
		this.quickmenu = false
    },
    // echarts方法
	 drawLine(){
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('myChart'))
            // 绘制图表
            myChart.setOption({
                xAxis: {
                    type: 'category',
                    
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [{
                        data: [0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0, 21.56],
                        type: 'line'
                    }]
                });
            }
	},
    mounted(){
         this.drawLine();
    }
}
</script>

<style scoped>
.quickmenu {
		font-size: 14px;
		position: fixed;
		top: 58px;
		background-color: #fff;
		position: fixed;
		width: 108px;
		color: #404040;
		border: #eee 1px solid;
		padding: 10px;
		padding-bottom: 20px;
		z-index: 3;
		box-shadow: 1px 3px 4px rgba(0, 0, 0, 0.18);
	}

	.quickmenu a {
		display: block;
		padding-left: 8px;
		margin-top: 10px;
		margin-right: 20px;
		line-height: 27px;
		_zoom: 1;
		text-decoration: none;
		color: #545454;
		float: left;
		font-size: 14px;
	}
	.top {
		width: 100%;
		height: 58px;
		margin: 0 auto;
		padding: 0px;
		position: fixed;
		z-index: 700;
	}
	
	.topbannerbg {
		background: #101F46;
	}
	
	img {
		vertical-align: middle;
		display: inline-block;
	}
	
	.top a {
		height: 58px;
		line-height: 58px;
		font-size: 16px;
		font-weight: 500;
		color: #fff;
		text-align: left;
		text-indent: 0px;
		float: left;
		margin: 0px;
		padding: 0 35px;
	}
	
	.top a:hover {
		background: #4B5564;
		color: #fff;
	}
	.personal{
		width: 150px;
		height: 181px;
		color: #404040;
		background: #fff;
		padding: 4px;
		font-size: 13px;
		border: #eee 1px solid;
		box-shadow: 1px 3px 4px rgba(0, 0, 0, 0.18);
        position: fixed;
        right: 50px;
        z-index: 1;
	}
	.personal a{
		display: block;
		padding-left: 8px;
		line-height: 27px;
		text-decoration: none;
		color: #545454;
	}
	.personal a:hover{
		color: blue;
	}
	.personal a span{
		padding-left: 10px;
	}
	 .main{
        width: 1107px;
        height: 816px;
        display: flex;
        
    }
    .left{
        flex-direction: row;
        width: 221px;
        height: 319px;
        /* background: red; */
    }
    .right{
        flex-direction: row;
        width: 779px;
        height: 547px;
        /* background: blue; */
    }
    .left{
        border-right: 1px solid #99a1a6;
    }
    .left_top{
        width: 180px;
        height: 99px;
        color: #99a1a6;
        font-size: 12px;
    }
    .left_top1{
        width: 100%;
        height: 40px;
        display: flex;
    }
    .left_top1 .sp{
        line-height: 40px;
        margin-left: 20px;
    }
    .left_top4,.left_top3{
        width: 100%;
        height: 28px;
        line-height: 28px;
    }
    .left_but{
        width: 100%;
    }
    .left_but1{
        width: 180px;
        height: 32px;
        line-height: 32px;
        border-bottom: 1px solid #99a1a6;
    }
    .left_but2{
        width: 180px;
        height: 40px;
        display: flex;   
        margin-top: 20px; 
    }
  .left_but2 ul{
      margin-left: 20px;
  }
  .right{
      width: 779px;
      height: 547px;
  }
  .right_top{
      width: 739px;
      height: 75px;
      line-height: 75px;
      border-bottom: 1px dashed #e5e5e5;
      font-size: 14px;
      color: #aaa;
      display: flex;
  }
  .right_cen{
      width: 739px;
      height: 69px;
      line-height: 69px;
      border-bottom: 1px dashed #e5e5e5;
      font-size: 14px;
      color: #aaa;
      display: flex;
  }
  .right_top1{
      margin-left: 180px;
  }
  .right_top2{
       margin-left: 50px;
       color: #3a3d3f;
  }
  .right_top3{
      margin-left: 100px;
  }
  .but{
    width: 110px;
    height: 28px;
    line-height: 28px;
    background: #FF7700;
    border: solid 1px #EF6502;
    color: #fff;
    text-align: center;
    border: 1px solid #e4e4e4;
    border-radius: 4px;
  }
  .myChart{
      margin-left: 50px;
  }

.form_content1 {
    height: 350px;
    width: 98%;
    margin: 10px 0 8px 0;
    padding-top: 5px;
    overflow-x: hidden;
    overflow-y: auto;
    margin-left: 30px !important;
    margin-left: 27px;
    _height: 1px;
    margin-right: 55px;
    _margin-right: 50px;
    font-size: 12px;
}
tr {
    display: table-row;
    vertical-align: inherit;
    border-color: inherit;
}
.form_table, .form_table table, table {
    border-spacing: 0;
    border-collapse: collapse;
}
.form_table_edit td {
    padding: 5px 0;
}
/*  */
.form_table_edit th {
    width: 25%;
    padding-right: 20px;
    height: 50px;
    line-height: 32px;
    font-weight: normal;
    text-align: right;
    color: #555;
}
.form_control .commontext, .Nsb_form_s_date {
    width: 65%;
}
.commontext, .Nsb_form_s_date {
    height: 35px;
    line-height: 35px;
}
.commontext, .commonselect, .commontextarea {
    border: solid 1px #e2e2e2;
    background: #fff;
}
.bluebtn {
    background: #FF9326;
    border: solid 1px #EF6502;
    color: #fff;
}
.bluebtn, .graybtn {
    display: inline-block;
    height: 26px;
    font-size: 14px;
    line-height: 26px;
    padding: 0 12px;
    vertical-align: middle;
    border-radius: 4px;
}
.resourcemenu {
		font-size: 14px;
		position: fixed;
		top: 58px;
		background-color: #fff;
		position: fixed;
		width: 108px;
		color: #404040;
		border: #eee 1px solid;
		padding: 5px;
		padding-bottom: 10px;
		z-index: 2;
		box-shadow: 1px 3px 4px rgba(0, 0, 0, 0.18);
	}

	.resourcemenu a {
		width: 100%;
		display: block;
		padding-left: 20px;
		margin-top: 10px;
		line-height: 27px;
		_zoom: 1;
		text-decoration: none;
		color: #545454;
		float: left;
		font-size: 16px;
	}

	.resourcemenu i {
		font-size: 16px;
	}
   .fix {
	    width: 260px;
	    height: 275px;
	    background: #479de6;
	   display: inline-block;
	    margin-top: 15px;
	}
	.iconfix {
	    color: #fff;
	    margin-left: 75px;
	    margin-top: 14px;
	    font-size: 100px;
	}
	.typetext {
	    color: #fff;
	    text-align: center;
	    font-size: 20px;
	    margin-top: 8px;
	}
	.typetextdetail {
	    color: #fff;
	    text-align: center;
	    font-size: 13px;
	    margin-top: 15px;
	}
	.btn_create_exam {
	    background: #fff;
	    color: #4597df;
	    border: 1px solid #999;
	    margin-top: 15px;
	    margin-left: 75px;
	}
	.btn {
	    display: inline-block;
	    padding: 6px 12px;
	    margin-bottom: 0;
	    font-size: 14px;
	    font-weight: 400;
	    line-height: 1.42857143;
	    text-align: center;
	    white-space: nowrap;
	    vertical-align: middle;
	    cursor: pointer;
	    user-select: none;
	    background-image: none;
	    border: 1px solid transparent;
	    border-radius: 4px;
	}
	.fixfromrandom {
		display: inline-block;
	    width: 260px;
	    height: 275px;
	    background: #25c08e;
	    margin-left: 35px;
	    margin-top: 15px;
	}
	.iconfixfromrandom {
	    color: #fff;
	    margin-left: 85px;
	    margin-top: 14px;
	    font-size: 100px;
	}
</style>
