<template>
	<div class="syle">
		<div style="padding:15px 20px;background-color: #f7f9fb;">
			<div style="border: 1px solid #e6e9ee;margin-bottom: 5px;height: 46px;border-bottom: 1px solid #eee;float: left;width:100% ">
				<div style="color: #2b71c8;border-bottom: 2px solid #2b71c8;width: 150px;height: 46px;line-height: 46px;padding: 8px 25px 10px 25px;font-size: 14px;float: left; ">
					<div style="margin-top: -10px;">
						<i class="fa fa-user-times"></i> 缺席统计
					</div>
				</div>
				<div style="font-size: 12px;float: right;padding: 4px;">
					<ButtonGroup style="padding: 0 4px 0 0;">
						<Button>
							<i class="fa fa-angle-double-down" aria-hidden="true"></i>
							查询
						</Button>
					</ButtonGroup>
					<ButtonGroup>
						<Button>
							<i class="fa fa-download" aria-hidden="true"></i>
							导出
						</Button>
					</ButtonGroup>
				</div>
			</div>
			<div class="table">
				<Table border :columns="columns1" :data="data1" ref="selection" size="small">
					<template slot-scope="{ row, index }" slot="action">
						<div @click="dialogVisible = true">
						<i class="fa fa-user-times" style="color: #2376e6"></i>
						<span style="font-size: 12px;color: #2376e6;">缺席人员</span>
						</div>
					</template>
				</Table>
			</div>
			<div style="margin: 20px 20px;text-align: left;padding-top: 8px;">
				共
				<span style="font-style: normal;color: #ff8000;">3</span> 条记录 ， 每页显示
				<Select v-model="model1" style="width:50px">
					<Option v-for="item in cityList" :value="item.value" :key="item.value">{{ item.label }}</Option>
				</Select>，跳转至：
				<Input v-model="value" style="width: 50px" />页
				<ButtonGroup>
					<Button>跳转</Button>
				</ButtonGroup>
				<!-- <Page :total="40" size="small" show-elevator show-sizer  show-total  /> -->
			</div>
		</div>
		<el-dialog :visible.sync="dialogVisible" width="1300px" :before-close="handleClose">
					<span style="color: #9f5a5a;position: absolute;top: 5px;font-size: 17px;">缺考人员-Nginx</span>
					<div class="topp">
						<img style="position: absolute;left: 31px;top: 79px;" src="../../public/images/23.png" />
						<span style="font-size: 15px;color: black;font-size: 15px;color: black;position: absolute;left: 55px;top: 76px;">缺席人员列表</span>
						<div class="dc-3-1">
							<img src="../../public/images/24.png" />
							<span>导出</span>
						</div>
						<span style="color: #a699b3;position: absolute;right: 129px;top: 77px;">|</span>
						<div class="cx-3-1" @click="ddd">
							<img src="../../public/images/13.png" />
							<span>查询</span>
						</div>
						<span style="color: #2b87d8;position: absolute;right: 235px;top: 77px;">|</span>
						<input style="position: absolute;right: 356px;top: 82px;" type="checkbox">
						<span style="color: #2b71c8;position: absolute;right: 251px;top: 78px;">未交卷也算缺考</span>
					</div>
					<div class="cha-4" v-show="dd">
						<span class="s1-3-1">关键词搜索</span><input class="in1-3-1" type="text" />
						<div class="cx2-3-1">
							<img src="../../public/images/15.png" />
							<span>查询</span>
						</div>
						<div class="cz-3-1">
							<img src="../../public/images/16.png" />
							<span>重置</span>
						</div>
					</div>
					<table cellspacing="0" style="position: relative;top: 5px;text-align: left;">
						<tr style="width: 1260px;height: 37px;background-color: white;font-weight: bold;">
							<td style="border: 1px solid #eeeeee;width: 400px;border-right: none;">账号</td>
							<td style="border: 1px solid #eeeeee;width: 300px;border-left: none;border-right: none;">姓名</td>
							<td style="border: 1px solid #eeeeee;width: 300px;border-left: none;border-right: none;">所属部门</td>
							<td style="border: 1px solid #eeeeee;width: 300px;border-left: none;border-right: none;">手机号码</td>
						</tr>
						<tr style="width: 1260px;height: 37px;background-color: white;">
							<td style="border: 1px solid #eeeeee;width: 400px;border-right: none;border-top: none;">521175582@qq.com</td>
							<td style="border: 1px solid #eeeeee;width: 200px;border-left: none;border-right: none;border-top: none;">海纳创新</td>
							<td style="border: 1px solid #eeeeee;width: 300px;border-left: none;border-right: none;border-top: none;">海纳创新</td>
							<td style="border: 1px solid #eeeeee;width: 400px;border-left: none;border-right: none;border-top: none;">18975019203</td>
						</tr>
						<tr style="width: 1260px;height: 37px;background-color: white;">
							<td style="border: 1px solid #eeeeee;width: 400px;border-right: none;border-top: none;">test1</td>
							<td style="border: 1px solid #eeeeee;width: 200px;border-left: none;border-right: none;border-top: none;">测试1</td>
							<td style="border: 1px solid #eeeeee;width: 300px;border-left: none;border-right: none;border-top: none;">海纳创新/后台</td>
							<td style="border: 1px solid #eeeeee;width: 400px;border-left: none;border-right: none;border-top: none;"></td>
						</tr>
						<tr style="width: 1260px;height: 37px;background-color: white;">
							<td style="border: 1px solid #eeeeee;width: 400px;border-right: none;border-top: none;">test2</td>
							<td style="border: 1px solid #eeeeee;width: 200px;border-left: none;border-right: none;border-top: none;">测试2</td>
							<td style="border: 1px solid #eeeeee;width: 300px;border-left: none;border-right: none;border-top: none;">海纳创新/后台</td>
							<td style="border: 1px solid #eeeeee;width: 400px;border-left: none;border-right: none;border-top: none;"></td>
						</tr>
					</table>
					<div class="db-2-1">
						<P>共<span style="color: #ff8000;">3</span>条记录，每页显示&nbsp;<select style="height: 20px;position: relative;top: -2px; border: 1px solid #d9d9d9;color: #73777a;">
								<option>100</option>
								<option>200</option>
								<option>300</option>
							</select>，跳转至:&nbsp;<input type="text" style="width: 30px;height: 20px;position: relative;top: -2px; border: 1px solid #d9d9d9;" />&nbsp;页
							<div class="tz-1">
								<span style="margin-left: 6px;">跳转</span>
							</div>
						</P>
						<div style="background-color: #222a35; width: 49px;height: 43px;border-radius: 5px;cursor: pointer;position: absolute;right: 22px;top: 29px;">
							<span style="color: white;margin-left: 18px;line-height: 43px;">1</span>
						</div>
					</div>
					<span slot="footer" class="dialog-footer">
						<el-button @click="dialogVisible = false">取 消</el-button>
						<el-button type="primary" @click="dialogVisible = false">确 定</el-button>
					</span>
				</el-dialog>
	</div>

</template>

<script>
	export default {
		data() {
			return {
				columns1: [{ //表格样式
						type: 'selection',
						width: 60,
						align: 'center'
					},
					{
						title: '名称',
						key: 'name',
						width: 410,
						align: 'center'
					},
					{
						title: '类型',
						key: 'type',
						width: 80,
						align: 'center'
					},
					{
						title: '开始时间/结束时间',
						key: 'date',
						align: 'center'
					},
					{
						title: '应参加人数',
						key: 'data1',
						width: 98,
						align: 'center'
					},
					{
						title: '已参加人数',
						key: 'data2',
						width: 98,
						align: 'center'
					},
					{
						title: '参考比例	',
						key: 'data3',
						width: 88,
						align: 'center'
					},
					{
						title: '缺考人数',
						key: 'data4',
						width: 88,
						align: 'center'
					},
					{
						title: '缺考比例',
						key: 'data5',
						width: 88,
						align: 'center'
					},
					{
						title: '操作',
						slot: 'action',
						width: 110,
						align: 'center'
					}
				],
				data1: [{ //表格数据
						name: 'Nginx',
						type: '考试',
						date: '2020-04-03 11:50 ~ 2020-04-10 11:50',
						data1: '3',
						data2: '0',
						data3: '0%',
						data4: '3',
						data5: '100%'
					},
					{
						name: 'Nginx',
						type: '考试',
						date: '2020-04-03 11:50 ~ 2020-04-10 11:50',
						data1: '3',
						data2: '0',
						data3: '0%',
						data4: '3',
						data5: '100%'
					},
					{
						name: 'Nginx',
						type: '考试',
						date: '2020-04-03 11:50 ~ 2020-04-10 11:50',
						data1: '3',
						data2: '0',
						data3: '0%',
						data4: '3',
						data5: '100%'
					}
				],
				cityList: [{
						value: "10",
						label: "10"
					},
					{
						value: "20",
						label: "20"
					},
					{
						value: "30",
						label: "30"
					},
					{
						value: "40",
						label: "40"
					},
					{
						value: "100",
						label: "100"
					},
					{
						value: "1000",
						label: "1000"
					}
				],
				model1: "20",
				value: "",
				dialogVisible: false
			}
		},
		methods:{
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {});
			}
		}
	}
</script>

<style scoped>
	.syle {

		background-color: #f7f9fb;
		min-height: 600px;
	}

	.top {
		display: inline-block;
		height: 35px;
		width: 100%;
		color: #fff;
		background: #2b71c8;
		border: 1px solid #e8e8e8;
		font-size: 12px;
		font-weight: 500;
		text-align: center;
		text-decoration: none;
		line-height: 35px;
	}

	.top1 {
		display: inline-block;
		height: 35px;
		width: 100%;
		color: #fff;
		background: #2b71c8;
		border: 1px solid #e8e8e8;
		font-size: 12px;
		font-weight: 500;
		text-align: center;
		text-decoration: none;
		line-height: 35px;
	}
	.db-2-1 p {
			position: absolute;
			top: 38px;
			left: 29px;
			color: #73777a;
		}
	
		.tz-1:hover {
			border: 1px solid #007DCE;
		}
	
		.tz-1 {
			border-radius: 5px;
			width: 45px;
			height: 22px;
			position: relative;
			top: -25px;
			left: 305px;
			border: 1px solid #d9d9d9;
			cursor: pointer;
		}
	
		.db-2-1 {
			background-color: white;
			height: 100px;
			width: 1260px;
			position: relative;
			top: 12px;
			border-radius: 5px;
		}
	
		.cx-3-1 span {
			margin-left: 25px;
			line-height: 36px;
			color: #6a7680;
		}
	
		.cx-3-1:hover {
			background-color: #eff2f5;
		}
	
		.cx-3-1 img {
			position: absolute;
			left: 9px;
			top: 14px;
		}
	
		.cx-3-1 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 146px;
			top: 69px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.dc-3-1 img {
			position: absolute;
			left: 12px;
			top: 10px;
		}
	
		.dc-3-1 span {
			margin-left: 31px;
			line-height: 36px;
			color: white;
		}
	
		.topp {
			border: 1px solid #e6e9ee;
			height: 50px;
			background-color: white;
		}
	
		.el-dialog__body {
			background-color: #f9fafc;
		}
	
		.db-2 p {
			position: absolute;
			top: 38px;
			left: 29px;
			color: #73777a;
		}
	
		.db-2 {
			background-color: white;
			height: 100px;
			width: 1252px;
			position: relative;
			top: -536px;
			left: 232px;
			border-radius: 5px;
		}
	
		html {
			overflow-x: hidden;
			overflow-y: auto;
		}
	
		.el-date-table {
			position: absolute;
			top: 250px;
			left: 244px;
		}
	
		tbody {
			position: absolute;
			top: -190px;
			left: -192px;
			z-index: 99;
			background-color: white;
		}
	
		.block {
			position: absolute;
			left: 480px;
			top: 24px;
		}
	
		td {
			color: #555555;
	
		}
	
	
		table {
			background-color: #eff2f5;
	
		}
	
		body {
			background-color: #f7f9fb;
		}
	
		.qxtj {
			border-bottom: 2px solid #2b71c8;
			width: 147px;
			height: 49px;
		}
	
		.tou-3 {
			background-color: white;
			height: 50px;
			width: 1252px;
			position: absolute;
			top: 90px;
			left: 232px;
			border: 1px solid #e6e9ee;
		}
	
		.qxtj img {
			position: relative;
			top: 18px;
			left: 26px;
		}
	
		.qxtj span {
			position: relative;
			left: 43px;
			top: 16px;
			color: #2b71c8;
		}
	
		.cx-3 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 88px;
			top: 7px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.dc-3-1 {
			width: 73px;
			height: 35px;
			border: 1px solid #2b71c8;
			position: absolute;
			right: 38px;
			top: 68px;
			border-radius: 6px;
			cursor: pointer;
			background-color: #2b71c8;
		}
	
		.dc-3 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 9px;
			top: 7px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.cx-3:hover,
		.dc-3:hover {
			background-color: #eff2f5;
		}
	
		.cx-3 img {
			position: absolute;
			left: 9px;
			top: 14px;
		}
	
		.dc-3 img {
			position: absolute;
			left: 6px;
			top: 11px;
		}
	
		.dc-3 span,
		.cx-3 span {
			margin-left: 25px;
			line-height: 36px;
			color: #6a7680;
		}
	
		.cha-3 {
			background-color: white;
			height: 90px;
			width: 1252px;
			position: relative;
			top: 71px;
			left: 225px;
			border-radius: 5px;
			border: 1px solid #e6e9ee;
		}
	
		.cha-4 {
			background-color: white;
			height: 90px;
			width: 1257px;
			position: relative;
			top: 3px;
			left: 1px;
			border-radius: 5px;
			border: 1px solid #e6e9ee;
		}
	
		.s1-3 {
			color: #777777;
			position: absolute;
			left: 29px;
			top: 36px;
			font-size: 12px;
		}
	
		.in1-3 {
			border: 1px solid #dbd9d9;
			width: 260px;
			height: 32px;
			position: absolute;
			left: 98px;
			top: 28px;
			border-radius: 3px;
		}
	
		.s2-3 {
			color: #777777;
			position: absolute;
			left: 423px;
			top: 36px;
			font-size: 12px;
		}
	
		.cx2-3 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 206px;
			top: 25px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.cz-3 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 128px;
			top: 25px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.cx2-3:hover,
		.cz-3:hover {
			background-color: #eff2f5;
		}
	
		.cx2-3 img {
			position: absolute;
			left: 8px;
			top: 11px;
		}
	
		.cz-3 img {
			position: absolute;
			left: 6px;
			top: 11px;
		}
	
		.cz-3 span,
		.cx2-3 span {
			margin-left: 25px;
			line-height: 36px;
			color: #6a7680;
		}
	
		.cx2-3-1 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 206px;
			top: 25px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.cz-3-1 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 128px;
			top: 25px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.cx2-3-1:hover,
		.cz-3-1:hover {
			background-color: #eff2f5;
		}
	
		.cx2-3-1 img {
			position: absolute;
			left: 8px;
			top: 11px;
		}
	
		.cz-3-1 img {
			position: absolute;
			left: 6px;
			top: 11px;
		}
	
		.cz-3-1 span,
		.cx2-3-1 span {
			margin-left: 25px;
			line-height: 36px;
			color: #6a7680;
		}
	
		.s1-3-1 {
			color: #777777;
			position: absolute;
			left: 29px;
			top: 36px;
			font-size: 12px;
		}
	
		.in1-3-1 {
			border: 1px solid #dbd9d9;
			width: 260px;
			height: 32px;
			position: absolute;
			left: 98px;
			top: 28px;
			border-radius: 3px;
		}
</style>
