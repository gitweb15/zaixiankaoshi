<template>
	<div>
		<Header></Header>
	<div class="main-box">
		<ul class="navtabs">
			<li class="lefttopborder" style="background-color: #469304;">
				<a href="#" style="color: white;"><strong>1</strong><span class="examflag">练习</span>信息</a>
				<i></i>
			</li>
			<li class="active">
				<a href="#"><strong>2</strong>设计试卷</a>
				<i></i>
			</li>
			<li class="righttopborder">
				<a href="#"><strong>3</strong>发布<span class="examflag">练习</span></a>
				<i></i>
			</li>
		</ul>
		<div class="append-box">
			<div class="tab-content" style="padding-bottom:80px;">
				<div @click="id=1" style="margin-bottom:4px;float:left;text-align:left;background:#fff;border:1px solid #e6e9ee;padding:8px 4px 8px 4px;width:100%;font-size:13px;margin:0 auto;">
					<span style="margin:0 auto;display:block;margin-left:2px;"><button class="btn btn-blue"><i class="fa fa-plus"
							 aria-hidden="true"></i> 创建练习大题</button><span style="float:right;margin-top:5px;">共 <em id="lNum" style="font-size:14px;color:red">0</em>
							道试题，共 <em id="lTotalScore" style="font-size:14px;color:red">0</em> 分</span></span>
				</div>
				<div class="con" v-if="id==1">
					<div class="btn-group btn-report">
						<h5><a href="javascript:" type="title" tid="ca95a1" class="big_title"><span>第 1 大题</span><i class="fa fa-pencil fa-fw"></i></a><a
							 id="btnEditBigTitleRemark" href="javascript:doEditTitle('ca95a1')" class="big_title"><i class="fa fa-file-text-o"
								 title="点击编辑大题描述信息"></i></a><span style="font-size:12px;">（<em id="nodeNumca95a1" style="font-size:14px;color:red">0</em>
								道试题，共 <em id="nodeScoreca95a1" style="font-size:14px;color:red">0.00</em> 分）</span></h5>
						
						<button type="button" style="border-color: #ccc;" class="btn btn-default" @click="id=0"><i class="fa fa-trash-o"></i>
							删除章节及子章节</button>
					</div>

					<table cellspacing="0" cellpadding="0" class="common-table table-border">
						<thead>
							<tr style="cursor: move;">
								<th width="3%" style="text-align:center" title="拖拽序号可重新排序">序号</th>
								<th width="45%">章节名称</th>
								<th width="8%">练习试题管理</th>
								<th width="5%">试题数量</th>
								<th width="5%" style="text-align:center">操作</th>
							</tr>
						</thead>
					</table>
					<div style="margin-bottom: 4px; text-align: center;line-height:25px; background: #fff; border: 1px solid #ddd;border-top:none;width: 100%; font-size: 13px; margin: 0 auto;padding:6px 2px;">
						<button id="btnAddExer" class="btn btn-default" type="button" style="padding:3px 6px;border: 1px solid #ddd;border-radius: 4px;"><i class="fa fa-plus" aria-hidden="true"></i>   添加子章节</button>
					</div>
				</div>
			</div>
			<div class="bottom">
				<button class="btn btn-blue" type="button" @click="tanchu">
					<i class="fa fa-circle-o-notch fa-spin fa-fw margin-bottom"></i>
					完成设计 & 去发布练习
				</button>
				<button class="btn btn-default" style="font-size:13px;border-color: #ccc;"><i class="fa fa-eye"></i> 预览练习</button>
				<a style="border-color: #ccc;" class="btn btn-default" @click="$router.go(-1)"><i class="fa fa-reply" aria-hidden="true"></i> 上一步</a>
			</div>
			
		</div>
	</div>
	</div>
</template>

<script>
import Header from '@/components/Header/index.vue'
	export default {
		components:{Header},
		data() {
			return {
				kouling: 810438, //口令
				id: 0
			}
		},
		methods:{
			tanchu(){
				this.$router.push('/createLianxi3')
			}
		}
	}
</script>

<style scoped>
	.tab-content {
		float: left;
		width: 100%;
		padding: 0 20px;
	}

	.tab-content .con {
		margin-bottom: 16px;
	}

	.btn-report {
		width: 100%;
		padding: 5px;
		text-align: right;
		border-top-left-radius: 3px;
		border-top-right-radius: 3px;
		border: 1px solid #e6e9ee;
		border-bottom: none;
		background-color: #fff;
	}

	.btn-group,
	.btn-group-vertical {
		position: relative;
		display: inline-block;
		vertical-align: middle;
	}

	.btn-report h5 {
		float: left;
		margin: 0;
		padding-left: 5px;
		line-height: 25px;
		font-size: 16px;
	}

	.big_title {
		font-size: 14px;
		color: #333;
	}

	.btn-report .btn {
		float: inherit;
		padding: 4px 12px;
		font-size: 12px;
		border-radius: 3px !important;
	}

	.common-table {
		width: 100%;
		border: 1px solid #e6e9ee;
		color: #222;
	}

	table {
		background-color: transparent;
	}

	table {
		border-spacing: 0;
		border-collapse: collapse;
	}

	.table-border td,
	.table-border th {
		border-right: 1px solid #e6e9ee;
		border-bottom: 1px solid #e6e9ee;
	}

	.common-table th {
		padding: 7px 0 7px 5px;
		color: #555;
		line-height: 22px;
		text-align: left;
		word-wrap: break-word;
		background-color: #eff2f5;
	}

	.main-box {
		float: left;
		padding: 15px 20px 20px 20px;
		width: 100%;
		min-height: 600px;
		background-color: #f7f9fb;
	}

	.navtabs {
		float: left;
		margin-bottom: 10px;
		height: 45px;
		width: 100%;
		border-top-left-radius: 12px;
		border-top-right-radius: 12px;
		border: 1px solid #e6e9ee;
		border-bottom: none;
		background-color: #e2e9ef;
	}

	.navtabs li a {
		display: inline-block;
		width: 100%;
		height: 45px;
		line-height: 45px;
		font-size: 16px;
		color: #999;
		cursor: not-allowed;
		border-right: 1px solid #fff;
	}

	.navtabs li.active a {
		color: #fff;
		cursor: pointer;
		background-color: #173689;
	}

	.navtabs li strong {
		position: absolute;
		top: 7px;
		left: 30%;
		font-size: 28px;
		line-height: 1em;
		font-weight: 500;
	}

	.navtabs li.lefttopborder,
	.navtabs li.lefttopborder a {
		border-top-left-radius: 12px;
	}

	.navtabs li {
		position: relative;
		float: left;
		width: 33.33333333333%;
		text-align: center;
		cursor: pointer;
	}

	.navtabs li.active i {
		position: absolute;
		left: 47.5%;
		bottom: 0;
		border-color: transparent transparent #f7f9fb transparent;
		border-style: dashed dashed solid dashed;
		border-width: 8px;
		display: block;
		font-size: 0;
		width: 0;
		height: 0;
		line-height: 0;
	}

	.append-box {
		position: relative;
		float: left;
		width: 100%;
		margin-bottom: 15px;
		padding-top: 10px;
		padding-bottom: 20px;
		border-radius: 3px;
		border: 1px solid #e6e9ee;
		background-color: #fff;
	}

	.append-box h4 {
		margin-top: -11px;
		margin-bottom: 10px;
		height: 40px;
		line-height: 40px;
		text-indent: 20px;
		font-size: 16px;
		color: #555;
		border-top: 1px solid #e6e9ee;
		background-color: #f9f9f9;
		font-weight: 500;
	}

	fieldset {
		min-width: 0;
		padding: 0;
		margin: 0;
		border: 0;
	}

	.append-box fieldset {
		margin-bottom: 10px;
		padding: 0 15px 10px 15px;
	}

	.append-box .form-group {
		margin-right: 0;
		margin-bottom: 0;
	}

	.append-box .control-label {
		padding-right: 5px;
		font-weight: 500;
		color: #777;
		padding-top: 7px;
	}

	.control-label {
		font-size: 13px;
	}

	.col-sm-2 {
		width: 16.66666667%;
		float: left;
		position: relative;
		min-height: 1px;
		padding-right: 15px;
		padding-left: 15px;
	}

	.col-sm-5 {
		width: 41.66666667%;
		float: left;
		position: relative;
		min-height: 1px;
		padding-right: 15px;
		padding-left: 15px;
	}

	.col-sm-7 {
		width: 58.33333333%;
		float: left;
		position: relative;
		min-height: 1px;
		padding-right: 15px;
		padding-left: 15px;
	}

	.append-box p {
		margin: 10px 0 0 0;
	}

	.form-control {
		padding-left: 5px;
		border-color: #dbd9d9;
		box-shadow: none;
		font-size: 13px;
		overflow-x: hidden;
		display: block;
		width: 100%;
		height: 34px;
		padding: 6px 12px;
		font-size: 14px;
		line-height: 1.42857143;
		color: #555;
		background-color: #fff;
		background-image: none;
		border: 1px solid #ccc;
		border-radius: 4px;
		transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
	}

	.input-group-btn {
		position: absolute;
		top: 0;
		right: 15px;
		white-space: nowrap;
		vertical-align: middle;
		display: inline-block;
	}

	button {
		overflow: visible;
	}

	.btn {
		display: inline-block;
		padding: 6px 12px;
		margin-bottom: 0;
		font-size: 14px;
		font-weight: 400;
		line-height: 1.42857143;
		text-align: center;
		white-space: nowrap;
		vertical-align: middle;
		cursor: pointer;
		user-select: none;
		background-image: none;
		border: 1px solid transparent;
		border-radius: 4px;
	}

	.btn-default {
		color: #333;
		background-color: #fff;
		border-color: #ccc;
	}

	.caret {
		display: inline-block;
		width: 0;
		height: 0;
		margin-left: 2px;
		vertical-align: middle;
		border-top: 4px solid;
		border-right: 4px solid transparent;
		border-left: 4px solid transparent;
	}

	textarea.form-control {
		height: auto;
	}

	label {
		display: inline-block;
		max-width: 100%;
		margin-bottom: 5px;
		font-weight: 700;
	}

	.help-block {
		font-size: 12px;
	}

	.append-box .bottom {
		display: inline-block;
		padding: 6px 0 6px 0;
		width: 100%;
		text-align: center;
		position: fixed;
		bottom: 0;
		left: 0;
		z-index: 11;
		background: #f8f8f8;
		border-top: 1px solid #eee;
	}

	.btn-blue {
		border-radius: 3px;
		color: #fff;
		border: none;
		cursor: pointer;
		background-color: #2b71c8;
	}

	.append-box .bottom .btn {
		margin-right: 15px;
		min-width: 100px;
		height: 35px;
		line-height: 1em;
		padding: 8px 20px;
	}

	.fix {
		width: 260px;
		height: 275px;
		background: #479de6;
		display: inline-block;
		margin-top: 15px;
	}

	.iconfix {
		color: #fff;
		margin-left: 75px;
		margin-top: 14px;
		font-size: 100px;
	}

	.iconrandom {
		color: #fff;
		margin-left: 85px;
		margin-top: 14px;
		font-size: 100px;
	}

	.typetext {
		color: #fff;
		text-align: center;
		font-size: 20px;
		margin-top: 8px;
	}

	.typetextdetail {
		color: #fff;
		text-align: center;
		font-size: 13px;
		margin-top: 15px;
	}

	.btn_create_exam {
		background: #fff;
		color: #4597df;
		border: 1px solid #999;
		margin-top: 15px;
		margin-left: 75px;
	}

	.btn {
		display: inline-block;
		padding: 6px 12px;
		margin-bottom: 0;
		font-size: 14px;
		font-weight: 400;
		line-height: 1.42857143;
		text-align: center;
		white-space: nowrap;
		vertical-align: middle;
		cursor: pointer;
		user-select: none;
		background-image: none;
		border: 1px solid transparent;
		border-radius: 4px;
	}

	.fixfromrandom {
		display: inline-block;
		width: 260px;
		height: 275px;
		background: #25c08e;
		margin-left: 35px;
		margin-top: 15px;
	}

	.iconfixfromrandom {
		color: #fff;
		margin-left: 85px;
		margin-top: 14px;
		font-size: 100px;
	}
</style>
