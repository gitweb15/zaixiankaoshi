<template>
	<div class="syle">
		<div style="padding:15px 20px;background-color: #f7f9fb;">
			<div style="border: 1px solid #e6e9ee;    margin-bottom: 5px;
    height: 46px;
    border-bottom: 1px solid #eee;float: left;width:100% ">
				<div style="color: #2b71c8;
    border-bottom: 2px solid #2b71c8;width: 150px;
    height: 46px;
    line-height: 46px;
    padding: 8px 20px 10px 20px;font-size: 14px;float: left; ">
	<div style="margin-top: -10px;">
		<i class="fa fa-tv"></i> 培训学习统计
	</div>
					
				</div>
				<div style="font-size: 12px;
    float: right;
    padding: 4px;">

					<ButtonGroup style="padding: 0 4px 0 0;">
						<Button>
							<i class="fa fa-angle-double-down" aria-hidden="true"></i>
							查询
						</Button>
					</ButtonGroup>



					<ButtonGroup>
						<Button>
							<i class="fa fa-download" aria-hidden="true"></i>
							导出
						</Button>


					</ButtonGroup>

				</div>
			</div>
			<div class="table">
				<Table border :columns="columns1" :data="data1" ref="selection" size="small">
					<template slot-scope="{ row, index }" slot="action">
						<div @click="dialogVisible=true">
						<i class="fa fa-bar-chart-o" style="color: #2376e6"></i> <span style="font-size: 12px;
							color: #2376e6;">学院进度</span>
						</div>
					</template>
				</Table>
			</div>
			<div style="margin: 20px 20px;
    text-align: left;
    padding-top: 8px;">
				共
				<span style="    font-style: normal;
    color: #ff8000;">1</span> 条记录 ， 每页显示
				<Select v-model="model1" style="width:50px">
					<Option v-for="item in cityList" :value="item.value" :key="item.value">{{ item.label }}</Option>
				</Select>，跳转至：
				<Input v-model="value" style="width: 50px" />页
				<ButtonGroup>
					<Button>跳转</Button>
				</ButtonGroup>
				<!-- <Page :total="40" size="small" show-elevator show-sizer  show-total  /> -->
			</div>
		</div>
		<el-dialog title="" :visible.sync="dialogVisible" width="1300px" :before-close="handleClose">
					<span style="color: #5a5a5a;font-size: 15px;position: absolute;top: 6px;">学习统计-Redis</span>
					<div class="topp-1">
						<img style="position: absolute;left: 41px;top: 70px;" src="../../public/images/29.png" />
						<span style="position: absolute;left: 74px;top: 74px;font-size: 15px;">学习记录</span>
						<div class="dc-3-1">
							<img src="../../public/images/24.png" />
							<span>导出</span>
						</div>
						<span style="color: #a699b3;position: absolute;right: 129px;top: 77px;">|</span>
						<div class="cx-3-1" @click="abc1">
							<img src="../../public/images/13.png" />
							<span>查询</span>
						</div>
					</div>
					<div class="cha-4" v-show="abc">
						<span class="s1-3-1">关键词搜索</span><input class="in1-3-1" type="text" />
						<span class="s2-1">学习状态</span>
						<template>
							<el-select v-model="value" placeholder="请选择">
								<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
								</el-option>
							</el-select>
						</template>
						<div class="cx2-3-1">
							<img src="../../public/images/15.png" />
							<span>查询</span>
						</div>
						<div class="cz-3-1">
							<img src="../../public/images/16.png" />
							<span>重置</span>
						</div>
					</div>
					<table cellspacing="0" style="position: relative;top: 5px;">
						<tr style="height: 60px; background-color: white; text-align: center; font-size: 17px;">
							<td style="border: 1px solid #eeeeee; width: 208px;border-right: none;">应参加人数<br>3</td>
							<td style="border: 1px solid #eeeeee; width: 208px;border-right: none;">已参加人数<br>1</td>
							<td style="border: 1px solid #eeeeee; width: 208px;border-right: none;">缺席人数<br>2</td>
							<td style="border: 1px solid #eeeeee; width: 208px;border-right: none;">完成课程人数<br>1</td>
							<td style="border: 1px solid #eeeeee; width: 208px;border-right: none;">未完成课程人数<br>3</td>
							<td style="border: 1px solid #eeeeee; width: 210px;">课程通过率<br>0%</td>
						</tr>
					</table>
					<table cellspacing="0" style="position: relative;top: 10px;">
						<tr style="height: 30px; background-color: white; text-align: center; font-size: 17px;font-weight: 550;">
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">账号</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">姓名</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">所属部门</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">开始时间/结束时间</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">学习时长</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">学习次数</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">所得学分</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">学习进度</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">状态</td>
							<td style="border: 1px solid #eeeeee; width: 140px;border-right: none;">设备</td>
							<td style="border: 1px solid #eeeeee; width: 140px;">操作</td>
						</tr>
						<tr style="height: 30px; background-color: white; text-align: center; font-size: 17px;">
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">test1</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">测试1</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">后台</td>
							<td style="border: 1px solid #eeeeee; width: 250px;border-right: none;border-top: none;">2020-04-03 11:20~2020-04-03 11:39</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">0分21秒</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">14</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">0.00</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">1%</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">学习中</td>
							<td style="border: 1px solid #eeeeee; width: 145px;border-right: none;border-top: none;">移动端</td>
							<td style="border: 1px solid #eeeeee; width: 145x;border-top: none;">学习明细</td>
						</tr>
						<tr style="height: 30px; background-color: white; text-align: center; font-size: 17px;">
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">521175582@qq.com</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">海纳创新</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">海纳创新</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">2020-04-03 11:20~2020-04-03 11:39</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">0分0秒</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">8</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">0.00</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">0%</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">学习中</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">移动端</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-top: none;">学习明细</td>
						</tr>
					</table>
					<div class="ddd" style="border: 1px solid #eeeeee; text-align: center; width: 1258px;height: 35px;position: relative;top: 26px;">
						<span style="line-height: 35px;">共2条记录</span>
					</div>
					<span slot="footer" class="dialog-footer">
						<el-button @click="dialogVisible = false">取 消</el-button>
						<el-button type="primary" @click="dialogVisible = false">确 定</el-button>
					</span>
				</el-dialog>
	</div>

</template>

<script>
	export default {
		data() {
			return {
				columns1: [{//表格样式
						type: 'selection',
						width: 60,
						align: 'center'
					},
					{
						title: '课程名称',
						key: 'name',
						width: 315,
						align: 'center'
					},
					{
						title: '开始时间/结束时间',
						key: 'date',
						align: 'center'
					},
					{
						title: '参加方式',
						key: 'data1',
						width: 88,
						align: 'center'
					},
					{
						title: '完成条件',
						key: 'data2',
						width: 118,
						align: 'center'
					},
					{
						title: '参加人数	',
						key: 'data3',
						width: 88,
						align: 'center'
					},
					{
						title: '完成课程人数',
						key: 'data4',
						width: 110,
						align: 'center'
					},
					{
						title: '未完成人数',
						key: 'data5',
						width: 98,
						align: 'center'
					},
					{
						title: '课程通过率',
						key: 'data6',
						width: 98,
						align: 'center'
					},
					{
						title: '操作',
						slot: 'action',
						width: 110,
						align: 'center'
					}
				],
				data1: [{//表格数据
						name: 'Redis',
						date: '2020-04-01 18:22 ~ 2020-05-01 18:22',
						data1: '安排学习',
						data2: '达到课程学时',
						data3: '2',
						data4: '0',
						data5: '2%',
						data6: '0%'
					}
				],
				cityList: [{
						value: "10",
						label: "10"
					},
					{
						value: "20",
						label: "20"
					},
					{
						value: "30",
						label: "30"
					},
					{
						value: "40",
						label: "40"
					},
					{
						value: "100",
						label: "100"
					},
					{
						value: "1000",
						label: "1000"
					}
				],
				model1: "10",
				value: "",
				abc: false,
				dialogVisible: false
			}
		},
		methods:{
			abc1() {
				if (this.abc == false) {
					this.abc = true
				} else {
					this.abc = false
				}
			},
			handleClose(done) {
				this.$confirm('确认关闭？')
					.then(_ => {
						done();
					})
					.catch(_ => {});
			}
		}
	}
</script>

<style scoped>
	.syle {

		background-color: #f7f9fb;
		min-height: 600px;
	}

	.top {
		display: inline-block;
		height: 35px;
		width: 100%;
		color: #fff;
		background: #2b71c8;
		border: 1px solid #e8e8e8;
		font-size: 12px;
		font-weight: 500;
		text-align: center;
		text-decoration: none;
		line-height: 35px;
	}

	.top1 {
		display: inline-block;
		height: 35px;
		width: 100%;
		color: #fff;
		background: #2b71c8;
		border: 1px solid #e8e8e8;
		font-size: 12px;
		font-weight: 500;
		text-align: center;
		text-decoration: none;
		line-height: 35px;
	}
	.cx-3-1{
		width: 73px;
		height: 35px;
		line-height: 40px;
		border: 1px solid #cccccc;
		position: absolute;
		right: 150px;
		top: 68px;
		border-radius: 6px;
		cursor: pointer;
		text-align: center;
	}
	.dc-3-1{
		width: 73px;
		height: 35px;
		line-height: 40px;
		border: 1px solid #cccccc;
		position: absolute;
		right: 40px;
		top: 68px;
		border-radius: 6px;
		cursor: pointer;
		text-align: center;
		background-color: #2B71C8;
		color: #FFFFFF;
	}
	.cx-3-1{
		width: 73px;
		height: 35px;
		line-height: 40px;
		border: 1px solid #cccccc;
		position: absolute;
		right: 150px;
		top: 68px;
		border-radius: 6px;
		cursor: pointer;
		text-align: center;
	}
	.dc-3-1{
		width: 73px;
		height: 35px;
		line-height: 40px;
		border: 1px solid #cccccc;
		position: absolute;
		right: 40px;
		top: 68px;
		border-radius: 6px;
		cursor: pointer;
		text-align: center;
		background-color: #2B71C8;
		color: #FFFFFF;
	}
		
	.cx2-3-1 {
		width: 73px;
		height: 35px;
		border: 1px solid #cccccc;
		position: absolute;
		right: 206px;
		top: 25px;
		border-radius: 6px;
		cursor: pointer;
	}
		
	.cz-3-1 {
		width: 73px;
		height: 35px;
		border: 1px solid #cccccc;
		position: absolute;
		right: 128px;
		top: 25px;
		border-radius: 6px;
		cursor: pointer;
	}
		
	.cx2-3-1:hover,
	.cz-3-1:hover {
		background-color: #eff2f5;
	}
		
	.cx2-3-1 img {
		position: absolute;
		left: 8px;
		top: 11px;
	}
		
	.cz-3-1 img {
		position: absolute;
		left: 6px;
		top: 11px;
	}
		
	.cz-3-1 span,
	.cx2-3-1 span {
		margin-left: 25px;
		line-height: 36px;
		color: #6a7680;
	}
		
	.cha-4 {
		background-color: white;
		height: 90px;
		width: 1258px;
		position: relative;
		top: 5px;
		border-radius: 5px;
		border: 1px solid #e6e9ee;
	}
		
	.topp-1 {
		border: 1px solid #e6e9ee;
		height: 50px;
		background-color: white;
	}
		
	
</style>
