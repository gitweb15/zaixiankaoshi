<template>
    <div class="syle">
     <!-- 新增考生弹出框-->
       <Modal v-model="modal5" @on-cancel="cancel" width="800" footer-hide title="新增考生" >
            <div class="main1">
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">账号<i style="color:red">*</i></label>
                    <div>
                        <input name="txtLoginID" type="text" id="txtLoginID"  style="width: 400px;" class="form-control required">
                    </div>
                </div>
               <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">姓名<i style="color:red">*</i></label>
                    <div>
                        <input name="txtLoginID" type="text" id="txtLoginID" style="width: 400px;" class="form-control required">
                    </div>
                </div>
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">密码</label>
                    <div >
                        <input name="txtLoginID" type="text" id="txtLoginID" style="width: 400px;" class="form-control required">
                    </div>
                </div>
                <div class="form-group ">
                    <label class="col-sm-2 control-labels">所属部门<i style="color:red">*</i></label>
                    <div class="input-group">
                        <input name="txtDeptName" type="text" class="form-control" style="width: 333px;" value="海纳创新" >
                        <div class="input-group-btn" style="left: 332px">
                        <button id="btnSelectDept" type="button" style="height:34px;" class="btn btn-default dropdown-toggle" data-toggle="dropdown" >选择 <span class="caret"></span></button>
                        </div>
                    </div>     
                </div>
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">手机号码</label>
                    <div>
                        <input name="txtLoginID" type="text" id="txtLoginID" style="width: 400px;" class="form-control required">
                    </div>
                </div>
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">邮箱</label>
                    <div>
                        <input name="txtLoginID" type="text" id="txtLoginID" style="width: 400px;" class="form-control required">
                    </div>
                </div>
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">证件号码</label>
                    <div>
                        <input name="txtLoginID" type="text" id="txtLoginID" style="width: 400px;" class="form-control required">
                    </div>
                </div>
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">性别</label>
                    <div>
                        <select name="ddlSex" id="ddlSex" class="form-control valid" style="width: 400px;">
                            <option value=""></option>
                            <option value="男"> 男 </option>
                            <option value="女"> 女 </option>
                        </select>
                    </div>
                </div>
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">状态</label>
                    <div>
                        <select name="ddlUserStatus" id="ddlUserStatus" style="width: 400px;" class="form-control valid">
                            <option selected="selected" value="Normal">激活</option>
                            <option value="Locked">锁定</option>
                            <option value="Pending">挂起</option>
                            <option value="Disabled">禁用</option>
                        </select>
                    </div>
                </div>
                <div class="form-group " style="height:65px">
                    <label class="col-sm-2 control-labels">备注</label>
                    <div>
                        <textarea name="txtRemark" id="txtRemark" style="width: 400px;" class="form-control required"></textarea>
                    </div>
                </div>
                <div class="bottom" style="background:#fff;text-align: center;">
                    <button type="button" class="btn btn-blue" onclick=""><i class="fa fa-calendar-o"></i>   保 存</button>        
                    <button type="button" class="btn btn-default" onclick=""><i class="fa fa-calendar-times-o" ></i>  保存并关闭</button>       
                    <button type="button" class="btn btn-default" onclick=""><i class="fa fa-calendar-plus-o"></i>  保存并新增</button>
                    <button type="button" class="btn btn-default" onclick=""><i class="fa fa-window-close-o"></i>   关 闭</button>
                </div>
            </div>
        </Modal>
    </div>

</template>

<script>
export default {
    data(){
        return{
           modal5: true//默认弹出
        }
    },
    methods:{
       cancel(){//退出
           this.$router.push("/examinee")
       },
    },
}
</script>

<style scoped>
.control-labels{
    width: 150px;
    height: 40px;
    vertical-align: middle;
    line-height: 40px;
}

   .append-box {
        width: 100%;
        margin-bottom: 15px;
        padding-top: 10px;
        padding-bottom: 20px;
        border-radius: 3px;
        background-color: #fff;
    }
    .append-box fieldset {
        margin-bottom: 10px;
        padding: 0 15px 10px 15px;
    }
    fieldset {
        display: block;
        margin-inline-start: 2px;
        margin-inline-end: 2px;
        padding-block-start: 0.35em;
        padding-inline-start: 0.75em;
        padding-inline-end: 0.75em;
        padding-block-end: 0.625em;
        min-inline-size: min-content;
        border-width: 2px;
        border-style: groove;
        border-color: threedface;
        border-image: initial;
        border: 0;
        
    }

.form-control {
    padding-left: 5px;
    border-color: #dbd9d9;
    box-shadow: none;
    font-size: 13px;
    overflow-x: hidden;
}
.form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);

}
.append-box fieldset.col2 .form-group {
    float: left;
    width: 50%;
}
.append-box .control-label {
    padding-right: 5px;
    font-weight: 500;
    color: #777;
    padding-top: 7px;
}
.col-sm-1, .col-sm-2, .col-sm-9,.col-sm-9 .input-group-btn{
    float: left;
}
.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
.btn-red {
    border-radius: 3px;
    color: #fff;
    border: none;
    cursor: pointer;
    background-color: red;
}
.btn-default {
    color: #333;
    background-color: #fff;
    border-color: #ccc;
}
.caret {
    display: inline-block;
    margin-left: 2px;
    vertical-align: middle;
    border-top: 4px solid;
    border-right: 4px solid transparent;
    border-left: 4px solid transparent;
}
.form-group {
    display: flex;
}
.input-group-btn{
    position: relative;
    left: 245px;
    bottom: 34px;
}
.htmleditor {
    float: right;
    margin-top: -20px;
    padding-right: 20px;
    color: #2b71c8;
    position: relative;
}

.form-control {
    padding-left: 5px;
    border-color: #dbd9d9;
    box-shadow: none;
    font-size: 13px;
    overflow-x: hidden;
}
textarea {
    resize: none;
}
.common-table th {
    padding: 7px 0 7px 5px;
    color: #555;
    line-height: 22px;
    text-align: left;
    word-wrap: break-word;
    background-color: #eff2f5;
    text-align: center;
}
.append-box .bottom {
    display: inline-block;
    padding: 6px 0 6px 0;
    width: 100%;
    text-align: center;
    z-index: 11;
    background: #f8f8f8;
    border-top: 1px solid #eee;
}


</style>