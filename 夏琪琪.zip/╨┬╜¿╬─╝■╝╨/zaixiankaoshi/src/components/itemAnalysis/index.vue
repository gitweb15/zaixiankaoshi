<template>
	<div>
        <div class="main-box1">  
           <div class="tabmenu">
            <a href="#" class="active"><i class="fa fa-area-chart pdd"></i> 试题分析</a> 
            <span style="font-size:12px;float:right;padding:4px;">
                <button type="button" class="btn btn-default" onclick=""><i class="fa fa-angle-double-down"></i>  查询</button>
                <button type="button" class="btn btn-default" onclick=""><i class="fa fa-download" ></i>  导出</button>
            </span>
        </div>
       
            <Table border ref="selection" :columns="columns4"  size="small"></Table>
            <div class="pagination pages" style="width:100%;background:#fff;color:#73777a;font-size:13px;text-align:right;padding-right:4px;margin:0 auto;">        
            <div style="float:left;margin:20px 20px;text-align:right;padding-top:8px;">
                共<span id="lTotalCount" class="org">1</span>条记录， 
                每页显示 
                <select id="ddlPageSize" style="line-height:25px;min-height:25px;padding:2px 4px;border:1px solid #d9d9d9">
	                <option selected="selected" value="10">10</option>
	                <option value="20">20</option>
	                <option value="50"> 50 </option>
	                <option value="100"> 100 </option>
	                <option value="200"> 200 </option>
	                <option value="300"> 300 </option>
	                <option value="500"> 500 </option>
	                <option value="1000"> 1000 </option>
	                <option value="2000"> 2000 </option>
                </select>
                 ，跳转至：<input type="text" id="txtGoPage" style="line-height:20px;min-height:20px;padding:2px 4px;border:1px solid #d9d9d9;width:40px"> 页
                <button id="btnGoPage" type="button" class="btn btn-default" style="padding:2px 8px 3px 8px;" onclick="">跳转</button>
            </div>
            <div id="pager" class="pager clearfix" style=""><span class="current">1</span></div>
        </div>
        </div>
        <Modal
        v-model="modal1"
        title="信息提示"
        width="400"
        >
            <div  style="height: 110px;">                
                <table height="100%" border="0" align="center" cellpadding="10" cellspacing="0">		
                    <tr>
                        <td style="vertical-align:middle">
                        <img src="../../assets/icon_alert.png" width="34" height="34" align="absmiddle"></td>			
                        <td style="vertical-align:middle;padding-left:8px;font-size:13px;" align="left">
                            提示：此功能只对付费版本开放，
                            <a href="http://www.kaoshiyun.com.cn/buy" style="color:rgb(255, 106, 0)">点击升级!</a>
                        </td>
                    </tr>	
                </table>              
            </div>
             <div slot="footer" style="text-align: center;">
                <Button  size="large" @click="cancel" >确定</Button>
            </div>
        </Modal>
	</div>
</template>

<script>
export default {
	name: "practice",
    data(){
      return {
          modal1:true,
          columns4: [//表格样式
            {
                type: 'selection',
                align: 'center',
                width: 60
                
            },
            {
                title: '试题内容',
                key: 'name1'
            },
            {
                title: '题型',
                key: 'name2'
            },
            {
                title: '试题分类',
                key: 'name3'
            },
            {
                title: '试题难度',
                key: 'name4'
            },
            {
                title: '标准答案',
                key: 'name5'
            },
            {
                title: '答题次数',
                key: 'name6',
            },
            {
                title: '答错次数',
                key: 'name7',
                align: 'center',
            },
            {
                title: '答错概率',
                key: 'name8',
                align: 'center',
            },
            {
                title: '答对次数',
                key: 'name9',
                align: 'center',
              
            },
            {
                title: '答对概率',
                key: 'name10',
                align: 'center',
              
            },
            {
                title: '得分概率',
                slot: 'name',
                width: 67,
                align: 'center'
            }
        ],
        data1: [
            {
                name1: '',
                name2: '',
                name3: '',
                name4: '',
                name5: '',
                name6: '',
                name7: '',
                name8: '',
                name9: '',
                name10: '',
            },
           
        ]
      }
    },
    created(){
        
    },
	methods:{
        cancel(){//退出弹出框
            this.modal1=false
        }
	}
}
</script>

<style scoped>
	.main-box1 {
        float: left;
        padding: 15px 20px 20px 20px;
        width: 100%;
        min-height: 600px;
        background-color: #f7f9fb;
        
    }
    .tabmenu {
        width: 100%;
        border: 1px solid #e6e9ee;
        background: #fff;
        margin-bottom: 5px;
        height: 46px;
        border-bottom: 1px solid #eee;
        color: #999;
    }
   .tabmenu a {
        color: #000;
        top: 1px;
        width: 150px;
        height: 46px;
        line-height: 46px;
        padding: 8px 25px 10px 25px;
        left: 150px;
        text-align: center;
        font-size: 14px;
        color: #428bca;
        text-decoration: none;
    }
    .btn-default {
        color: #333;
        background-color: #fff;
        border-color: #ccc;
    }
    .btn {
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857143;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        cursor: pointer;
        background-image: none;
        border: 1px solid #e6e9ee;
        border-radius: 4px;
        margin-left: 3px;
    }
    .pages {
        display: inline-block;
        width: 100%;
        color: #555;
        text-align: center;
    }

    .pagination {
        display: inline-block;
        padding-left: 0;
        margin: 20px 0;
        border-radius: 4px;
    }
    .pager span.current {
        background-color: #222a35;
        color: #fff;
        border-color: #ebebeb;
    }
    .pager a, .pager span {
        width: 45px;
        height: 40px;
        border: 1px solid #ebebeb;
        margin-left: -1px;
        color: #8a8a8a;
        display: inline-block;
        line-height: 40px;
        font-size: 15px;
        text-decoration: none;
        margin: 0 2px;
        border-radius: 6px;
        text-align: center;
        margin-top: 15px;
    }
  
</style>
