<template>
	<div>
        <div class="main-box1">  
           <div class="tabmenu">
            <a href="#" class="active"><i class="fa fa-address-card-o"></i>  练习统计</a> 
            <span style="font-size:12px;float:right;padding:4px;">
                <button type="button" class="btn btn-default" onclick=""><i class="fa fa-angle-double-down" aria-hidden="true"></i>  查询</button>
                <button type="button" class="btn btn-default" onclick=""><i class="fa fa-download" aria-hidden="true"></i>  导出</button>
            </span>
        </div>
        <dl class="sievebar" style="display:none">
            <dt class="item">关键字搜索</dt>
            <dd class="con input">
                <input name="txtSearchField" type="text" id="txtSearchField" class="form-control"></dd>            
            <dt class="item">创建时间</dt>
            <dd class="con input">
                <input name="txtBeginTime" type="text" id="txtBeginTime" class="form-control icon-date width-48" autocomplete="off" style="">-<input name="txtEndTime" type="text" id="txtEndTime" class="form-control icon-date width-48" autocomplete="off" style=""></dd>
            
            <dt class="item"></dt>
            <dd class="con">
                <button id="btnSearch" class="btn btn-default" onclick=""><i class="fa fa-search" aria-hidden="true"></i>   查 询</button>
                <button class="btn btn-default" type="reset" onclick=""><i class="fa fa-refresh" aria-hidden="true"></i>   重 置</button>
            </dd>
        </dl>
            <Table border ref="selection" :columns="columns4" :data="data1" size="small">
                <a @click="dialogVisible = true" style="font-size:12px;color:#2376e6"  slot="name"><i class="fa fa-bar-chart-o"></i> 练习统计</a>
            </Table>
            <div class="pagination pages" style="width:100%;background:#fff;color:#73777a;font-size:13px;text-align:right;padding-right:4px;margin:0 auto;">            
            <div style="float:left;margin:20px 20px;text-align:right;padding-top:8px;">
                共<span id="lTotalCount" class="org">1</span>条记录 ， 
                每页显示 
                <select id="ddlPageSize" style="line-height:25px;min-height:25px;padding:2px 4px;border:1px solid #d9d9d9">
	                <option selected="selected" value="10">10</option>
	                <option value="20">20</option>
	                <option value="50"> 50 </option>
	                <option value="100"> 100 </option>
	                <option value="200"> 200 </option>
	                <option value="300"> 300 </option>
	                <option value="500"> 500 </option>
	                <option value="1000"> 1000 </option>
	                <option value="2000"> 2000 </option>
                </select>
                 ，跳转至：<input type="text" style="line-height:20px;min-height:20px;padding:2px 4px;border:1px solid #d9d9d9;width:40px"> 页
                <button type="button" class="btn btn-default" style="padding:2px 8px 3px 8px;" onclick="">跳转</button>
            </div>
            <div class="pager clearfix" style=""><span class="current">1</span></div>
        </div>
        </div>
		<el-dialog  :visible.sync="dialogVisible" width="1300px" :before-close="handleClose">
					<span style="color: #5a5a5a;font-size: 15px;position: absolute;top: 6px;">练习统计-1、Redis介绍</span>
					<div class="topp-1">
						<img style="position: absolute;left: 41px;top: 67px;" src="../../../public/images/27.png" />
						<span style="position: absolute;left: 74px;top: 74px;font-size: 15px;">练习统计</span>
						<div class="dc-3-1">
							<img src="../../../public/images/24.png" />
							<span>导出</span>
						</div>
						<span style="color: #a699b3;position: absolute;right: 129px;top: 77px;">|</span>
						<div class="cx-3-1" @click="abc1">
							<img src="../../../public/images/13.png" />
							<span>查询</span>
						</div>
					</div>
					<div class="cha-4" v-show="abc">
						<span class="s1-3-1">关键词搜索</span><input class="in1-3-1" type="text" />
						<div class="cx2-3-1" >
							<img src="../../../public/images/15.png" />
							<span>查询</span>
						</div>
						<div class="cz-3-1">
							<img src="../../../public/images/16.png" />
							<span>重置</span>
						</div>
					</div>
					<table cellspacing="0" style="position: relative;top: 5px;">
						<tr style="height: 60px; background-color: white; text-align: center; font-size: 17px;">
							<td style="border: 1px solid #eeeeee; width: 200px;border-right: none;">应参加人数<br>3</td>
							<td style="border: 1px solid #eeeeee; width: 200px;border-right: none;">已参加人数<br>1</td>
							<td style="border: 1px solid #eeeeee; width: 200px;border-right: none;">缺考人数<br>2</td>
							<td style="border: 1px solid #eeeeee; width: 200px;border-right: none;">参加人次<br>1</td>
							<td style="border: 1px solid #eeeeee; width: 200px;border-right: none;">正确率<br>33.00%</td>
							<td style="border: 1px solid #eeeeee; width: 200px;border-right: none;">错题率<br>67.0%</td>
							<td style="border: 1px solid #eeeeee; width: 200px;">平均练习时长<br>0分33秒</td>
						</tr>
					</table>
					<table cellspacing="0" style="position: relative;top: 10px;">
						<tr style="height: 30px; background-color: white; text-align: center; font-size: 17px;font-weight: 550;">
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;">账号</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;">姓名</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;">所属部门</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;">参加次数</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;">练习总时长</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;">正确率</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;">错题率</td>
							<td style="border: 1px solid #eeeeee; width: 158px;">操作</td>
						</tr>
						<tr style="height: 30px; background-color: white; text-align: center; font-size: 17px;">
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">test1</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">测试1</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">后台</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">1</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">0分33秒</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">33.0%</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-right: none;border-top: none;">67.0%</td>
							<td style="border: 1px solid #eeeeee; width: 158px;border-top: none;">练习详情</td>
						</tr>
					</table>
					<div class="ddd" style="border: 1px solid #eeeeee; text-align: center; width: 1258px;height: 35px;position: relative;top: 20px;">
						<span style="line-height: 35px;">共1条记录</span>
					</div>
					<span slot="footer" class="dialog-footer">
						<el-button @click="dialogVisible = false">取 消</el-button>
						<el-button type="primary" @click="dialogVisible = false">确 定</el-button>
					</span>
				</el-dialog>
	</div>
</template>

<script>
export default {
    data(){
      return {
		  dialogVisible: false,
		  abc: false,
          columns4: [//表格样式
            {
                type: 'selection',
                align: 'center',
                width: 60
                
            },
            {
                title: '练习名称',
                key: 'name1'
            },
            {
                title: '开始时间/结束时间',
                key: 'name2'
            },
            {
                title: '参与方式',
                key: 'name3'
            },
            {
                title: '练习类型',
                key: 'name4'
            },
            {
                title: '参加人数',
                key: 'name5'
            },
            {
                title: '练习次数',
                key: 'name6',
            },
            {
                title: '平均练习时长',
                key: 'name7',
                align: 'center',
            },
            {
                title: '得分率',
                key: 'name8',
                align: 'center',
            },
            {
                title: '正确率',
                key: 'name9',
                align: 'center',
              
            },
            {
                title: '错题率',
                key: 'name10',
                align: 'center',
              
            },
            {
                title: '操作',
                slot: 'name',
                width: 67,
                align: 'center'
            }
        ],
        data1: [//表格数据
            {
                name1: '1、Redis介绍',
                name2: '2020-04-03 10:39 ~ 2020-04-10 10:39',
                name3: '安排考试',
                name4: '章节练习',
                name5: '1',
                name6: '1',
                name7: '0 分钟',
                name8: '0.00',
                name9: '33.00%',
                name10: '67.00%',
            },
           
        ]
      }
	},
	methods:{
        handleClose(done) {
        	this.$confirm('确认关闭？')
        		.then(_ => {
        			done();
        		})
        		.catch(_ => {});
        },
		abc1() {
			if (this.abc == false) {
				this.abc = true
			} else {
				this.abc = false
			}
		},
	}
}
</script>

<style scoped>
	.main-box1 {
        float: left;
        padding: 15px 20px 20px 20px;
        width: 100%;
        min-height: 600px;
        background-color: #f7f9fb;
    }
    .tabmenu {
        width: 100%;
        border: 1px solid #e6e9ee;
        background: #fff;
        margin-bottom: 5px;
        height: 46px;
        border-bottom: 1px solid #eee;
        color: #999;
    }
   .tabmenu a {
        color: #000;
        top: 1px;
        width: 150px;
        height: 46px;
        line-height: 46px;
        padding: 8px 25px 10px 25px;
        left: 150px;
        text-align: center;
        font-size: 14px;
        color: #428bca;
        text-decoration: none;
    }
    .btn-default {
        color: #333;
        background-color: #fff;
        border-color: #ccc;
    }
    .btn {
        display: inline-block;
        padding: 6px 12px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857143;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        cursor: pointer;
        background-image: none;
        border: 1px solid #e6e9ee;
        border-radius: 4px;
        margin-left: 3px;
    }
    .pages {
        display: inline-block;
        width: 100%;
        color: #555;
        text-align: center;
    }

    .pagination {
        display: inline-block;
        padding-left: 0;
        margin: 20px 0;
        border-radius: 4px;
    }
    .pager span.current {
        background-color: #222a35;
        color: #fff;
        border-color: #ebebeb;
    }
    .pager a, .pager span {
        width: 45px;
        height: 40px;
        border: 1px solid #ebebeb;
        margin-left: -1px;
        color: #8a8a8a;
        display: inline-block;
        line-height: 40px;
        font-size: 15px;
        text-decoration: none;
        margin: 0 2px;
        border-radius: 6px;
        text-align: center;
        margin-top: 15px;
    }
    
	
	.ddd:hover {
			color: #007DCE;
		}
	
		.s1-3-1 {
			color: #777777;
			position: absolute;
			left: 29px;
			top: 36px;
			font-size: 12px;
		}
	
		.in1-3-1 {
			border: 1px solid #dbd9d9;
			width: 260px;
			height: 32px;
			position: absolute;
			left: 98px;
			top: 28px;
			border-radius: 3px;
		}
		.cx-3-1{
			width: 73px;
			height: 35px;
			line-height: 40px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 150px;
			top: 68px;
			border-radius: 6px;
			cursor: pointer;
			text-align: center;
		}
		.dc-3-1{
			width: 73px;
			height: 35px;
			line-height: 40px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 40px;
			top: 68px;
			border-radius: 6px;
			cursor: pointer;
			text-align: center;
			background-color: #2B71C8;
			color: #FFFFFF;
		}
	
		.cx2-3-1 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 206px;
			top: 25px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.cz-3-1 {
			width: 73px;
			height: 35px;
			border: 1px solid #cccccc;
			position: absolute;
			right: 128px;
			top: 25px;
			border-radius: 6px;
			cursor: pointer;
		}
	
		.cx2-3-1:hover,
		.cz-3-1:hover {
			background-color: #eff2f5;
		}
	
		.cx2-3-1 img {
			position: absolute;
			left: 8px;
			top: 11px;
		}
	
		.cz-3-1 img {
			position: absolute;
			left: 6px;
			top: 11px;
		}
	
		.cz-3-1 span,
		.cx2-3-1 span {
			margin-left: 25px;
			line-height: 36px;
			color: #6a7680;
		}
	
		.cha-4 {
			background-color: white;
			height: 90px;
			width: 1258px;
			position: relative;
			top: 5px;
			border-radius: 5px;
			border: 1px solid #e6e9ee;
		}
	
		.topp-1 {
			border: 1px solid #e6e9ee;
			height: 50px;
			background-color: white;
		}
	
</style>
