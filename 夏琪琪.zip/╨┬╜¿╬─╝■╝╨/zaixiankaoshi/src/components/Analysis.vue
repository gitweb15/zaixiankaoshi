<template>
    <div class="syle">
        <div style="padding:15px 20px;background-color: #f7f9fb;">
      <div
        style="border: 1px solid #e6e9ee;margin-bottom: 5px;height: 46px;border-bottom: 1px solid #eee;float: left;width:100% ">
        <div style="color: #2b71c8;border-bottom: 2px solid #2b71c8;width: 150px;height: 46px;line-height: 46px;padding: 8px 25px 10px 25px;font-size: 14px;float: left;">
          <i class="fa fa-bar-chart-o"></i>  考生分析
        </div>
        <div style="font-size: 12px;float: right;padding: 4px;">
          <ButtonGroup style="padding: 0 4px 0 0;">
            <Button>
              <i class="fa fa-angle-double-down" aria-hidden="true"></i>
              查询
            </Button>
          </ButtonGroup>
            <ButtonGroup> 
            <Button>
              <i class="fa fa-download" aria-hidden="true"></i>
              导出
            </Button>
            
            
          </ButtonGroup> 
           
        </div>
      </div>
      <div class="table">
 <Table border :columns="columns12" :data="data6" ref="selection">
        <template  slot-scope="{ row }" slot="classification">
            {{ row.classification }}
        </template>
        <template slot-scope="{ row, index }"  slot="action">
			<div @click="dialogVisible = true">
			   <i class="fa fa-bar-chart-o"></i>
			   <span style="font-size: 12px;color: #2376e6;">考生分析</span>
           </div>   
        </template>
    </Table>
      </div>
      <div style="margin: 20px 20px;
    text-align: left;
    padding-top: 8px;">
        共
        <span style="    font-style: normal;
    color: #ff8000;">2</span> 条记录 ， 每页显示
        <Select v-model="model1" style="width:50px">
          <Option v-for="item in cityList" :value="item.value" :key="item.value">{{ item.label }}</Option>
        </Select>，跳转至：
        <Input v-model="value" style="width: 50px" />页
        <ButtonGroup>
          <Button>跳转</Button>
        </ButtonGroup>
        <!-- <Page :total="40" size="small" show-elevator show-sizer  show-total  /> -->
      </div>
    </div>
    <BackTop :height="70" :bottom="10" style="width: 40px;">
      <div class="top">帮助</div>
      <div class="top1">
        <Icon type="ios-arrow-up" style="padding: 0;" />
      </div>
    </BackTop>
	<el-dialog title="" :visible.sync="dialogVisible" width="1300px" :before-close="handleClose">
				<div class="tc" style="height: 700px;">
					<span style="position: absolute;top: 22px;font-size: 18px;">考生分析-测试2</span>
					<div style="border-bottom: 1px solid #eeeeee;"></div>
					<table cellspacing="0" style="font-size:14px;position: absolute;top: 81px;">
						<tr>
							<td width="62px" height="45px" style="border: 1px solid #e6e9ee;text-align:center;">姓名:</td>
							<td bgcolor="white" width="252px" style="border: 1px solid #e6e9ee;text-align:center;text-align:left; font-size: 15px;font-weight: bold;">测试2</td>
							<td width="62px" height="45px" style="border: 1px solid #e6e9ee;text-align:center;">账号:</td>
							<td bgcolor="white" width="252px" style="border: 1px solid #e6e9ee;text-align:center;text-align:left;font-size: 15px;font-weight: bold;">test2</td>
							<td width="72px" height="45px" style="border: 1px solid #e6e9ee;text-align:center;">所属部门:</td>
							<td bgcolor="white" width="547px" style="border: 1px solid #e6e9ee;text-align:center;text-align:left;font-size: 15px;font-weight: bold;">海纳创新/前台</td>
						</tr>
					</table>
					<span style="color: #555555; font-size: 18px;position: absolute;top: 155px;">考生分析</span>
					<table cellspacing="0" style="position: absolute;top: 208px; text-align: center;">
						<tr bgcolor="#f9fcff">
							<td style="border: 1px solid  #e6e9ee; border-right: none;width: 120px; height:35px;"></td>
							<td style="border: 1px solid  #e6e9ee;border-right: none;width: 120px; border-left: none;text-align: center;font-weight: bold;">考试</td>
							<td style="border: 1px solid  #e6e9ee;width: 120px;border-left: none;"></td>
						</tr>
						<tr bgcolor="#f9fcff">
							<td style="border: 1px solid  #e6e9ee; border-right: none;height:35px;border-top: none;font-weight: bold;">参加数</td>
							<td style="border: 1px solid  #e6e9ee;border-right: none;border-top: none;height:35px;font-weight: bold; ">通过数</td>
							<td style="border: 1px solid  #e6e9ee;border-top: none;font-weight: bold;">通过率</td>
						</tr>
						<tr bgcolor="white">
							<td style="border: 1px solid  #e6e9ee; border-right: none; height:35px;border-top: none;">0</td>
							<td style="border: 1px solid  #e6e9ee;border-right: none; border-top: none;">0</td>
							<td style="border: 1px solid  #e6e9ee;border-top: none;">0%</td>
						</tr>
					</table>
	
					<table cellspacing="0" style="position: absolute;top: 208px;left: 383px;text-align: center;">
						<tr bgcolor="#eff2f5">
							<td style="border: 1px solid  #e6e9ee; border-right: none;width: 120px; height:35px;"></td>
							<td style="border: 1px solid  #e6e9ee;border-right: none;width: 120px; border-left: none;font-weight: bold;">练习</td>
							<td style="border: 1px solid  #e6e9ee;width: 120px;border-left: none;"></td>
						</tr>
						<tr bgcolor="#eff2f5">
							<td style="border: 1px solid  #e6e9ee; border-right: none;height:35px;border-top: none;font-weight: bold;">参加数</td>
							<td style="border: 1px solid  #e6e9ee;border-right: none;border-top: none;font-weight: bold; ">练习时长</td>
							<td style="border: 1px solid  #e6e9ee;border-top: none;font-weight: bold;">正确率</td>
						</tr>
						<tr bgcolor="white">
							<td style="border: 1px solid  #e6e9ee; border-right: none;height:35px;border-top: none;">0</td>
							<td style="border: 1px solid  #e6e9ee;border-right: none; border-top: none;">0分钟</td>
							<td style="border: 1px solid  #e6e9ee;border-top: none;">0.00%</td>
						</tr>
					</table>
	
					<table cellspacing="0" style="position: absolute;top: 208px;left: 746px;text-align: center;">
						<tr bgcolor="#f9fcff">
							<td style="border: 1px solid  #e6e9ee; border-right: none;width: 120px; height:35px;"></td>
							<td style="border: 1px solid  #e6e9ee;border-right: none;width: 120px; border-left: none;font-weight: bold;">培训</td>
							<td style="border: 1px solid  #e6e9ee;width: 120px;border-left: none;"></td>
						</tr>
						<tr bgcolor="#f9fcff">
							<td style="border: 1px solid  #e6e9ee; border-right: none;height:35px;border-top: none;font-weight: bold;">参加数</td>
							<td style="border: 1px solid  #e6e9ee;border-right: none;border-top: none;font-weight: bold; ">完成数</td>
							<td style="border: 1px solid  #e6e9ee;border-top: none;font-weight: bold;">完成率</td>
						</tr>
						<tr bgcolor="white">
							<td style="border: 1px solid  #e6e9ee; border-right: none;border-top: none; height: 35px;">0</td>
							<td style="border: 1px solid  #e6e9ee;border-right: none; border-top: none;">0</td>
							<td style="border: 1px solid  #e6e9ee;border-top: none;">0%</td>
						</tr>
					</table>
	
	
					<table cellspacing="0" style="position: absolute;top: 208px;left: 1109px;text-align: center;">
						<tr>
							<td style="border: 1px solid  #e6e9ee;width: 170px; height:70px;font-weight: bold;">所得积分</td>
						</tr>
						<tr bgcolor="white">
							<td style="border: 1px solid  #e6e9ee;height:35px;border-top: none;">0.00</td>
						</tr>
					</table>
					<table cellspacing="0" style="position: absolute;top: 384px;text-align: center;font-weight: bold;    width: 1264px;">
						<tr>
							<td style="width: 237px; height: 35px;text-align: left;border: 1px solid  #e6e9ee;">考试名称</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">总分/及格分数</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">参加次数</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">及格次数</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">最好成绩</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">所得积分</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">通过考试</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">考试排名</td>
							<td style="width: 111px; height: 35px;border: 1px solid  #e6e9ee;">击败人数</td>
							<td style="width: 110px; height: 35px;border: 1px solid  #e6e9ee;">击败率</td>
						</tr>
					</table>
					<span style="color: #555555; font-size: 18px;position: absolute;top: 340px;">考试(<span style="color: #ff0000;">0</span>)</span>
					<span style="color: #555555; font-size: 18px;position: absolute;top: 457px;">练习(<span style="color: #ff0000;">0</span>)</span>
					<span style="color: #555555; font-size: 18px;position: absolute;top: 590px;">课程(<span style="color: #ff0000;">0</span>)</span>
					<table cellspacing="0" style="position: absolute;top: 516px;text-align: center;font-weight: bold;">
						<tr>
							<td style="width: 450px; height: 35px;text-align: left;border: 1px solid  #e6e9ee;">练习名称</td>
							<td style="width: 199px; height: 35px;text-align: left;border: 1px solid  #e6e9ee;">练习类型</td>
							<td style="width: 199px; height: 35px;border: 1px solid  #e6e9ee;">练习时长</td>
							<td style="width: 199px; height: 35px;border: 1px solid  #e6e9ee;">正确率</td>
							<td style="width: 199px; height: 35px;border: 1px solid  #e6e9ee;">所得积分</td>
						</tr>
					</table>
	
					<table cellspacing="0" style="position: absolute;top: 650px;text-align: center;font-weight: bold;">
						<tr>
							<td style="width: 345px; height: 35px;text-align: left;border: 1px solid  #e6e9ee;">课程名称</td>
							<td style="width: 180px; height: 35px;border: 1px solid  #e6e9ee;">学习时长</td>
							<td style="width: 180px; height: 35px;border: 1px solid  #e6e9ee;">考试成绩</td>
							<td style="width: 180px; height: 35px;border: 1px solid  #e6e9ee;">所得积分</td>
							<td style="width: 180px; height: 35px;border: 1px solid  #e6e9ee;">进度</td>
							<td style="width: 180px; height: 35px;border: 1px solid  #e6e9ee;">状态</td>
						</tr>
					</table>
				</div>
				<span slot="footer" class="dialog-footer">
					<el-button @click="dialogVisible = false">取 消</el-button>
					<el-button type="primary" @click="dialogVisible = false">确 定</el-button>
				</span>
			</el-dialog>
    </div>

</template>

<script>
export default {
    data(){
        return{
            columns12: [//表格样式
        
                     {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '姓名',
                        key: 'name'
                    },
                    {
                        title: '账号',
                        key: 'age'
                    },
                    {
                        title: '所属部门',			
                        key: 'address'
                    },{ title: '考试',
                        align: 'center',
                        children: [
                                    {
                                        title: '参加数',
                                        key: 'street',
                                        align: 'center',
                                        
                                    },{
                                        title: '通过数',
                                        key: 'street',
                                        align: 'center',
                                        
                                    },{
                                        title: '通过率',
                                        key: 'street',
                                        align: 'center',
                                       
                                    }]},{ title: '练习',
                        align: 'center',
                        children: [
                                    {
                                        title: '参加数',
                                        key: 'street',
                                        align: 'center',
                                        
                                    },{
                                        title: '练习时长',
                                        key: 'street',
                                        align: 'center',
                                        
                                    },{
                                        title: '正确率',
                                        key: 'street',
                                        align: 'center',
                                       
                                    }]},{ title: '培训',
                        align: 'center',
                        children: [
                                    {
                                        title: '参加数',
                                        key: 'street',
                                        align: 'center',
                                        
                                    },{
                                        title: '完成数',
                                        key: 'street',
                                        align: 'center',
                                        
                                    },{
                                        title: '完成率',
                                        key: 'street',
                                        align: 'center',
                                       
                                    }]},{
                        title: '所得积分',
                        key: 'address'
                    },
                    {
                        title: '操作',
                        slot: 'action',
                     width:120,
                        align: 'center'
                    }
                ],
                data6: [
                    {
          name: "John Brown",
          age: 18,
          address: "New York No. 1 Lake Park",
          classification: "试题分类/Nginx",street:10
        },
        {
          name: "Jim Green",
          age: 24,
          address: "London No. 1 Lake Park",
          classification: "试题分类/Nginx",street:10
        }
                ],
      cityList: [
        {
          value: "10",
          label: "10"
        },
        {
          value: "20",
          label: "20"
        },
        {
          value: "30",
          label: "30"
        },
        {
          value: "40",
          label: "40"
        },
        {
          value: "100",
          label: "100"
        },
        {
          value: "1000",
          label: "1000"
        }
      ], 
	  model1: "20",
	  value: '',
		value1: '',
		value2: '',
		show: false,
		dialogVisible: false
        }
    },
	methods:{
		handleClose(done) {
			this.$confirm('确认关闭？')
				.then(_ => {
					done();
				})
				.catch(_ => {});
		}
	}
}
</script>

<style scoped>
.syle{
        
        background-color: #f7f9fb;
       min-height: 600px;
}
.top {
  display: inline-block;
  height: 35px;
  width: 100%;
  color: #fff;
  background: #2b71c8;
  border: 1px solid #e8e8e8;
  font-size: 12px;
  font-weight: 500;
  text-align: center;
  text-decoration: none;
  line-height: 35px;
}
.top1 {
  display: inline-block;
  height: 35px;
  width: 100%;
  color: #fff;
  background: #2b71c8;
  border: 1px solid #e8e8e8;
  font-size: 12px;
  font-weight: 500;
  text-align: center;
  text-decoration: none;
  line-height: 35px;
}
</style>