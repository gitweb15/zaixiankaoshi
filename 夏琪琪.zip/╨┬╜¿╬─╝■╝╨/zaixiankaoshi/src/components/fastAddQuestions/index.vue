<template>
    <div class="syle">
     <!-- 批量添加试题 -->
        <Modal v-model="modal6" width="944" @on-cancel="oncancel" title="批量添加试题" >
            <div class="nav">
                 <div class="fieldset">
                    <label class="control-labels">指定试题分类</label>
                    <div class="input-group">
                        <input name="txtTreeName" type="text" placeholder="请选择一个分类，试题将导入到此分类下" class="form-control" size="30">
                        <div class="input_but">
                            <button type="button" class="btn btn-default" data-toggle="dropdown">选择</button>
                        </div>
                    </div>
                </div>
                <div class="fieldset">
                    <label class="control-labels">单击快速添加</label>
                    <div class="exportType">
                        <a href="#" target="_blank"><i class="fa fa-plus"></i>  单选题</a>
                        <a href="#" target="_blank"><i class="fa fa-plus"></i>  多选题</a>
                        <a href="#" target="_blank"><i class="fa fa-plus"></i>  判断题</a>
                        <a href="#" target="_blank"><i class="fa fa-plus"></i>  填空题</a>
                        <a href="#" target="_blank"><i class="fa fa-plus"></i>  问答题</a>
                    </div>
                </div>
               
                 <div class="fieldset">
                    <label class="control-labels">试题分类</label>
                    <div class="input-group" style="font-size:12px;">
                        <fieldset style="border:none">
            <span style="width:80%;float:left">
                <textarea name="txtQuestionContent" id="txtQuestionContent" class="form-controls" style="width:96%;height:410px;font-size:13px;" rows="21">
                    (题型:单选题)(标准答案:A)(分数:5)(试题难度:容易)
                    公益性文化事业是保障公民及泵文化权益的重要途径。大力发展公益性文化事业，始终坚持放在首位的是（ ）
                    A.繁荣文化市场
                    B.经济效益
                    C.社会效益
                    D.创新文化体制

                    (题型:多选题)(标准答案:B,C)(分数:2)(试题分类:自然科学/医疗机械类)(试题分析:无)
                    各类安全工器具应经过国家规定的()和使用中的周期性试验，并做好记录。
                    A.出厂试验
                    B.型式试验
                    C.外观检验
                    D.耐压试验

                    (题型:填空题)(标准答案:神经和体液|作用时间较长&amp;作用时间长)(分数:2)(试题难度:困难)
                    运动员出发后心跳加快，是___调节的结果；运动停止后心跳并不立即恢复到正常水平，原因之一是激素调节具有___的特点。

                    (题型:判断题)(标准答案:B)(分数:5)
                    在同一个圆里 半径的数量是直径的一半。
                    A.正确
                    B.错误

                    (题型:问答题)(标准答案:在车轨上)(分数:5)(试题分类:百科知识/脑筋急转弯类)
                    火车由北京到上海需要6小时,行使3小时后,火车该在什么地方?

                </textarea>
                <br>
                <textarea name="txtOutputMsg" id="txtOutputMsg" class="form-control" readonly="" style="width:96%;font-size:13px;display:none;color:seagreen" rows="8"></textarea>
            </span>
            <span style="width:19%;float:left;line-height:28px;">
                <h5>导入须知</h5>
                1、试题与试题之间用空行隔开。<br>
                2、每道试题内部不允许出现空行，也不要手动按回车键换行，如果内容太长超出一行范围让其自动换行。<br>
                3、填空题：填空位置请用三个连续英文下划线标记,如___,填空题多个填空答案使用竖线|分隔，一个空有多个答案请用&amp;开隔<br>
            </span>
        </fieldset>
                    </div>
                </div>
                

            </div>
           <div slot="footer" class="footer_but">        
                <button class="btn btn-default"><i class="fa fa-check" aria-hidden="true"></i>   检查格式</button>
                <button class="btn btn-blue" disabled="disabled"><i class="fa fa-arrow-circle-o-up" aria-hidden="true"></i>   导入</button>
                <button class="btn btn-default" onclick="javascript:Dialog.close()"><i class="fa fa-window-close-o" aria-hidden="true"></i>   关 闭</button>
            </div>
        </Modal>
    </div>

</template>

<script>
export default {
    data(){
        return{
           modal6: true
        }
    },
    methods:{
       oncancel(){
           this.$router.push("/questions")
       }
    },
}
</script>

<style scoped>

.form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);

}

.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
.btn-red {
    border-radius: 3px;
    color: #fff;
    border: none;
    cursor: pointer;
    background-color: red;
}
.btn-default {
    color: #333;
    background-color: #fff;
    border-color: #ccc;
}



.form-control {
    padding-left: 5px;
    border-color: #dbd9d9;
    box-shadow: none;
    font-size: 13px;
    overflow-x: hidden;
}
textarea {
    resize: none;
}

.append-box .bottom {
    display: inline-block;
    padding: 6px 0 6px 0;
    width: 100%;
    text-align: center;
    z-index: 11;
    background: #f8f8f8;
    border-top: 1px solid #eee;
}
/* 批量导入 */
.nav{
    width: 915px;
    height: 382px;
    overflow-y:scroll; 
}
.fieldset{
    width: 100%;
    height: 40px;
    display: flex;
    margin-bottom: 30px;
}
.control-labels{
    width: 150px;
    height: 40px;
    vertical-align: middle;
    line-height: 40px;
}

.exportType a{
    display: inline-block;
    padding: 4px 8px;
    border: 1px solid #2b71c8;
    margin-right: 5px;
}
.input_but{
    position: relative;
    left: 248px;
    bottom: 34px;
}

.file {
    display: inline-block;
    background: #D0EEFF;
    border: 1px solid #99D3F5;
    border-radius: 4px;
    padding: 4px 12px;
}
.footer_but{
    display: inline-block;
    padding: 6px 0 6px 0;
    width: 100%;
    text-align: center;
    background: #fff;
    border-top: 1px solid #eee;
    
}

.required{
    width: 300px;
}


</style>