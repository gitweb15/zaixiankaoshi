import Vue from 'vue'
import VueRouter from 'vue-router'


Vue.use(VueRouter)

  const routes = [
    {
      path: '/',
      name: 'login',
      component: () => import('@/views/login')//登录
    },
  {
    path: '/Home',
    name: 'Home',
    component: () => import('@/views/Home')//主页
  },
	{
		path: '/kaoshi',
		name: 'Kaoshi',
		component: () => import('../views/kaoshi.vue')//考试
	},
	{
		path: '/lianxi',
		name: 'Lianxi',
		component: () => import('../views/lianxi.vue')//练习
	},
	{
		path: '/peixun',
		name: 'Peixun',
		component: () => import('../views/peixun.vue')//培训
	},
	{
		path: '/Upgrade',
		name: 'Upgrade',
		component: () => import('../views/Upgrade')//在线升级
	},
  {
    path: '/Modal',
    name: 'Modal',
    component: () => import('@/components/Modal')
  },
  {
		path: '/questions',
		name: 'Questions',
		component: () => import('../views/questions')//试题管理
	},
	{
		path: '/examinee',
		name: 'Examinee',
    component: () => import('../views/Examinee'),//考生管理
    children:[
      {
        path: '/addCandidates',//新增考生
        name: 'AddCandidates',
        component: () => import('../components/addCandidates')
      },
      {
        path: '/batchCandidates',//批量导入考生
        name: 'batchCandidates',
        component: () => import('../components/batchCandidates')
      }
    ]
	},
  {
		path: '/core',
		name: 'Core',
		component: () => import('../views/core')//考生中心
	},
  {
		path: '/examedit',
		name: 'Examedit',
		component: () => import('../components/examedit')//创建考试
	},
	{
		path: '/createLianxi',
		name: 'CreateLianxi',
		component: () => import('../components/createLianxi')//创建练习
	},
  {
		path: '/lessonedit',
		name: 'Lessonedit',
		component: () => import('../components/lessonedit')//创建培训课程
  },
  {
    path: '/SubAdministrator',
    name: 'SubAdministrator',
    component: () => import('../views/SubAdministrator'),//管理设置
    redirect: '/SubAdministrator/admin',
    children:[
      {
        path:'admin',
        name: 'Admin',
        component:()=>import('@/components/admin'),//账号信息
        
      },
      {
        path:'ziliuyou',
        name: 'Ziliuyou',
        component:()=>import('@/components/ziliuyou'),//子管理员
        
      },
      {
        path:'Control',
        name: 'Control',
        component:()=>import('@/components/Control'),//购买历史
        
      },
      
      
    ]
  },
  {
    path: '/baobiao',
    name: 'baobiao',
    component: () => import('../views/baobiao'),//报表
    redirect: '/kaoshichengji',
    children:[
      {
				path: '/kaoshichengji',//考试成绩
				component: () => import('@/components/kaoshichengji')
      }, 
      {
				path: '/Analysis',//考生分析
				name: 'Analysis',
				component: () => import('../components/Analysis')
			},
      {
        path:'/Statistical',//答题统计
        component:()=>import('@/components/Statistical'),
        
      }, 
      {
				path: '/quexitongji',//缺席统计
				name: 'Quexitongji',
				component: () => import('@/components/quexitongji.vue')
      }, 
      {
				path: '/judgepaper',//人工评卷
				name: 'Judgepaper',
				component: () => import('@/components/judgepaper.vue')
      },
      {
        path:'/Practice',//练习统计
        component:()=>import('@/components/Practice'),
        
      },  
      {
				path: '/lessonanalysis',//培训学习统计
				name: 'Lessonanalysis',
				component: () => import('../components/lessonanalysis.vue')
      }, 
      {
				path: '/IntegralAnalysis',//积分统计
				name: 'IntegralAnalysis',
				component: () => import('../components/IntegralAnalysis.vue')
      }, 
      {
				path: '/itemAnalysis',//试题分析
				name: 'itemAnalysis',
				component: () => import('../components/itemAnalysis')
			}, 
      {
				path: '/questionTypeAnalysis',//试题类型统计
				name: 'QuestionTypeAnalysis',
				component: () => import('../components/questionTypeAnalysis')
			}
    ]
  },
  {
		path: '/register',//注册
		name: 'register',
		component: () => import('../views/register.vue')
  },
  {
		path: '/questions',
		name: 'questions',
    component: () => import('../views/questions.vue'),//试题管理
    children:[
      
      {
        path: '/addQuestions',//试题新增&编辑
        name: 'addQuestions',
        component: () => import('../components/addQuestions')
      },
      {
        path: '/BatchQuestions',//批量导入试题
        name: 'BatchQuestions',
        component: () => import('../components/BatchQuestions')
      },
      {
        path: '/fastAddQuestions',//批量添加试题
        name: 'fastAddQuestions',
        component: () => import('../components/fastAddQuestions')
      }
    ]
	},
	{
		path: '/examedit2',//设计试卷
		name: 'examedit2',
		component: () => import('../components/examedit2')
	},
	{
		path: '/examedit3',//发布试卷
		name: 'examedit3',
		component: () => import('../components/examedit3')
	},
	{
		path: '/createLianxi2',//发布练习
		name: 'createLianxi2',
		component: () => import('../components/createLianxi2')
	},
	{
		path: '/createLianxi3',//发布练习
		name: 'createLianxi3',
		component: () => import('../components/createLianxi3')
	},
	{
		path: '/lessonedit2',//发布练习
		name: 'lessonedit2',
		component: () => import('../components/lessonedit2')
	},
	{
		path: '/lessonedit3',//发布练习
		name: 'lessonedit3',
		component: () => import('../components/lessonedit3')
	}
 
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
